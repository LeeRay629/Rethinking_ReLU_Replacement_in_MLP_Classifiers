"""
Result dataclass returned by `quad4fhe.replace(...)`.
"""
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Union

import numpy as np
import os


@dataclass
class QuantScanRow:
    """One row of the quantization-robustness scan (one decimal-place level)."""
    decimals: int
    delta_theta_l2: float                       # ||theta_q - theta*||_2
    within_tolerance: bool                      # ||Delta theta|| < delta_mu / (R+ + R-)
    separation_preserved: bool                  # RCH separation still holds?
    gap: float                                  # P_mu - N_mu (binary) / min pairwise margin (multi)
    extra: Dict[str, Any] = field(default_factory=dict)


@dataclass
class ReplacementResult:
    """
    Full result of a `quad4fhe.replace(...)` call.

    Attributes
    ----------
    alpha, beta, eta : float
        Coefficients of the quadratic replacement p(u) = alpha * u^2 + beta * u + eta.
    threshold : Optional[float]
        Deployment threshold tau (binary task only). None for multi-class.
    zero_threshold_realized : Optional[bool]
        Whether eta was chosen so that the natural decision boundary lies at 0
        (binary only). None for multi-class.
    method_used : str
        One of "hard", "soft(C=<value>)", "rch(mu=<value>)".
    feasible : bool
        True iff the exact lossless condition (hard-margin) held. When False,
        the returned coefficients come from the robust (soft-margin / RCH) fallback.
    empirical_margin : float
        gamma* for binary (Theorem 1), or min pairwise margin for multi-class.
    normalized_margin : float
        rho = gamma* / ||theta|| (binary); min pairwise margin / ||theta_bar|| (multi).
    quant_decimals : int
        Smallest number of decimal places at which rounded coefficients still
        preserve separation. 0 if no tested level is safe.
    quant_scan : List[QuantScanRow]
        Full per-dp scan results (1..7 by default).
    W1, b1, W2, b2 : np.ndarray
        The BN-folded effective weights of the underlying model.
        - Binary  : W2 has shape (H,), b2 is a float.
        - Multi-K : W2 has shape (K, H), b2 has shape (K,).
    replaced_model : Optional[torch.nn.Module]
        A deep-copy of the original model with the activation replaced by a
        `QuadraticActivation`. Only present when `return_module=True`.
    report_vs_pseudo, report_vs_truth : Optional[pd.DataFrame]
        Two evaluation tables (agreement-with-original and accuracy-against-truth).
        Only present when `test_data` is given.
    fit_diagnostics, test_diagnostics : Optional[Dict[str, Any]]
        Direct calibration/test decision-preservation diagnostics for Quad4FHE,
        including agreement, mismatch count, and exact-preservation flag.
    solver_diagnostics : Optional[Dict[str, Any]]
        Margin/slack diagnostics and hyperparameter-selection trace.
    constraint_version : str
        Version tag for the theoretical constraint construction. Multiclass
        uses the corrected bias-free dL lift.
    baseline_results : Optional[Dict[str, Dict[str, Any]]]
        Keyed by baseline name (e.g. "remez_2", "ola"). Only present when
        `baselines` is non-empty.
    he_export_dir : Optional[str]
        Absolute path to exported HE artifacts (if `export_he_dir` was given).
    """
    # Core coefficients
    alpha: float
    beta: float
    eta: float
    threshold: Optional[float] = None
    zero_threshold_realized: Optional[bool] = None

    # Diagnostics
    method_used: str = "unknown"
    feasible: bool = False
    empirical_margin: float = float("nan")
    normalized_margin: float = float("nan")

    # Quantization
    quant_decimals: int = 0
    quant_scan: List[QuantScanRow] = field(default_factory=list)

    # Folded model weights
    W1: Optional[np.ndarray] = None
    b1: Optional[np.ndarray] = None
    W2: Optional[np.ndarray] = None
    b2: Optional[Union[float, np.ndarray]] = None

    # Replaced module
    replaced_model: Optional[Any] = None        # Optional[nn.Module], avoid torch import in dataclass

    # Evaluation
    report_vs_pseudo: Optional[Any] = None      # Optional[pd.DataFrame]
    report_vs_truth: Optional[Any] = None
    fit_diagnostics: Optional[Dict[str, Any]] = None
    test_diagnostics: Optional[Dict[str, Any]] = None
    solver_diagnostics: Optional[Dict[str, Any]] = None
    constraint_version: str = "unknown"

    # Baselines
    baseline_results: Optional[Dict[str, Dict[str, Any]]] = None

    # HE export
    he_export_dir: Optional[str] = None

    def summary(self) -> str:
        """Human-readable multi-line summary of the result."""
        lines = [
            "==== quad4fhe.ReplacementResult ====",
            f"  method_used            = {self.method_used}",
            f"  feasible (hard-margin) = {self.feasible}",
            f"  alpha                  = {self.alpha:+.10f}",
            f"  beta                   = {self.beta:+.10f}",
            f"  eta                    = {self.eta:+.10f}",
        ]
        if self.threshold is not None:
            lines.append(f"  threshold (tau)        = {self.threshold:+.10f}")
        if self.zero_threshold_realized is not None:
            lines.append(f"  zero-threshold deploy  = {self.zero_threshold_realized}")
        lines += [
            f"  empirical margin       = {self.empirical_margin:+.10f}",
            f"  normalized margin      = {self.normalized_margin:+.10f}",
            f"  constraint version     = {self.constraint_version}",
            f"  min safe decimal places= {self.quant_decimals}  "
            f"({'not quantizable' if self.quant_decimals == 0 else 'OK'})",
        ]
        if self.fit_diagnostics is not None:
            lines.append(
                f"  fit agreement         = {self.fit_diagnostics.get('agreement', float('nan')):.6f} "
                f"(mismatches={self.fit_diagnostics.get('mismatch_count', 'NA')})"
            )
        if self.test_diagnostics is not None:
            lines.append(
                f"  test agreement        = {self.test_diagnostics.get('agreement', float('nan')):.6f} "
                f"(mismatches={self.test_diagnostics.get('mismatch_count', 'NA')})"
            )
        if self.he_export_dir is not None:
            try:
                disp = os.path.relpath(self.he_export_dir)
                # If the relative path would walk up many directories
                # (very different drive on Windows), fall back to basename.
                if disp.startswith("..") and disp.count("..") > 2:
                    disp = os.path.basename(self.he_export_dir)
            except ValueError:
                # Windows: different drive — no relative path exists
                disp = os.path.basename(self.he_export_dir)
            lines.append(f"  HE artifact dir        = {disp}")
        return "\n".join(lines)

    def __repr__(self) -> str:  # pragma: no cover
        return self.summary()
