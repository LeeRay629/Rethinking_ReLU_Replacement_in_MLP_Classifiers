"""
quad4fhe.torch_adapter — PyTorch-facing utilities:

* `QuadraticActivation`   — drop-in nn.Module that computes alpha x^2 + beta x + eta
* `extract_layer_weights` — inspect a model, find the hidden/output layers, fold BN
* `build_replaced_model`  — deep-copy a model and swap the activation
"""
from quad4fhe.torch_adapter.activation import QuadraticActivation
from quad4fhe.torch_adapter.extractor import (
    UnsupportedLayerError,
    extract_layer_weights,
    resolve_module_by_path,
)
from quad4fhe.torch_adapter.replace import build_replaced_model

__all__ = [
    "QuadraticActivation",
    "extract_layer_weights",
    "resolve_module_by_path",
    "UnsupportedLayerError",
    "build_replaced_model",
]
