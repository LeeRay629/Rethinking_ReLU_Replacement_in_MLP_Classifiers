"""Integration test for the frozen-backbone code path."""
import numpy as np
import torch
import torch.nn as nn

import quad4fhe
from tests.fixtures import make_multiclass_dataset


class _Head(nn.Module):
    def __init__(self, d, h, k):
        super().__init__()
        self.fc1 = nn.Linear(d, h)
        self.act = nn.ReLU()
        self.fc2 = nn.Linear(h, k)
    def forward(self, x):
        return self.fc2(self.act(self.fc1(x)))


class _Full(nn.Module):
    def __init__(self, d_in, d_back, h, k):
        super().__init__()
        self.backbone = nn.Sequential(nn.Linear(d_in, d_back), nn.Tanh())
        for p in self.backbone.parameters():
            p.requires_grad = False
        self.head = _Head(d_back, h, k)
    def forward(self, x):
        return self.head(self.backbone(x))


def test_frozen_backbone_runs_and_matches_theory():
    X_tr, X_te, y_tr, y_te = make_multiclass_dataset(n_classes=3, seed=0)
    torch.manual_seed(0)
    model = _Full(d_in=X_tr.shape[1], d_back=16, h=24, k=3)
    # Train only the head
    opt = torch.optim.Adam(model.head.parameters(), lr=5e-3)
    ce = nn.CrossEntropyLoss()
    X_t = torch.tensor(X_tr, dtype=torch.float32)
    y_t = torch.tensor(y_tr, dtype=torch.long)
    model.train()
    for _ in range(150):
        opt.zero_grad()
        loss = ce(model(X_t), y_t)
        loss.backward()
        opt.step()
    model.eval()

    res = quad4fhe.replace(
        task="multiclass",
        model=model,
        backbone=model.backbone,
        hidden_layer="head.fc1",
        output_layer="head.fc2",
        activation="relu",
        fit_data=(X_tr, y_tr),
        test_data=(X_te, y_te),
        verbose=False,
    )
    assert res.replaced_model is not None

    # Replaced model must be a drop-in for RAW inputs (it contains the backbone).
    rm = res.replaced_model.eval()
    with torch.no_grad():
        logits_module = rm(torch.tensor(X_te, dtype=torch.float32)).cpu().numpy()
        feats_test = (model.backbone(torch.tensor(X_te, dtype=torch.float32))
                      .cpu().numpy().astype(np.float64))

    from quad4fhe.core.lifting import (
        build_pairwise_lifted_constraints,
        quadratic_logits_from_QL,
    )
    _, _, _, Q, L, B = build_pairwise_lifted_constraints(
        feats_test, res.W1, res.b1, res.W2, res.b2,
        np.zeros(len(feats_test), dtype=np.int64),
    )
    logits_theory = quadratic_logits_from_QL(
        Q, L, res.alpha, res.beta, res.eta, B, res.b2,
    )
    diff = float(np.max(np.abs(logits_module - logits_theory)))
    assert diff < 1e-3, f"Frozen-backbone drop-in mismatch: {diff}"
