"""
quad4fhe.quant
==============

Quantization-robustness scan. Given the optimal (alpha, beta, eta) and the
corresponding separation condition (exact or RCH), round the coefficients to
N decimal places for N = 1..7 and check:

    (a) whether the rounded coefficients still satisfy the geometric
        separation condition (Theorem 1 / Theorem 4);
    (b) how much the separation gap shrinks.

The smallest N at which separation still holds is returned as
`quant_decimals`; if no N in the scan range works, 0 is returned (meaning
the user should not quantize below float precision).
"""
from __future__ import annotations

from typing import List, Optional

import numpy as np

from quad4fhe.core.geom import (
    compute_quantization_robustness_exact,
    compute_quantization_robustness_rch,
    verify_exact_separation,
    verify_rch_separation,
)
from quad4fhe.result import QuantScanRow

DEFAULT_DP_GRID = [1, 2, 3, 4, 5, 6, 7]


# -----------------------------------------------------------------------------
# Binary quantization scan (theta = (alpha, beta))
# -----------------------------------------------------------------------------
def scan_quantization_binary(
    alpha: float,
    beta: float,
    eta: float,
    S_plus: np.ndarray,
    S_minus: np.ndarray,
    *,
    mu_p: Optional[float] = None,
    mu_n: Optional[float] = None,
    dp_grid: List[int] = DEFAULT_DP_GRID,
) -> List[QuantScanRow]:
    """Scan rounding granularities for the binary case.

    If ``mu_p`` / ``mu_n`` are None, exact separation (Theorem 1 + Cor 1.2) is
    tested. Otherwise RCH separation (Theorem 4 + Cor 2.4) is tested.
    """
    theta_star = np.array([alpha, beta], dtype=np.float64)

    if mu_p is None or mu_n is None:
        rho_star, M, tol = compute_quantization_robustness_exact(theta_star, S_plus, S_minus)
        mode = "exact"
    else:
        delta_mu, R_plus, R_minus, tol = compute_quantization_robustness_rch(
            theta_star, S_plus, S_minus, mu_p, mu_n,
        )
        mode = "rch"

    rows: List[QuantScanRow] = []
    for dp in dp_grid:
        a_q = round(alpha, dp)
        b_q = round(beta, dp)
        theta_q = np.array([a_q, b_q], dtype=np.float64)
        delta = float(np.linalg.norm(theta_q - theta_star))
        within = (delta < tol)
        if mode == "exact":
            P, N, sep_ok = verify_exact_separation(theta_q, S_plus, S_minus)
            gap = P - N
        else:
            P, N, sep_ok = verify_rch_separation(theta_q, S_plus, S_minus, mu_p, mu_n)
            gap = P - N
        rows.append(QuantScanRow(
            decimals=int(dp),
            delta_theta_l2=delta,
            within_tolerance=bool(within),
            separation_preserved=bool(sep_ok),
            gap=float(gap),
            extra={
                "mode": mode,
                "alpha_q": a_q, "beta_q": b_q, "eta_q": round(eta, dp),
                "tolerance": float(tol),
            },
        ))
    return rows


# -----------------------------------------------------------------------------
# Multi-class quantization scan (theta = (alpha, beta, eta))
# -----------------------------------------------------------------------------
def scan_quantization_multiclass(
    alpha: float,
    beta: float,
    eta: float,
    Zbar: np.ndarray,
    dp_grid: List[int] = DEFAULT_DP_GRID,
) -> List[QuantScanRow]:
    """Scan for the multi-class case.

    Separation = all pairwise margins > 0 after rounding:
        min_i,r  Zbar_{i,r}^T * [u_q, v_q, w_q, lambda] > 0
    with lambda = 1 (theta = (u/lambda, v/lambda, w/lambda) convention).
    """
    Zbar = np.asarray(Zbar, dtype=np.float64)

    # Reference minimum pairwise margin with the unrounded theta.
    theta_ref_4d = np.array([alpha, beta, eta, 1.0], dtype=np.float64)
    ref_min_margin = float(np.min(Zbar @ theta_ref_4d))

    # 3D tolerance heuristic (Cor 2.4-style):
    # row.dot([u,v,w,1]) >= ref_min_margin, so delta_row.dot(row[:3]) could break it.
    R3 = float(np.max(np.linalg.norm(Zbar[:, :3], axis=1)))
    tol3d = ref_min_margin / R3 if R3 > 1e-15 else float("inf")

    rows: List[QuantScanRow] = []
    for dp in dp_grid:
        a_q = round(alpha, dp)
        b_q = round(beta, dp)
        e_q = round(eta, dp)
        theta_q_3d = np.array([a_q - alpha, b_q - beta, e_q - eta], dtype=np.float64)
        delta = float(np.linalg.norm(theta_q_3d))
        within = (delta < tol3d)
        theta_q_4d = np.array([a_q, b_q, e_q, 1.0], dtype=np.float64)
        margins = Zbar @ theta_q_4d
        min_m = float(np.min(margins))
        sep_ok = min_m > 0.0
        rows.append(QuantScanRow(
            decimals=int(dp),
            delta_theta_l2=delta,
            within_tolerance=bool(within),
            separation_preserved=bool(sep_ok),
            gap=min_m,
            extra={
                "mode": "multiclass",
                "alpha_q": a_q, "beta_q": b_q, "eta_q": e_q,
                "ref_min_margin": ref_min_margin,
                "tolerance": float(tol3d),
            },
        ))
    return rows


# -----------------------------------------------------------------------------
# Reduce scan rows to a single "minimum safe decimals" integer
# -----------------------------------------------------------------------------
def min_safe_decimals(scan: List[QuantScanRow]) -> int:
    """Return the smallest ``decimals`` in the scan at which separation still
    holds. Returns 0 if no tested level preserves separation.

    NB: rows are expected to be ordered from coarsest (small dp) to finest
    (large dp). The usual outcome is "first few fail, remainder succeed"; we
    return the smallest dp that succeeds.
    """
    for row in scan:
        if row.separation_preserved:
            return int(row.decimals)
    return 0
