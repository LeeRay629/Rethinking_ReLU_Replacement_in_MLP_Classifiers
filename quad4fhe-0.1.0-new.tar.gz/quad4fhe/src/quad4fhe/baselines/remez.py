"""
quad4fhe.baselines.remez — minimax (Remez-iteration) polynomial approximation.

Minimises the L-infinity error against the target activation over the
pre-activation range, yielding the polynomial with the smallest worst-case
error of its degree.
"""
from __future__ import annotations

import numpy as np
from scipy.optimize import linprog

from quad4fhe.baselines._base import _BaseBaseline, activation_numpy


def _polyval_inc(coeffs_inc: np.ndarray, x: np.ndarray) -> np.ndarray:
    return np.polynomial.polynomial.polyval(x, coeffs_inc)


def _initial_chebyshev_points(lo: float, hi: float, n: int) -> np.ndarray:
    k = np.arange(n)
    xs = np.cos(np.pi * k / (n - 1))
    return 0.5 * (lo + hi) + 0.5 * (hi - lo) * xs[::-1]


def _compress_alternating_extrema(err: np.ndarray, cand_idx):
    abs_err = np.abs(err)
    out = []
    for idx in cand_idx:
        s = 1 if err[idx] >= 0 else -1
        if not out:
            out.append(idx)
            continue
        prev = out[-1]
        prev_s = 1 if err[prev] >= 0 else -1
        if s == prev_s:
            if abs_err[idx] > abs_err[prev]:
                out[-1] = idx
        else:
            out.append(idx)
    return out


def fit_remez_minimax(
    Y_ref: np.ndarray,
    degree: int,
    activation: str,
    grid_points: int = 12001,
    max_iter: int = 20,
):
    """Return `(coeffs_desc, poly_fn, max_err, mean_err)`.

    Falls back to a linear-programming minimax fit if Remez fails to converge.
    """
    act_fn = activation_numpy(activation)
    flat = Y_ref.reshape(-1)
    lo, hi = float(np.min(flat)), float(np.max(flat))
    if hi - lo < 1e-12:
        hi = lo + 1e-12
    grid = np.linspace(lo, hi, grid_points)
    act_grid = act_fn(grid)

    n_ext = degree + 2
    x_ext = _initial_chebyshev_points(lo, hi, n_ext)
    prev_ext = None
    coeffs_inc = None

    for _ in range(max_iter):
        y_ext = act_fn(x_ext)
        V = np.vander(x_ext, N=degree + 1, increasing=True)
        alt = ((-1) ** np.arange(n_ext)).reshape(-1, 1)
        A = np.hstack([V, alt])
        try:
            sol = np.linalg.solve(A, y_ext)
        except np.linalg.LinAlgError:
            sol, *_ = np.linalg.lstsq(A, y_ext, rcond=None)
        coeffs_inc = sol[:-1]

        approx_grid = _polyval_inc(coeffs_inc, grid)
        err = act_grid - approx_grid
        abs_err = np.abs(err)

        cand = [0]
        for i in range(1, len(grid) - 1):
            if abs_err[i] >= abs_err[i - 1] and abs_err[i] >= abs_err[i + 1]:
                cand.append(i)
        cand.append(len(grid) - 1)
        cand = sorted(set(cand))
        ext_idx = _compress_alternating_extrema(err, cand)

        if len(ext_idx) < n_ext:
            order = np.argsort(abs_err)[::-1]
            for idx in order:
                idx = int(idx)
                if idx not in ext_idx:
                    ext_idx.append(idx)
                    ext_idx = sorted(ext_idx)
                    ext_idx = _compress_alternating_extrema(err, ext_idx)
                    if len(ext_idx) >= n_ext:
                        break
        while len(ext_idx) > n_ext:
            scores = [abs_err[j] for j in ext_idx]
            ext_idx.pop(int(np.argmin(scores)))

        if len(ext_idx) != n_ext:
            coeffs_inc = None
            break

        x_new = grid[ext_idx]
        if prev_ext is not None and np.max(np.abs(x_new - prev_ext)) < 1e-7:
            x_ext = x_new
            break
        prev_ext = x_ext.copy()
        x_ext = x_new

    if coeffs_inc is None:
        # LP-based minimax fallback
        X_mat = np.vander(grid, N=degree + 1, increasing=True)
        c_obj = np.zeros(degree + 2, dtype=np.float64)
        c_obj[-1] = 1.0
        A_ub = np.vstack([
            np.hstack([X_mat, -np.ones((len(grid), 1))]),
            np.hstack([-X_mat, -np.ones((len(grid), 1))]),
        ])
        b_ub = np.concatenate([act_grid, -act_grid])
        bounds = [(None, None)] * (degree + 1) + [(0.0, None)]
        lp = linprog(c_obj, A_ub=A_ub, b_ub=b_ub, bounds=bounds, method="highs")
        if not lp.success:
            raise RuntimeError(f"Remez LP fallback failed for degree={degree}: {lp.message}")
        coeffs_inc = np.asarray(lp.x[:-1], dtype=np.float64)

    coeffs_desc = coeffs_inc[::-1]
    poly_fn = np.poly1d(coeffs_desc)
    approx_grid = poly_fn(grid)
    max_err = float(np.max(np.abs(approx_grid - act_grid)))
    mean_err = float(np.mean(np.abs(approx_grid - act_grid)))
    return coeffs_desc, poly_fn, max_err, mean_err


class RemezBaseline(_BaseBaseline):
    def __init__(self, degree: int):
        if degree < 1:
            raise ValueError(f"RemezBaseline requires degree >= 1, got {degree}")
        self.degree = int(degree)
        self.name = f"remez_{degree}"
        self._fn = None
        self._coeffs_desc = None

    def fit(self, Y_ref: np.ndarray, activation: str) -> None:
        coeffs_desc, poly_fn, max_err, mean_err = fit_remez_minimax(
            Y_ref, self.degree, activation,
        )
        self._coeffs_desc = coeffs_desc
        self._fn = lambda x: poly_fn(np.asarray(x, dtype=np.float64))
        self.max_err = max_err
        self.mean_err = mean_err
        self.coeffs_info = {
            "kind": "remez",
            "degree": self.degree,
            "coeffs_ascending": [float(v) for v in coeffs_desc[::-1].tolist()],
        }

    def apply(self, Y: np.ndarray) -> np.ndarray:
        return self._fn(Y)
