"""
quad4fhe.baselines — baseline polynomial/piecewise approximations of
ReLU/GELU/SiLU for head-to-head comparison with Quad4FHE.

Every baseline exposes the same uniform interface:

    baseline.evaluate(
        Y_fit, Y_test,
        W2, b2,
        y_fit_ref, y_test_ref,
        y_fit_true, y_test_true,
        orig_logits_fit, orig_logits_test,
        activation, task,
    ) -> dict

where `Y_fit` / `Y_test` are the pre-activation hidden tensors, `W2, b2` are
the output-layer weights (in the folded representation), and `*_ref` labels
are the pseudo-labels taken from the original model's decisions.

The returned dict contains at least:
    max_err, mean_err, coeffs (if polynomial), metrics_test, metrics_vs_pseudo.
"""
from quad4fhe.baselines.ls_poly import LSPolyBaseline
from quad4fhe.baselines.ola import OLABaseline
from quad4fhe.baselines.precise import PreciseReLUBaseline
from quad4fhe.baselines.registry import (
    ALL_BASELINE_NAMES,
    build_baseline,
    expand_baseline_list,
)
from quad4fhe.baselines.remez import RemezBaseline
from quad4fhe.baselines.square import SquareBaseline

__all__ = [
    "SquareBaseline",
    "LSPolyBaseline",
    "RemezBaseline",
    "OLABaseline",
    "PreciseReLUBaseline",
    "build_baseline",
    "ALL_BASELINE_NAMES",
    "expand_baseline_list",
]
