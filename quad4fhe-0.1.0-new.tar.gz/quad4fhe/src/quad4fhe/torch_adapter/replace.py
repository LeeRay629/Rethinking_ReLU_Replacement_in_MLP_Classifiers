"""
quad4fhe.torch_adapter.replace
==============================

Given a trained model and quadratic coefficients, return a deep-copy of the
model with the activation layer swapped for a `QuadraticActivation`. All other
weights (W1, b1, W2, b2, BN statistics, etc.) remain untouched, so forward()
of the returned model produces scores that numerically match the theoretical
quadratic-replacement formula.
"""
from __future__ import annotations

import copy
from typing import Union

import torch.nn as nn

from quad4fhe.torch_adapter.activation import QuadraticActivation
from quad4fhe.torch_adapter.extractor import (
    _collect_ordered_modules,
    _match_activation,
    resolve_module_by_path,
)


def _replace_module_by_ref(root: nn.Module, target: nn.Module, new_module: nn.Module) -> bool:
    """Walk `root.named_modules()` looking for any parent that has `target` as
    a direct child (setattr or indexed-item) and replace it with `new_module`.
    Returns True on success."""
    for _, mod in root.named_modules():
        if mod is target:
            continue
        for child_name, child in mod.named_children():
            if child is target:
                setattr(mod, child_name, new_module)
                return True
    return False


def build_replaced_model(
    original_model: nn.Module,
    alpha: float,
    beta: float,
    eta: float,
    hidden_layer: Union[str, nn.Module],
    output_layer: Union[str, nn.Module],
    activation: Union[str, nn.Module] = "relu",
) -> nn.Module:
    """Return a deep-copy of `original_model` with the specified activation
    replaced by a `QuadraticActivation(alpha, beta, eta)`.

    The hidden / output linear weights, BN statistics, etc. are preserved —
    only the activation nn.Module is swapped. Because `QuadraticActivation`
    is sample-invariant like ReLU, forward() of the returned model should
    numerically match `quadratic_logits_from_QH/QL` up to floating-point
    precision.
    """
    model = copy.deepcopy(original_model)
    model.eval()

    hidden_mod_orig = resolve_module_by_path(original_model, hidden_layer)
    output_mod_orig = resolve_module_by_path(original_model, output_layer)

    # Locate the corresponding modules in the copy, and the activation.
    all_orig = _collect_ordered_modules(original_model)
    all_new = _collect_ordered_modules(model)
    if len(all_orig) != len(all_new):  # pragma: no cover
        raise RuntimeError("deepcopy changed the module count — unexpected.")

    hidden_idx = next((i for i, (_, m) in enumerate(all_orig) if m is hidden_mod_orig), None)
    output_idx = next((i for i, (_, m) in enumerate(all_orig) if m is output_mod_orig), None)
    if hidden_idx is None or output_idx is None:
        raise RuntimeError("Cannot locate layers in deepcopied model.")

    # Find the activation in the original, then use the same index in the copy.
    activation_position = None
    for i in range(hidden_idx + 1, output_idx):
        mod = all_orig[i][1]
        if _match_activation(mod, activation):
            activation_position = i
            break
    if activation_position is None:
        raise RuntimeError(
            "No activation instance found between hidden_layer and output_layer. "
            "Cannot build replaced model."
        )

    target_in_copy = all_new[activation_position][1]
    new_act = QuadraticActivation(alpha=alpha, beta=beta, eta=eta, trainable=False)

    ok = _replace_module_by_ref(model, target_in_copy, new_act)
    if not ok:
        raise RuntimeError(
            f"Failed to replace activation module {type(target_in_copy).__name__} "
            "in the deepcopied model. This typically happens when the activation "
            "is a top-level attribute of a non-standard container; please use a "
            "supported layout (Sequential, or direct .attr on the root module)."
        )
    return model
