"""
quad4fhe.torch_adapter.activation
=================================

Drop-in replacement `nn.Module` that computes

    p(x) = alpha * x^2 + beta * x + eta.

Designed to replace ReLU / GELU / SiLU in a trained model *at inference time*
(no retraining). The coefficients are fixed `float` attributes — not
`nn.Parameter`s — by default, to make it clear they should not be updated
by an optimizer. Pass ``trainable=True`` if you want to fine-tune them.
"""
from __future__ import annotations

import torch
import torch.nn as nn


class QuadraticActivation(nn.Module):
    """Polynomial activation p(x) = alpha * x^2 + beta * x + eta.

    Parameters
    ----------
    alpha, beta, eta : float
        Coefficients returned by `quad4fhe.replace(...)`.
    trainable : bool, default False
        If True, wrap (alpha, beta, eta) as `nn.Parameter`s so they are
        updated by an optimizer. Defaults to False (frozen) because the
        whole point of this library is to avoid retraining.
    """

    def __init__(self, alpha: float, beta: float, eta: float, trainable: bool = False):
        super().__init__()
        if trainable:
            self.alpha = nn.Parameter(torch.tensor(float(alpha)))
            self.beta = nn.Parameter(torch.tensor(float(beta)))
            self.eta = nn.Parameter(torch.tensor(float(eta)))
        else:
            self.register_buffer("alpha", torch.tensor(float(alpha)))
            self.register_buffer("beta", torch.tensor(float(beta)))
            self.register_buffer("eta", torch.tensor(float(eta)))
        self._trainable = trainable

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.alpha * x * x + self.beta * x + self.eta

    def extra_repr(self) -> str:
        a = float(self.alpha)
        b = float(self.beta)
        e = float(self.eta)
        return f"alpha={a:+.6g}, beta={b:+.6g}, eta={e:+.6g}, trainable={self._trainable}"

    def coefficients(self):
        """Return (alpha, beta, eta) as Python floats."""
        return float(self.alpha), float(self.beta), float(self.eta)
