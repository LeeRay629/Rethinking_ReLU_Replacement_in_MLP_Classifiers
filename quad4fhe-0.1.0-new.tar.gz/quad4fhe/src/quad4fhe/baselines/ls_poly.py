"""
quad4fhe.baselines.ls_poly — least-squares polynomial fit to the activation
over a grid covering the pre-activation range.
"""
from __future__ import annotations

import numpy as np

from quad4fhe.baselines._base import _BaseBaseline, activation_error, activation_numpy


class LSPolyBaseline(_BaseBaseline):
    """Least-squares polynomial approximation of a given degree."""
    def __init__(self, degree: int):
        if degree < 1:
            raise ValueError(f"LSPolyBaseline requires degree >= 1, got {degree}")
        self.degree = int(degree)
        self.name = f"ls_poly_{degree}"
        self._coeffs_desc = None                 # np.poly1d convention
        self._fn = None

    def fit(self, Y_ref: np.ndarray, activation: str) -> None:
        act_fn = activation_numpy(activation)
        flat = np.asarray(Y_ref, dtype=np.float64).reshape(-1)
        lo, hi = float(np.min(flat)), float(np.max(flat))
        if hi - lo < 1e-12:
            hi = lo + 1e-12
        grid = np.linspace(lo, hi, 30000)
        self._coeffs_desc = np.polyfit(grid, act_fn(grid), self.degree)
        poly = np.poly1d(self._coeffs_desc)
        self._fn = lambda x: poly(np.asarray(x, dtype=np.float64))
        self.max_err, self.mean_err = activation_error(self._fn, Y_ref, activation)
        self.coeffs_info = {
            "kind": "ls_poly",
            "degree": self.degree,
            "coeffs_ascending": [float(v) for v in self._coeffs_desc[::-1].tolist()],
        }

    def apply(self, Y: np.ndarray) -> np.ndarray:
        return self._fn(Y)
