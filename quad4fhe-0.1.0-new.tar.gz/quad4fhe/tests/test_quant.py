"""Unit tests for `quad4fhe.quant`."""
import numpy as np

from quad4fhe.quant import (
    DEFAULT_DP_GRID,
    min_safe_decimals,
    scan_quantization_binary,
    scan_quantization_multiclass,
)
from quad4fhe.result import QuantScanRow


def test_scan_binary_returns_rows_in_dp_order():
    rng = np.random.default_rng(0)
    S_plus = rng.standard_normal((20, 2)) + np.array([5.0, 0.0])
    S_minus = rng.standard_normal((20, 2)) + np.array([-5.0, 0.0])
    rows = scan_quantization_binary(
        alpha=0.123456, beta=0.987654, eta=0.0,
        S_plus=S_plus, S_minus=S_minus,
    )
    assert len(rows) == len(DEFAULT_DP_GRID)
    # dp should be strictly increasing
    for r1, r2 in zip(rows, rows[1:]):
        assert r2.decimals > r1.decimals
    # delta should be non-increasing as dp increases (finer rounding)
    for r1, r2 in zip(rows, rows[1:]):
        assert r2.delta_theta_l2 <= r1.delta_theta_l2 + 1e-12


def test_scan_binary_at_high_dp_preserves_separation():
    """If theta_star strictly separates the clusters, then at dp=7 the
    rounded theta must still separate them."""
    rng = np.random.default_rng(0)
    S_plus = rng.standard_normal((20, 2)) + np.array([5.0, 0.0])
    S_minus = rng.standard_normal((20, 2)) + np.array([-5.0, 0.0])
    # theta = (1.0, 0.0) strictly separates these clusters along x-axis.
    rows = scan_quantization_binary(
        alpha=1.0, beta=0.0, eta=0.0,
        S_plus=S_plus, S_minus=S_minus,
    )
    # At 7 decimals, separation should hold
    assert rows[-1].separation_preserved


def test_min_safe_decimals_picks_first_success():
    scan = [
        QuantScanRow(decimals=1, delta_theta_l2=0.1, within_tolerance=False,
                     separation_preserved=False, gap=-0.1),
        QuantScanRow(decimals=2, delta_theta_l2=0.01, within_tolerance=False,
                     separation_preserved=True,  gap=0.05),
        QuantScanRow(decimals=3, delta_theta_l2=0.001, within_tolerance=True,
                     separation_preserved=True,  gap=0.08),
    ]
    assert min_safe_decimals(scan) == 2


def test_min_safe_decimals_zero_when_none_succeed():
    scan = [
        QuantScanRow(decimals=d, delta_theta_l2=1.0, within_tolerance=False,
                     separation_preserved=False, gap=-0.5)
        for d in [1, 2, 3]
    ]
    assert min_safe_decimals(scan) == 0


def test_scan_multiclass_produces_rows():
    rng = np.random.default_rng(0)
    Zbar = np.abs(rng.standard_normal((50, 4))) + 0.3
    rows = scan_quantization_multiclass(alpha=0.5, beta=0.8, eta=0.1, Zbar=Zbar)
    assert len(rows) == len(DEFAULT_DP_GRID)
    for r in rows:
        assert "alpha_q" in r.extra
        assert "beta_q" in r.extra
        assert "eta_q" in r.extra
