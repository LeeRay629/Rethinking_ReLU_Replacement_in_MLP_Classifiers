"""
Example 03: Frozen backbone + linear head.

Demonstrates the `backbone=...` kwarg of `quad4fhe.replace`. This is the
common setup for DINOv2 / CLIP / ResNet-style transfer learning: a frozen
feature extractor followed by a small trainable classification head.

Two usage patterns are shown:
    (A) Pre-extract features once, call replace on head-only model
        with (features, labels) as fit_data. Simpler and faster.
    (B) Keep the full model intact and pass backbone=<ref>; quad4fhe runs
        the backbone internally. Slower but more convenient when you want
        the returned replaced_model to be a drop-in for the full pipeline.

Run:
    python examples/03_frozen_backbone.py
"""
import numpy as np
import torch
import torch.nn as nn
from sklearn.datasets import make_classification
from sklearn.model_selection import train_test_split

import quad4fhe


# ---------------------------------------------------------------------------
# 1. Build a (fake) backbone + head
# ---------------------------------------------------------------------------
X, y = make_classification(
    n_samples=1200, n_features=64, n_informative=32,
    n_classes=8, n_clusters_per_class=1, class_sep=1.5, random_state=42,
)
X_tr, X_te, y_tr, y_te = train_test_split(X, y, test_size=0.25,
                                          stratify=y, random_state=42)

torch.manual_seed(0)
# Simulated frozen DINOv2: 64 -> 32
backbone = nn.Sequential(nn.Linear(64, 32), nn.Tanh())
for p in backbone.parameters():
    p.requires_grad = False


class Head(nn.Module):
    def __init__(self, d, h, k):
        super().__init__()
        self.fc1 = nn.Linear(d, h)
        self.act = nn.ReLU()
        self.fc2 = nn.Linear(h, k)
    def forward(self, x):
        return self.fc2(self.act(self.fc1(x)))


class FullModel(nn.Module):
    def __init__(self):
        super().__init__()
        self.backbone = backbone
        self.head = Head(32, 64, 8)
    def forward(self, x):
        return self.head(self.backbone(x))


model = FullModel()
opt = torch.optim.Adam(model.head.parameters(), lr=5e-3)
ce = nn.CrossEntropyLoss()

X_tr_t = torch.tensor(X_tr, dtype=torch.float32)
y_tr_t = torch.tensor(y_tr, dtype=torch.long)
print("Training the classification head ...")
for epoch in range(200):
    model.train()
    opt.zero_grad()
    loss = ce(model(X_tr_t), y_tr_t)
    loss.backward()
    opt.step()
model.eval()
with torch.no_grad():
    base_preds = model(torch.tensor(X_te, dtype=torch.float32)).argmax(dim=-1).numpy()
base_acc = float(np.mean(base_preds == y_te))
print(f"Baseline full-model test accuracy: {base_acc:.4f}")


# ---------------------------------------------------------------------------
# Pattern (A): pre-extract features and replace a head-only model
# ---------------------------------------------------------------------------
print("\n" + "=" * 78)
print("Pattern (A): pre-extract features, replace head only")
print("=" * 78)

with torch.no_grad():
    feats_tr = backbone(X_tr_t).numpy().astype(np.float64)
    feats_te = backbone(torch.tensor(X_te, dtype=torch.float32)).numpy().astype(np.float64)

result_A = quad4fhe.replace(
    task="multiclass",
    model=model.head,                     # pass the head only
    hidden_layer="fc1", output_layer="fc2", activation="relu",
    fit_data=(feats_tr, y_tr),
    test_data=(feats_te, y_te),
    verbose=False,
)
rm_A = result_A.replaced_model.eval()
with torch.no_grad():
    preds_A = rm_A(torch.tensor(feats_te, dtype=torch.float32)).argmax(dim=-1).numpy()
acc_A = float(np.mean(preds_A == y_te))
print(f"Pattern (A) test accuracy: {acc_A:.4f}   "
      f"(backbone ran once; returned module works on features)")


# ---------------------------------------------------------------------------
# Pattern (B): pass backbone=<ref>; replaced_model accepts raw inputs
# ---------------------------------------------------------------------------
print("\n" + "=" * 78)
print("Pattern (B): backbone=<ref>; replaced_model accepts raw inputs")
print("=" * 78)

result_B = quad4fhe.replace(
    task="multiclass",
    model=model,                            # pass the FULL model
    backbone=model.backbone,                # but specify backbone explicitly
    hidden_layer="head.fc1",                # dotted-path spec
    output_layer="head.fc2",
    activation="relu",
    fit_data=(X_tr, y_tr),                  # raw inputs
    test_data=(X_te, y_te),
    verbose=False,
)
rm_B = result_B.replaced_model.eval()
with torch.no_grad():
    preds_B = rm_B(torch.tensor(X_te, dtype=torch.float32)).argmax(dim=-1).numpy()
acc_B = float(np.mean(preds_B == y_te))
print(f"Pattern (B) test accuracy: {acc_B:.4f}   "
      f"(returned module is drop-in for the full pipeline)")

# Both patterns should produce identical replacements
print(f"\nalpha, beta, eta match: "
      f"{np.allclose([result_A.alpha, result_A.beta, result_A.eta], [result_B.alpha, result_B.beta, result_B.eta])}")
