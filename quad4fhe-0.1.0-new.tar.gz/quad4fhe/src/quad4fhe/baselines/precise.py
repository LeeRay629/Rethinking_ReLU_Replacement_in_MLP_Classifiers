"""
quad4fhe.baselines.precise — Precise Approximation of ReLU (alpha=11)
following the "Precise Approximation" line of work.

Evaluates a composition of three polynomials p1, p2, p3 on the normalised
input z = x / B, then returns 0.5 * (x + x * p3(p2(p1(z)))).

Only applicable for ReLU. `build_baseline` logs a warning and returns None
for other activations.
"""
from __future__ import annotations

import numpy as np

from quad4fhe.baselines._base import _BaseBaseline, activation_error

# Coefficient tables (from Lee et al., "Precise Approximation" paper)
_P1 = np.zeros(8, dtype=np.float64)
_P1[1] = 1.12590667402954e1
_P1[3] = -6.54692933329973e1
_P1[5] = 1.20694634277757e2
_P1[7] = -6.64019695377825e1

_P2 = np.zeros(8, dtype=np.float64)
_P2[1] = 4.70477624210883
_P2[3] = -6.79884851596681
_P2[5] = 3.31525104382873
_P2[7] = -4.89362936859897e-1

_P3 = np.zeros(28, dtype=np.float64)
_P3[1]  =  5.36334257654953
_P3[3]  = -3.55169555441962e1
_P3[5]  =  1.77807304115644e2
_P3[7]  = -5.92297395415024e2
_P3[9]  =  1.34891691889362e3
_P3[11] = -2.15876445084938e3
_P3[13] =  2.47365685586918e3
_P3[15] = -2.04913542536248e3
_P3[17] =  1.22739317090559e3
_P3[19] = -5.25826175134002e2
_P3[21] =  1.56930558712840e2
_P3[23] = -3.09658595645912e1
_P3[25] =  3.62894000814968
_P3[27] = -1.91160283749939e-1


def _polyval_inc(coeffs_inc: np.ndarray, x: np.ndarray) -> np.ndarray:
    return np.polynomial.polynomial.polyval(x, coeffs_inc)


def _precise_relu(x: np.ndarray, B: float, clip: bool = True) -> np.ndarray:
    B = max(float(B), 1e-8)
    x_arr = np.asarray(x, dtype=np.float64)
    z = x_arr / B
    if clip:
        z = np.clip(z, -1.0, 1.0)
    p1 = _polyval_inc(_P1, z)
    p2 = _polyval_inc(_P2, p1)
    p3 = _polyval_inc(_P3, p2)
    return 0.5 * (x_arr + x_arr * p3)


class PreciseReLUBaseline(_BaseBaseline):
    """Precise Approximation (alpha=11) for ReLU."""
    name = "precise_a11"

    def __init__(self, alpha: int = 11, clip: bool = True):
        if alpha != 11:
            raise ValueError("Only alpha=11 coefficients are bundled currently.")
        self.alpha = alpha
        self.clip = clip
        self.B = None

    def fit(self, Y_ref: np.ndarray, activation: str) -> None:
        if activation.lower() != "relu":
            raise ValueError("PreciseReLUBaseline only supports activation='relu'.")
        flat = Y_ref.reshape(-1)
        self.B = max(float(np.max(np.abs(flat))), 1e-8)
        self._fn = lambda x: _precise_relu(x, B=self.B, clip=self.clip)
        self.max_err, self.mean_err = activation_error(self._fn, Y_ref, activation)
        self.coeffs_info = {
            "kind": "precise_a11",
            "B": self.B, "clip": self.clip,
            # Note: this is NOT a simple polynomial — it's a 3-level composition.
            # We do not emit "coeffs_ascending" here; HE export treats this as a
            # custom opcode.
        }

    def apply(self, Y: np.ndarray) -> np.ndarray:
        return self._fn(Y)
