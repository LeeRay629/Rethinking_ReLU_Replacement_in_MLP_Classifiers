"""
quad4fhe — Exact and robust quadratic activation substitution for privacy-preserving
neural-network inference.

Top-level public API:
    quad4fhe.replace(...)                   # one-line end-to-end pipeline
    quad4fhe.ReplacementResult              # result dataclass
    quad4fhe.QuadraticActivation            # drop-in nn.Module activation
    quad4fhe.export_he_artifacts(...)       # HE-ready artifact export
    quad4fhe.UnsupportedLayerError          # raised for non-standard structures
"""
from quad4fhe.api import replace
from quad4fhe.export import export_he_artifacts
from quad4fhe.result import ReplacementResult
from quad4fhe.torch_adapter.activation import QuadraticActivation
from quad4fhe.torch_adapter.extractor import UnsupportedLayerError

__version__ = "0.1.0"

__all__ = [
    "replace",
    "ReplacementResult",
    "QuadraticActivation",
    "UnsupportedLayerError",
    "export_he_artifacts",
    "__version__",
]
