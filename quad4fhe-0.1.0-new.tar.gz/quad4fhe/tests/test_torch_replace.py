"""Unit tests for `quad4fhe.torch_adapter.activation` and `.replace`."""
import numpy as np
import pytest
import torch
import torch.nn as nn

from quad4fhe.torch_adapter.activation import QuadraticActivation
from quad4fhe.torch_adapter.replace import build_replaced_model


class ToyMLP(nn.Module):
    def __init__(self, d, h, k):
        super().__init__()
        self.fc1 = nn.Linear(d, h)
        self.act = nn.ReLU()
        self.fc2 = nn.Linear(h, k)
    def forward(self, x):
        return self.fc2(self.act(self.fc1(x)))


# -----------------------------------------------------------------------------
# QuadraticActivation
# -----------------------------------------------------------------------------
def test_quadratic_activation_forward():
    q = QuadraticActivation(alpha=0.5, beta=1.0, eta=-0.3)
    x = torch.tensor([-2.0, -1.0, 0.0, 1.0, 2.0])
    expected = 0.5 * x ** 2 + 1.0 * x + (-0.3)
    out = q(x)
    np.testing.assert_allclose(out.detach().numpy(), expected.numpy(), atol=1e-7)


def test_quadratic_activation_default_is_frozen():
    q = QuadraticActivation(0.1, 0.5, 0.0)
    # Buffers, not parameters
    assert len(list(q.parameters())) == 0


def test_quadratic_activation_trainable_flag():
    q = QuadraticActivation(0.1, 0.5, 0.0, trainable=True)
    params = list(q.parameters())
    assert len(params) == 3          # alpha, beta, eta


def test_quadratic_activation_coefficients_accessor():
    q = QuadraticActivation(0.1, 0.5, -0.2)
    a, b, e = q.coefficients()
    assert a == pytest.approx(0.1)
    assert b == pytest.approx(0.5)
    assert e == pytest.approx(-0.2)


# -----------------------------------------------------------------------------
# build_replaced_model
# -----------------------------------------------------------------------------
def test_build_replaced_model_swaps_activation():
    torch.manual_seed(0)
    m = ToyMLP(5, 8, 3).eval()
    replaced = build_replaced_model(
        m, alpha=0.1, beta=0.9, eta=0.05,
        hidden_layer="fc1", output_layer="fc2", activation="relu",
    )
    # Quad should have replaced ReLU
    assert isinstance(replaced.act, QuadraticActivation)
    # Original is untouched
    assert isinstance(m.act, nn.ReLU)


def test_replaced_model_forward_equals_manual_quadratic():
    torch.manual_seed(0)
    m = ToyMLP(5, 8, 3).eval()
    alpha, beta, eta = 0.3, 0.8, 0.0
    replaced = build_replaced_model(
        m, alpha=alpha, beta=beta, eta=eta,
        hidden_layer="fc1", output_layer="fc2", activation="relu",
    ).eval()

    x = torch.randn(7, 5)
    with torch.no_grad():
        out_replaced = replaced(x).numpy()
        pre = m.fc1(x)
        manual = m.fc2(alpha * pre ** 2 + beta * pre + eta).numpy()
    np.testing.assert_allclose(out_replaced, manual, atol=1e-5)


def test_replaced_model_independent_from_original():
    """Modifying the replaced model's weights must not affect the original."""
    torch.manual_seed(0)
    m = ToyMLP(5, 8, 3).eval()
    replaced = build_replaced_model(
        m, 0.1, 0.9, 0.0, "fc1", "fc2", "relu",
    )
    with torch.no_grad():
        replaced.fc1.weight.zero_()
    assert not torch.allclose(m.fc1.weight, replaced.fc1.weight)
