# quad4fhe

**Exact & robust quadratic activation substitution for privacy-preserving neural-network inference.**

`quad4fhe` implements the theory of *empirically lossless quadratic replacement of ReLU-class
activations*, designed for Fully Homomorphic Encryption (FHE) and Multi-Party Computation
(MPC) pipelines where non-polynomial activations are either unsupported or prohibitively
expensive.

Unlike prior work that minimises *pointwise* approximation error of the activation
function and then retrains the network, `quad4fhe` directly solves a **convex geometric
problem** in the lifted (Q, H) space (binary) or the 4-dimensional pairwise-difference
space (multi-class). The resulting `(alpha, beta, eta)` triple replaces the original
activation **at inference time, without any retraining**, and—when the geometric
feasibility condition is satisfied—preserves the original model's decisions on the
training set exactly.

## Key features

- **One-line replacement.** `quad4fhe.replace(...)` takes a trained PyTorch model and a
  fit dataset, and returns both the quadratic coefficients and a drop-in
  `nn.Module` replacement.
- **Exact & robust modes.** Hard-margin (exact lossless, Theorems 1–3) with automatic
  fallback to Reduced-Convex-Hull (Theorem 4) and primal/dual QP (Theorem 5).
- **Single-hidden-layer & frozen-backbone.** Works on both plain MLPs and pretrained
  feature extractors (e.g. DINOv2 + custom head).
- **Binary & multi-class.** Proposition 2.6 for multi-class (hard/soft-margin QP) with
  cutting-plane and OSQP warm-start acceleration for large-K problems.
- **Automatic BatchNorm folding.** BN layers between the hidden and output layer are
  folded into effective weights before the theory is applied.
- **Quantization robustness scan.** Reports the smallest number of decimal places at
  which the rounded coefficients still satisfy the empirical separation condition.
- **Baseline zoo.** Ships Square / LS-Poly / Remez / OLA / Precise-Approximation baselines
  for head-to-head comparison.
- **HE-ready artifact export.** Dumps plain `.bin` + `meta.json` for direct C++
  SEAL/CKKS consumption.

## Installation

```bash
pip install quad4fhe
# optional accelerators
pip install 'quad4fhe[fast]'   # cvxpy + osqp
```

## Quick start

```python
import quad4fhe
import torch

# your trained model
model = MyMLP()              # has .fc1 (Linear), ReLU, .fc2 (Linear)
model.load_state_dict(torch.load("mymlp.pt"))
model.eval()

result = quad4fhe.replace(
    task            = "binary",
    model           = model,
    hidden_layer    = "fc1",
    output_layer    = "fc2",
    activation      = "relu",
    fit_data        = (X_train, y_train),     # y_train is used only for reporting
    test_data       = (X_test, y_test),
    baselines       = ["remez_2", "ls_poly_2", "ola"],
    export_he_dir   = "he_out/",
    verbose         = True,
)

print(f"alpha = {result.alpha:.6f}")
print(f"beta  = {result.beta:.6f}")
print(f"eta   = {result.eta:.6f}")
print(f"threshold = {result.threshold:.6f}")
print(f"minimum safe decimal places = {result.quant_decimals}")

# drop-in replacement
logits = result.replaced_model(X_test_tensor)
preds  = (logits > result.threshold).long()

# evaluation tables
print(result.report_vs_pseudo)   # agreement with original ReLU model
print(result.report_vs_truth)    # accuracy against ground-truth labels
```

## API layers

The library is organised in three layers, from low to high:

| Layer              | Module                       | Purpose                                                |
|--------------------|------------------------------|--------------------------------------------------------|
| Core (NumPy only)  | `quad4fhe.core.*`            | Lifting, convex geometry, QP solvers                   |
| PyTorch adapter    | `quad4fhe.torch_adapter.*`   | Parameter extraction, BN fold, `QuadraticActivation`   |
| High-level         | `quad4fhe.replace(...)`      | End-to-end pipeline: fit → replace → export → report   |

Researchers who only need the pure convex-geometry pieces can use
`quad4fhe.core` directly without any PyTorch dependency.

## Supported model structures

Between `hidden_layer` and `output_layer`, the following module types are recognised:

| Module             | Behaviour                                         |
|--------------------|---------------------------------------------------|
| `nn.Linear`        | Extracted as W1/b1 (hidden) or W2/b2 (output)     |
| `nn.BatchNorm1d`   | Folded into W1_eff, b1_eff automatically          |
| `nn.Dropout*`      | Ignored (identity in eval mode)                   |
| `nn.Identity`      | Ignored                                           |
| `nn.ReLU/GELU/SiLU`| Marked as the activation to be replaced           |
| **Anything else**  | `UnsupportedLayerError` — use the `extractor` hook|

`nn.LayerNorm` is **not** auto-folded (sample-dependent statistics). For unusual
architectures, pass a custom `extractor=...` function.

## Citation

If you use this library in academic work, please cite:

```bibtex
@inproceedings{quad4fhe2026,
    title  = {Exact and Robust Quadratic Activation Substitution for Privacy-Preserving Neural-Network Inference},
    author = {...},
    booktitle = {CCS},
    year   = {2026},
}
```

## License

MIT License — see `LICENSE`.
