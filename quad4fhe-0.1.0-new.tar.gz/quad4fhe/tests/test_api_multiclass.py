"""End-to-end integration test for `quad4fhe.replace` on a multi-class task."""
import numpy as np
import torch

import quad4fhe
from tests.fixtures import (
    MLPWithBN,
    SimpleMulticlassMLP,
    make_multiclass_dataset,
    train_model,
)


def test_multiclass_pipeline_end_to_end():
    X_tr, X_te, y_tr, y_te = make_multiclass_dataset(n_classes=4, seed=42)
    model = SimpleMulticlassMLP(in_dim=X_tr.shape[1], hidden_dim=24, num_classes=4)
    model = train_model(model, X_tr, y_tr, task="multiclass", epochs=150, lr=5e-3)

    res = quad4fhe.replace(
        task="multiclass", model=model,
        hidden_layer="fc1", output_layer="fc2", activation="relu",
        fit_data=(X_tr, y_tr),
        test_data=(X_te, y_te),
        baselines=["square", "remez_2"],
        verbose=False,
    )

    assert np.isfinite(res.alpha)
    assert np.isfinite(res.beta)
    assert np.isfinite(res.eta)
    assert res.threshold is None          # no threshold for multi-class
    assert res.replaced_model is not None
    assert res.report_vs_pseudo is not None

    # Drop-in module matches theory
    from quad4fhe.core.lifting import (
        build_pairwise_lifted_constraints,
        quadratic_logits_from_QL,
    )
    rm = res.replaced_model.eval()
    with torch.no_grad():
        logits_module = rm(torch.tensor(X_te, dtype=torch.float32)).cpu().numpy()
    _, _, _, Q, L, B = build_pairwise_lifted_constraints(
        X_te, res.W1, res.b1, res.W2, res.b2,
        np.zeros(len(X_te), dtype=np.int64),
    )
    logits_theory = quadratic_logits_from_QL(
        Q, L, res.alpha, res.beta, res.eta, B, res.b2,
    )
    diff = float(np.max(np.abs(logits_module - logits_theory)))
    assert diff < 1e-3, f"Multi-class drop-in mismatch: {diff}"


def test_multiclass_with_bn_fold():
    """Verify that a model with BN produces a correctly-folded replacement."""
    X_tr, X_te, y_tr, y_te = make_multiclass_dataset(n_classes=3, seed=7)
    model = MLPWithBN(in_dim=X_tr.shape[1], hidden_dim=32, num_classes=3)
    # Train to get meaningful BN statistics
    model = train_model(model, X_tr, y_tr, task="multiclass", epochs=200, lr=5e-3)

    res = quad4fhe.replace(
        task="multiclass", model=model,
        hidden_layer="fc1", output_layer="fc2", activation="relu",
        fit_data=(X_tr, y_tr),
        test_data=(X_te, y_te),
        verbose=False,
    )

    # Drop-in must still match theory even with the BN fold
    from quad4fhe.core.lifting import (
        build_pairwise_lifted_constraints,
        quadratic_logits_from_QL,
    )
    rm = res.replaced_model.eval()
    with torch.no_grad():
        logits_module = rm(torch.tensor(X_te, dtype=torch.float32)).cpu().numpy()
    _, _, _, Q, L, B = build_pairwise_lifted_constraints(
        X_te, res.W1, res.b1, res.W2, res.b2,
        np.zeros(len(X_te), dtype=np.int64),
    )
    logits_theory = quadratic_logits_from_QL(Q, L, res.alpha, res.beta, res.eta, B, res.b2)
    diff = float(np.max(np.abs(logits_module - logits_theory)))
    assert diff < 1e-3, f"BN-folded drop-in mismatch: {diff}"
