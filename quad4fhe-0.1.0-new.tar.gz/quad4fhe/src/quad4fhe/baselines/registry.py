"""
quad4fhe.baselines.registry
===========================

Name-based dispatch of baseline instances, supporting flexible names like:

    "square", "ls_poly_2", "remez_7", "ola", "precise_a11"

and the special name ``"all"`` which expands to the full list.
"""
from __future__ import annotations

import re
import warnings
from typing import List, Union

ALL_BASELINE_NAMES = [
    "square",
    "ls_poly_2", "ls_poly_3", "ls_poly_5", "ls_poly_7",
    "remez_2", "remez_3", "remez_5", "remez_7",
    "ola",
    "precise_a11",
]


def expand_baseline_list(
    baselines: Union[None, str, List[str]],
) -> List[str]:
    """Normalise the user's `baselines` argument to an explicit list of names.

    Supports: None → [], "all" → ALL_BASELINE_NAMES, a single string, or an
    explicit list. Names are case-insensitive and stripped.
    """
    if baselines is None:
        return []
    if isinstance(baselines, str):
        if baselines.lower() == "all":
            return list(ALL_BASELINE_NAMES)
        baselines = [baselines]
    return [str(n).strip().lower() for n in baselines]


def build_baseline(name: str, activation: str):
    """Instantiate a baseline object from its string name.

    Names follow these patterns:
        "square"        -> SquareBaseline
        "ls_poly_<D>"   -> LSPolyBaseline(degree=D)
        "remez_<D>"     -> RemezBaseline(degree=D)
        "ola"           -> OLABaseline()
        "precise_a11"   -> PreciseReLUBaseline() (ReLU only)
    """
    from quad4fhe.baselines.ls_poly import LSPolyBaseline
    from quad4fhe.baselines.ola import OLABaseline
    from quad4fhe.baselines.precise import PreciseReLUBaseline
    from quad4fhe.baselines.remez import RemezBaseline
    from quad4fhe.baselines.square import SquareBaseline

    name = name.strip().lower()
    if name == "square":
        return SquareBaseline()
    m = re.match(r"^ls_poly_(\d+)$", name)
    if m:
        return LSPolyBaseline(degree=int(m.group(1)))
    m = re.match(r"^remez_(\d+)$", name)
    if m:
        return RemezBaseline(degree=int(m.group(1)))
    if name == "ola":
        return OLABaseline()
    if name.startswith("precise_a"):
        if activation.lower() != "relu":
            warnings.warn(
                f"Baseline '{name}' is only defined for ReLU; "
                f"skipping (current activation='{activation}').",
                RuntimeWarning,
                stacklevel=2,
            )
            return None
        return PreciseReLUBaseline()
    raise ValueError(f"Unknown baseline name '{name}'. "
                     f"Supported: {ALL_BASELINE_NAMES} or 'all'.")
