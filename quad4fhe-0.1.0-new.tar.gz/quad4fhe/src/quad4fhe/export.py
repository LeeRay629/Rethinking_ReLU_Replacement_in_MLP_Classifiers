"""
quad4fhe.export
===============

Dump a self-contained set of artifacts that a C++ SEAL / CKKS / MPC front-end
can load with no Python dependency:

    # --- model weights (shared by all schemes) ---
    W1.bin              H*d   float64 (row-major)
    b1.bin              H     float64
    w2.bin              H     float64                       (binary)
    W2.bin              K*H   float64                       (multiclass)
    b2.bin              1     float64                       (binary)
                        K     float64                       (multiclass)

    # --- test set + ground truth ---
    X_test.bin          N*d   float64 (already StandardScaler-ed, if any)
    y_test_true.bin     N     int32   (ground truth)
    y_test_relu.bin     N     int32   (original ReLU decisions = pseudo labels)
    relu_logits_test.bin                                    (binary:  N     float64)
                                                            (multi :  N*K   float64)

    # --- one pair of files per scheme ---
    coeffs_<name>.bin       float64 ascending
    logits_<name>.bin       N   float64    (binary)
                            N*K float64    (multiclass)

    # --- optional: StandardScaler stats for downstream un-scaling ---
    scaler_mean.bin         d   float64   (present iff scaler_mean given)
    scaler_scale.bin        d   float64

    # --- manifests ---
    schemes.txt   one non-comment line per scheme
    meta.txt      key-value, parseable in C++ with `>>`
    meta.json     the same, but human-readable and richer
"""
from __future__ import annotations

import json
import os
from typing import Any, Dict, List, Optional, Sequence, Union

import numpy as np


def _to_ascending(coeffs: Sequence[float], degree: int) -> np.ndarray:
    c = np.asarray(coeffs, dtype=np.float64).reshape(-1)
    if c.size != degree + 1:
        raise ValueError(f"Coefficient length {c.size} != degree+1 = {degree + 1}")
    return c


def _write_float64(arr: np.ndarray, path: str) -> None:
    np.ascontiguousarray(arr, dtype=np.float64).tofile(path)


def _write_int32(arr: np.ndarray, path: str) -> None:
    np.ascontiguousarray(arr, dtype=np.int32).tofile(path)


def export_he_artifacts(
    out_dir: str,
    *,
    # --- task ---
    task: str,                                       # "binary" or "multiclass"
    # --- folded model weights ---
    W1: np.ndarray, b1: np.ndarray,
    W2: np.ndarray, b2: Union[float, np.ndarray],
    # --- test set ---
    X_test: np.ndarray,
    y_test_true: np.ndarray,
    relu_pred_test: np.ndarray,                       # N int32: original-model top-1
    relu_logits_test: np.ndarray,                     # binary: (N,), multi: (N, K)
    # --- schemes (Quad4FHE + any baselines the caller wants to ship) ---
    schemes: List[Dict[str, Any]],
    # --- optional metadata ---
    relu_threshold: float = 0.0,                      # binary only
    scaler_mean: Optional[np.ndarray] = None,
    scaler_scale: Optional[np.ndarray] = None,
    input_kind: str = "scaled_features",              # "raw" | "scaled_features" | "backbone_output"
    verbose: bool = False,
) -> str:
    """Write all artifacts under ``out_dir``. Returns the absolute directory
    path. Creates the directory if it does not exist.

    Each scheme dict in ``schemes`` must have:
        - name (str, filesystem-safe, no whitespace)
        - display_name (str, optional)
        - degree (int)
        - coeffs (array-like, length degree+1)
        - coeffs_order ("ascending" | "descending", default "ascending")
        - threshold (float; binary only, ignored for multi-class)
        - logits_test (binary: (N,); multi: (N, K))
        - notes (str, optional)
    """
    if task not in ("binary", "multiclass"):
        raise ValueError(f"task must be 'binary' or 'multiclass', got '{task}'")

    os.makedirs(out_dir, exist_ok=True)
    out_dir = os.path.abspath(out_dir)

    W1 = np.ascontiguousarray(W1, dtype=np.float64)
    b1 = np.ascontiguousarray(np.asarray(b1).reshape(-1), dtype=np.float64)
    X_test = np.ascontiguousarray(X_test, dtype=np.float64)
    y_test_true = np.ascontiguousarray(np.asarray(y_test_true).reshape(-1), dtype=np.int32)
    relu_pred_test = np.ascontiguousarray(np.asarray(relu_pred_test).reshape(-1), dtype=np.int32)

    H, d = W1.shape
    N = X_test.shape[0]

    # ------------------------------------------------------------------
    # Shape checks
    # ------------------------------------------------------------------
    if b1.shape[0] != H:
        raise ValueError("b1 length != H")
    if X_test.shape[1] != d:
        raise ValueError("X_test has wrong feature dim")
    if y_test_true.shape[0] != N:
        raise ValueError("y_test_true length mismatch")
    if relu_pred_test.shape[0] != N:
        raise ValueError("relu_pred_test length mismatch")

    if task == "binary":
        w2 = np.asarray(W2, dtype=np.float64).reshape(-1)
        if w2.shape[0] != H:
            raise ValueError("w2 length != H")
        b2_scalar = float(np.asarray(b2).reshape(-1)[0])
        relu_logits_test = np.ascontiguousarray(
            np.asarray(relu_logits_test).reshape(-1), dtype=np.float64,
        )
        if relu_logits_test.shape[0] != N:
            raise ValueError("relu_logits_test length mismatch")
        num_classes = None
    else:
        W2_arr = np.asarray(W2, dtype=np.float64)
        if W2_arr.ndim != 2 or W2_arr.shape[1] != H:
            raise ValueError(f"For multiclass, W2 must be (K, H); got {W2_arr.shape}")
        K = W2_arr.shape[0]
        b2_vec = np.asarray(b2, dtype=np.float64).reshape(-1)
        if b2_vec.shape[0] != K:
            raise ValueError(f"For multiclass, b2 must be (K,) with K={K}; got shape {b2_vec.shape}")
        relu_logits_test = np.ascontiguousarray(
            np.asarray(relu_logits_test, dtype=np.float64).reshape(N, K),
        )
        num_classes = int(K)

    # ------------------------------------------------------------------
    # Shared weights
    # ------------------------------------------------------------------
    _write_float64(W1, os.path.join(out_dir, "W1.bin"))
    _write_float64(b1, os.path.join(out_dir, "b1.bin"))
    if task == "binary":
        _write_float64(w2, os.path.join(out_dir, "w2.bin"))
        _write_float64(np.array([b2_scalar]), os.path.join(out_dir, "b2.bin"))
    else:
        _write_float64(W2_arr, os.path.join(out_dir, "W2.bin"))
        _write_float64(b2_vec, os.path.join(out_dir, "b2.bin"))

    # Test set + originals
    _write_float64(X_test, os.path.join(out_dir, "X_test.bin"))
    _write_int32(y_test_true, os.path.join(out_dir, "y_test_true.bin"))
    _write_int32(relu_pred_test, os.path.join(out_dir, "y_test_relu.bin"))
    _write_float64(relu_logits_test, os.path.join(out_dir, "relu_logits_test.bin"))

    # Optional StandardScaler stats
    if scaler_mean is not None and scaler_scale is not None:
        sm = np.asarray(scaler_mean, dtype=np.float64).reshape(-1)
        ss = np.asarray(scaler_scale, dtype=np.float64).reshape(-1)
        if sm.shape[0] != d or ss.shape[0] != d:
            raise ValueError("scaler_mean/scale must have length d (input dim).")
        _write_float64(sm, os.path.join(out_dir, "scaler_mean.bin"))
        _write_float64(ss, os.path.join(out_dir, "scaler_scale.bin"))

    # ------------------------------------------------------------------
    # Per-scheme artifacts
    # ------------------------------------------------------------------
    schemes_manifest_lines: List[str] = ["# name degree threshold"]
    schemes_json: List[Dict[str, Any]] = []

    for s in schemes:
        name = str(s["name"])
        if any(ch.isspace() for ch in name):
            raise ValueError(f"Scheme name '{name}' must not contain whitespace.")
        disp = str(s.get("display_name", name))
        degree = int(s["degree"])
        thr = float(s.get("threshold", 0.0))
        order = str(s.get("coeffs_order", "ascending")).lower()
        notes = str(s.get("notes", ""))

        coeffs = _to_ascending(s["coeffs"], degree)
        if order == "descending":
            coeffs = coeffs[::-1].copy()
        elif order != "ascending":
            raise ValueError(
                f"Scheme '{name}': coeffs_order must be 'ascending' or 'descending'"
            )

        logits = np.asarray(s["logits_test"], dtype=np.float64)
        if task == "binary":
            logits = logits.reshape(-1)
            if logits.shape[0] != N:
                raise ValueError(f"Scheme '{name}': logits_test length {logits.shape[0]} != {N}")
        else:
            logits = logits.reshape(N, num_classes)

        _write_float64(coeffs, os.path.join(out_dir, f"coeffs_{name}.bin"))
        _write_float64(logits, os.path.join(out_dir, f"logits_{name}.bin"))

        schemes_manifest_lines.append(f"{name} {degree} {thr:.17g}")
        schemes_json.append({
            "name": name, "display_name": disp, "degree": degree,
            "threshold": thr if task == "binary" else None,
            "coeffs_ascending": [float(v) for v in coeffs],
            "notes": notes,
        })

    with open(os.path.join(out_dir, "schemes.txt"), "w") as f:
        f.write("\n".join(schemes_manifest_lines) + "\n")

    # ------------------------------------------------------------------
    # Meta files
    # ------------------------------------------------------------------
    meta_lines = [
        f"task {task}",
        f"input_dim {d}",
        f"hidden_dim {H}",
        f"n_test {N}",
        f"n_schemes {len(schemes)}",
        f"input_kind {input_kind}",
    ]
    if task == "binary":
        meta_lines += [
            f"b2 {b2_scalar:.17g}",
            f"relu_threshold {float(relu_threshold):.17g}",
        ]
    else:
        meta_lines += [f"num_classes {num_classes}"]
    meta_lines += [f"has_scaler {int(scaler_mean is not None and scaler_scale is not None)}"]
    with open(os.path.join(out_dir, "meta.txt"), "w") as f:
        f.write("\n".join(meta_lines) + "\n")

    meta_json: Dict[str, Any] = {
        "task": task,
        "input_dim": int(d),
        "hidden_dim": int(H),
        "n_test": int(N),
        "input_kind": input_kind,
        "has_scaler": bool(scaler_mean is not None and scaler_scale is not None),
        "dtype_float": "float64 little-endian",
        "dtype_label": "int32 little-endian",
        "schemes": schemes_json,
    }
    if task == "binary":
        meta_json.update({
            "b2": float(b2_scalar),
            "relu_threshold": float(relu_threshold),
            "score_formula": "score(x) = sum_j w2_j * p(W1_j . x + b1_j) + b2",
            "decision_rule_per_scheme": "predict positive iff score > scheme.threshold",
        })
    else:
        meta_json.update({
            "num_classes": int(num_classes),
            "score_formula": "logits(x)_k = sum_j W2[k, j] * p(W1_j . x + b1_j) + b2[k]",
            "decision_rule": "predicted class = argmax_k logits_k",
        })
    with open(os.path.join(out_dir, "meta.json"), "w") as f:
        json.dump(meta_json, f, indent=2)

    if verbose:
        try:
            disp = os.path.relpath(out_dir)
        except ValueError:
            disp = os.path.basename(out_dir)
        print(f"[HE] Exported artifacts -> {disp}/")
        print(f"     task={task}, H={H}, d={d}, N_test={N}, schemes={len(schemes)}")
        for s in schemes_json:
            thr_str = f"thr={s['threshold']:+.6g}" if s['threshold'] is not None else "thr=N/A"
            print(f"     - {s['display_name']:<15s} (name={s['name']}, "
                  f"deg={s['degree']}, {thr_str})")
    return out_dir
