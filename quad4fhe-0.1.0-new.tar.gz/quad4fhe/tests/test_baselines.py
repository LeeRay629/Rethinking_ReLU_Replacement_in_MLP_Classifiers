"""Unit tests for `quad4fhe.baselines`."""
import warnings

import numpy as np
import pytest

from quad4fhe.baselines import (
    ALL_BASELINE_NAMES,
    LSPolyBaseline,
    OLABaseline,
    PreciseReLUBaseline,
    RemezBaseline,
    SquareBaseline,
    build_baseline,
    expand_baseline_list,
)


# -----------------------------------------------------------------------------
# Registry
# -----------------------------------------------------------------------------
def test_expand_none():
    assert expand_baseline_list(None) == []


def test_expand_string_all():
    result = expand_baseline_list("all")
    assert result == ALL_BASELINE_NAMES
    assert len(result) == 11


def test_expand_single_string():
    assert expand_baseline_list("remez_5") == ["remez_5"]


def test_expand_list_lowercase_strip():
    assert expand_baseline_list(["  Square  ", "REMEZ_2"]) == ["square", "remez_2"]


def test_build_baseline_by_name():
    assert isinstance(build_baseline("square", "relu"), SquareBaseline)
    assert isinstance(build_baseline("ls_poly_3", "relu"), LSPolyBaseline)
    assert isinstance(build_baseline("remez_5", "relu"), RemezBaseline)
    assert isinstance(build_baseline("ola", "relu"), OLABaseline)
    assert isinstance(build_baseline("precise_a11", "relu"), PreciseReLUBaseline)


def test_build_baseline_invalid_name():
    with pytest.raises(ValueError):
        build_baseline("not_a_real_baseline", "relu")


def test_precise_warns_and_skips_non_relu():
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        result = build_baseline("precise_a11", "gelu")
    assert result is None
    assert len(w) == 1
    assert "precise" in str(w[0].message).lower()


# -----------------------------------------------------------------------------
# Fit + apply for each baseline
# -----------------------------------------------------------------------------
@pytest.fixture
def Y_ref():
    rng = np.random.default_rng(0)
    return rng.standard_normal((40, 16)) * 2.0


def test_square_fits_and_applies(Y_ref):
    b = SquareBaseline()
    b.fit(Y_ref, "relu")
    out = b.apply(Y_ref)
    assert out.shape == Y_ref.shape
    np.testing.assert_allclose(out, Y_ref ** 2)
    assert b.coeffs_info["kind"] == "square"
    assert b.coeffs_info["coeffs_ascending"] == [0.0, 0.0, 1.0]


def test_ls_poly_degrees(Y_ref):
    for deg in [2, 3, 5, 7]:
        b = LSPolyBaseline(degree=deg)
        b.fit(Y_ref, "relu")
        assert len(b.coeffs_info["coeffs_ascending"]) == deg + 1
        assert b.max_err >= 0
        assert b.apply(Y_ref).shape == Y_ref.shape


def test_remez_reduces_max_err_compared_to_lspoly(Y_ref):
    """At the same degree, Remez should NOT do dramatically worse than LSPoly
    on max-err. In fact it usually does better, but we just need a sanity
    check that both produce finite errors in a reasonable ballpark."""
    deg = 5
    ls = LSPolyBaseline(degree=deg)
    ls.fit(Y_ref, "relu")
    rm = RemezBaseline(degree=deg)
    rm.fit(Y_ref, "relu")
    assert np.isfinite(ls.max_err)
    assert np.isfinite(rm.max_err)
    # Remez shouldn't be hugely worse than LS on max-err:
    assert rm.max_err <= 5.0 * ls.max_err


def test_ola_fits(Y_ref):
    b = OLABaseline(degrees=[7, 15, 31])
    b.fit(Y_ref, "relu")
    assert b.selected_degree in [7, 15, 31]
    assert b.selected_lambda_scale in [1.0, 2.0]
    out = b.apply(Y_ref)
    assert out.shape == Y_ref.shape


def test_precise_relu_only(Y_ref):
    b = PreciseReLUBaseline()
    b.fit(Y_ref, "relu")
    assert b.B > 0
    assert b.max_err >= 0
    out = b.apply(Y_ref)
    assert out.shape == Y_ref.shape
    # Should approximate ReLU reasonably
    relu = np.maximum(Y_ref, 0.0)
    # Not a tight tolerance — just sanity
    assert np.mean(np.abs(out - relu)) < 0.5


def test_precise_rejects_non_relu_at_fit(Y_ref):
    b = PreciseReLUBaseline()
    with pytest.raises(ValueError):
        b.fit(Y_ref, "gelu")
