"""
Example 02: Multi-class classification with BatchNorm.

Demonstrates quad4fhe on a multi-class MLP with `nn.BatchNorm1d` between the
hidden Linear and the activation. The library automatically folds BN into
effective W1_eff / b1_eff before applying the theory.

Run:
    python examples/02_multiclass_with_bn.py
"""
import numpy as np
import torch
import torch.nn as nn
from sklearn.datasets import make_classification
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

import quad4fhe


# ---------------------------------------------------------------------------
# 1. Create a synthetic multi-class dataset
# ---------------------------------------------------------------------------
X, y = make_classification(
    n_samples=2000, n_features=24, n_informative=16,
    n_classes=6, n_clusters_per_class=1, class_sep=1.5, random_state=42,
)
X_tr, X_te, y_tr, y_te = train_test_split(
    X, y, test_size=0.25, stratify=y, random_state=42,
)
scaler = StandardScaler().fit(X_tr)
X_tr = scaler.transform(X_tr)
X_te = scaler.transform(X_te)


# ---------------------------------------------------------------------------
# 2. Train an MLP with BN + Dropout
# ---------------------------------------------------------------------------
class BNMulticlassMLP(nn.Module):
    def __init__(self, d, h, k):
        super().__init__()
        self.fc1 = nn.Linear(d, h)
        self.bn  = nn.BatchNorm1d(h)
        self.act = nn.ReLU()
        self.drop = nn.Dropout(0.2)
        self.fc2 = nn.Linear(h, k)

    def forward(self, x):
        return self.fc2(self.drop(self.act(self.bn(self.fc1(x)))))


torch.manual_seed(0)
model = BNMulticlassMLP(d=X_tr.shape[1], h=48, k=6)
opt = torch.optim.Adam(model.parameters(), lr=5e-3, weight_decay=1e-4)
ce = nn.CrossEntropyLoss()

X_tr_t = torch.tensor(X_tr, dtype=torch.float32)
y_tr_t = torch.tensor(y_tr, dtype=torch.long)
print("Training BN MLP ...")
for epoch in range(300):
    model.train()
    opt.zero_grad()
    loss = ce(model(X_tr_t), y_tr_t)
    loss.backward()
    opt.step()
    if (epoch + 1) % 50 == 0:
        print(f"  epoch {epoch+1}: train loss = {loss.item():.4f}")

model.eval()
with torch.no_grad():
    preds = model(torch.tensor(X_te, dtype=torch.float32)).argmax(dim=-1).numpy()
acc = float(np.mean(preds == y_te))
print(f"Baseline MLP test accuracy: {acc:.4f}")


# ---------------------------------------------------------------------------
# 3. Replace ReLU with a quadratic. BN is auto-folded.
# ---------------------------------------------------------------------------
print("\n" + "=" * 78)
print("Running quad4fhe.replace(...) — watch for the BN fold line in Step 1.")
print("=" * 78)

result = quad4fhe.replace(
    task="multiclass",
    model=model,
    hidden_layer="fc1",
    output_layer="fc2",
    activation="relu",
    fit_data=(X_tr, y_tr),
    test_data=(X_te, y_te),
    baselines=["square", "ls_poly_2", "remez_2"],
    export_he_dir="he_out_multiclass",
    verbose=True,
)

# ---------------------------------------------------------------------------
# 4. Drop-in inference with the returned nn.Module
# ---------------------------------------------------------------------------
rm = result.replaced_model.eval()
with torch.no_grad():
    logits = rm(torch.tensor(X_te, dtype=torch.float32)).numpy()
quad_acc = float(np.mean(logits.argmax(axis=-1) == y_te))
print(f"\nQuad4FHE test accuracy: {quad_acc:.4f}  (baseline MLP: {acc:.4f})")
print(f"Pairwise minimum margin: {result.empirical_margin:+.6f}")
print(f"Minimum safe decimals: {result.quant_decimals}")
