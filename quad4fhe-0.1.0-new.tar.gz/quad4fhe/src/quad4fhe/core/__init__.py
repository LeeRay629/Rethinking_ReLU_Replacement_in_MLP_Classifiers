"""
quad4fhe.core — pure NumPy / SciPy implementation of the convex-geometry
substitution theory. This layer has no PyTorch dependency.

Researchers who wish to reproduce the theoretical experiments can import
everything they need from here:

    from quad4fhe.core import (
        # Binary-task lifting
        lift_binary,                          # (X, W1, b1, w2, b2) -> (Q, H)
        # Multi-class lifting
        build_pairwise_lifted_constraints,    # -> (Zbar, sample_idx)
        # Binary solvers
        solve_rch_distance,                   # closest-point in RCH (Theorem 4)
        solve_theorem5_primal,                # soft-margin primal QP
        # Multi-class solvers
        solve_mc_hard_margin,                 # Prop 2.6 (1)
        solve_mc_soft_margin,                 # Prop 2.6 (2)
        # Verification
        verify_exact_separation,
        verify_rch_separation,
        # Utilities
        capped_simplex_min,
        capped_simplex_max,
    )
"""
from quad4fhe.core.geom import (
    capped_simplex_max,
    capped_simplex_min,
    compute_quantization_robustness_exact,
    compute_quantization_robustness_rch,
    verify_exact_separation,
    verify_rch_separation,
)
from quad4fhe.core.lifting import (
    build_pairwise_lifted_constraints,
    lift_binary,
    quadratic_logits_from_QH,
    quadratic_logits_from_QL,
    realize_affine_score_by_eta,
    recover_alpha_beta_eta,
)
from quad4fhe.core.solvers import (
    solve_mc_hard_margin,
    solve_mc_soft_margin,
    solve_rch_distance,
    solve_theorem5_primal,
)

__all__ = [
    # Lifting
    "lift_binary",
    "build_pairwise_lifted_constraints",
    "quadratic_logits_from_QH",
    "quadratic_logits_from_QL",
    "realize_affine_score_by_eta",
    "recover_alpha_beta_eta",
    # Geometry
    "capped_simplex_min",
    "capped_simplex_max",
    "verify_exact_separation",
    "verify_rch_separation",
    "compute_quantization_robustness_exact",
    "compute_quantization_robustness_rch",
    # Solvers
    "solve_rch_distance",
    "solve_theorem5_primal",
    "solve_mc_hard_margin",
    "solve_mc_soft_margin",
]
