"""
Example 01: Binary classification on the Pima Indians Diabetes dataset.

Demonstrates the end-to-end `quad4fhe.replace(...)` pipeline on a standard
single-hidden-layer MLP for binary classification.

Run:
    python examples/01_diabetes_binary.py
"""
import numpy as np
import torch
import torch.nn as nn
from sklearn.datasets import fetch_openml
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

import quad4fhe

# ---------------------------------------------------------------------------
# 1. Load and split the Pima Indians Diabetes dataset
# ---------------------------------------------------------------------------
print("Loading Pima Indians Diabetes dataset ...")
try:
    data = fetch_openml(name="diabetes", version=1, as_frame=False, parser="liac-arff")
    X = np.asarray(data.data, dtype=np.float64)
    # Map the 'tested_positive' / 'tested_negative' labels to 1 / 0
    y = (np.asarray(data.target) == "tested_positive").astype(np.int64)
except Exception as e:
    # Fallback: use make_classification to avoid network dependency
    print(f"fetch_openml failed ({e}); using synthetic data instead.")
    from sklearn.datasets import make_classification
    X, y = make_classification(
        n_samples=768, n_features=8, n_informative=5,
        n_classes=2, random_state=42,
    )

X_tr, X_te, y_tr, y_te = train_test_split(
    X, y, test_size=0.25, stratify=y, random_state=42,
)
scaler = StandardScaler().fit(X_tr)
X_tr = scaler.transform(X_tr)
X_te = scaler.transform(X_te)


# ---------------------------------------------------------------------------
# 2. Define and train a simple MLP
# ---------------------------------------------------------------------------
class BinaryMLP(nn.Module):
    def __init__(self, d, h):
        super().__init__()
        self.fc1 = nn.Linear(d, h)
        self.act = nn.ReLU()
        self.fc2 = nn.Linear(h, 1)

    def forward(self, x):
        return self.fc2(self.act(self.fc1(x))).squeeze(-1)


torch.manual_seed(0)
model = BinaryMLP(d=X_tr.shape[1], h=16)
opt = torch.optim.Adam(model.parameters(), lr=1e-2, weight_decay=1e-4)
bce = nn.BCEWithLogitsLoss()

X_tr_t = torch.tensor(X_tr, dtype=torch.float32)
y_tr_t = torch.tensor(y_tr, dtype=torch.float32)
print("\nTraining baseline MLP ...")
for epoch in range(200):
    model.train()
    opt.zero_grad()
    loss = bce(model(X_tr_t), y_tr_t)
    loss.backward()
    opt.step()
    if (epoch + 1) % 50 == 0:
        print(f"  epoch {epoch+1}: train loss = {loss.item():.4f}")

model.eval()
with torch.no_grad():
    probs = torch.sigmoid(model(torch.tensor(X_te, dtype=torch.float32))).numpy()
acc = float(np.mean((probs > 0.5) == y_te))
print(f"Baseline MLP test accuracy: {acc:.4f}")


# ---------------------------------------------------------------------------
# 3. Substitute ReLU with a quadratic via quad4fhe.replace
# ---------------------------------------------------------------------------
print("\n" + "=" * 78)
print("Running quad4fhe.replace(...)")
print("=" * 78)

result = quad4fhe.replace(
    task="binary",
    model=model,
    hidden_layer="fc1",
    output_layer="fc2",
    activation="relu",
    fit_data=(X_tr, y_tr),
    test_data=(X_te, y_te),
    baselines=["square", "ls_poly_2", "remez_2", "ola"],
    export_he_dir="he_out_diabetes",
    verbose=True,
)

# ---------------------------------------------------------------------------
# 4. Use the drop-in replaced module for inference
# ---------------------------------------------------------------------------
print("\n" + "=" * 78)
print("Using the replaced nn.Module as a drop-in")
print("=" * 78)
rm = result.replaced_model.eval()
with torch.no_grad():
    test_logits = rm(torch.tensor(X_te, dtype=torch.float32)).numpy()
preds = (test_logits > result.threshold).astype(int)
acc_quad = float(np.mean(preds == y_te))
print(f"Quad4FHE test accuracy: {acc_quad:.4f}  (baseline MLP: {acc:.4f})")
print(f"Minimum safe decimals: {result.quant_decimals}")
print(f"HE artifacts written to: {result.he_export_dir}")
