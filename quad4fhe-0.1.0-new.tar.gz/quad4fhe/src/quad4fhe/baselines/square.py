"""
quad4fhe.baselines.square — trivial p(x) = x^2 baseline (used e.g. in CryptoNets).
"""
from __future__ import annotations

import numpy as np

from quad4fhe.baselines._base import _BaseBaseline, activation_error


class SquareBaseline(_BaseBaseline):
    name = "square"

    def fit(self, Y_ref: np.ndarray, activation: str) -> None:
        self._fn = lambda x: np.asarray(x, dtype=np.float64) ** 2
        self.max_err, self.mean_err = activation_error(self._fn, Y_ref, activation)
        self.coeffs_info = {
            "kind": "square",
            "coeffs_ascending": [0.0, 0.0, 1.0],   # p(x) = 0 + 0*x + 1*x^2
            "degree": 2,
        }

    def apply(self, Y: np.ndarray) -> np.ndarray:
        return self._fn(Y)
