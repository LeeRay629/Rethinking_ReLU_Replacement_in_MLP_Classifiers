"""
quad4fhe.core.solvers
=====================

Convex solvers for the four problems in the theory:

* **Binary / Theorem 3**   — RCH-distance (closest-point) QP
* **Binary / Theorem 5**   — primal/dual soft-margin QP
* **Multi  / Proposition 2.6 (1)** — hard-margin homogeneous QP
* **Multi  / Proposition 2.6 (2)** — soft-margin homogeneous QP

Each solver has three possible back-ends, tried in the order most efficient
→ most portable:

    1. CVXPY (OSQP / CLARABEL / ECOS / SCS)        — default when available
    2. OSQP direct (for warm-start batch of many C values)
    3. scipy.optimize (SLSQP / L-BFGS-B)           — always available

The caller never needs to know which back-end ran — the result object
includes a `solver` field for diagnostics.

Large multi-class hard-margin problems (K >> 10 so that N*(K-1) constraints
exceeds ~200k) automatically switch to a **cutting-plane** scheme: start from
a seed subset of constraints, solve, add the most-violated constraints, repeat.
"""
from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Any, Dict, List, Optional

import numpy as np
import scipy.sparse as sp
from scipy.optimize import Bounds, LinearConstraint, linprog, minimize

# -------- Optional accelerators --------
try:
    import cvxpy as cp
    HAS_CVXPY = True
except ImportError:  # pragma: no cover
    cp = None
    HAS_CVXPY = False

try:
    import osqp as osqp_direct
    HAS_OSQP_DIRECT = True
except ImportError:  # pragma: no cover
    osqp_direct = None
    HAS_OSQP_DIRECT = False


SOLVER_TOL = 1e-7
GEOM_TOL = 1e-7


# =============================================================================
# Generic CVXPY fallback wrapper
# =============================================================================
def _solve_cvxpy_problem(prob, verbose: bool = False):
    """Try OSQP → CLARABEL → ECOS → SCS in order. Returns the name of the
    solver that succeeded, along with the problem status."""
    if not HAS_CVXPY:
        raise RuntimeError("cvxpy is not installed")
    installed = set(cp.installed_solvers())
    ok_status = {
        "optimal", "optimal_inaccurate",
        "infeasible", "infeasible_inaccurate",
        "unbounded", "unbounded_inaccurate",
    }
    last_err = None
    for solver in ["OSQP", "CLARABEL", "ECOS", "SCS"]:
        if solver not in installed:
            continue
        try:
            if solver == "OSQP":
                prob.solve(solver=solver, verbose=verbose,
                           eps_abs=SOLVER_TOL, eps_rel=SOLVER_TOL,
                           max_iter=200000, polish=True)
            elif solver == "CLARABEL":
                prob.solve(solver=solver, verbose=verbose, max_iter=50000)
            elif solver == "ECOS":
                prob.solve(solver=solver, verbose=verbose,
                           abstol=SOLVER_TOL, reltol=SOLVER_TOL,
                           feastol=SOLVER_TOL, max_iters=200000)
            elif solver == "SCS":
                prob.solve(solver=solver, verbose=verbose,
                           eps=SOLVER_TOL, max_iters=200000)
            else:
                prob.solve(solver=solver, verbose=verbose)
            if prob.status in ok_status:
                return solver, prob.status
        except Exception as e:
            last_err = e
            continue
    raise RuntimeError(f"cvxpy solve failed. Last error: {last_err}")


# =============================================================================
# BINARY PROBLEMS
# =============================================================================
def solve_rch_distance(
    S_plus: np.ndarray,
    S_minus: np.ndarray,
    mu_p: float = 1.0,
    mu_n: float = 1.0,
    geom_tol: float = GEOM_TOL,
) -> Dict[str, Any]:
    """RCH closest-point QP (Theorem 4).

        min_{lambda, kappa}  || sum_i lambda_i z_i^+ - sum_j kappa_j z_j^- ||^2
        s.t.                 sum lambda_i = 1, sum kappa_j = 1,
                             0 <= lambda_i <= mu_p, 0 <= kappa_j <= mu_n.

    When mu_p = mu_n = 1, this reduces to the standard-convex-hull closest-
    point problem (Theorem 2 / 3).

    Returns
    -------
    A dict with keys:
        solver, status, rch_distance_sq, lam, kap, u_star, v_star,
        delta, theta_hat (= (u*-v*)/||.||  or None if distance=0),
        theta_from_dual (= 0.5 * (u* - v*)).
    """
    if HAS_CVXPY:
        return _solve_rch_distance_cvxpy(S_plus, S_minus, mu_p, mu_n, geom_tol)
    return _solve_rch_distance_slsqp(S_plus, S_minus, mu_p, mu_n, geom_tol)


def _solve_rch_distance_cvxpy(S_plus, S_minus, mu_p, mu_n, geom_tol):
    S_plus = np.asarray(S_plus, dtype=np.float64)
    S_minus = np.asarray(S_minus, dtype=np.float64)
    n_p, n_n = len(S_plus), len(S_minus)

    lam = cp.Variable(n_p)
    kap = cp.Variable(n_n)
    u = S_plus.T @ lam
    v = S_minus.T @ kap
    prob = cp.Problem(
        cp.Minimize(cp.sum_squares(u - v)),
        [lam >= 0, kap >= 0, lam <= mu_p, kap <= mu_n,
         cp.sum(lam) == 1, cp.sum(kap) == 1],
    )
    solver_name, status = _solve_cvxpy_problem(prob)
    lam_star = np.asarray(lam.value, dtype=np.float64).reshape(-1)
    kap_star = np.asarray(kap.value, dtype=np.float64).reshape(-1)
    u_star = lam_star @ S_plus
    v_star = kap_star @ S_minus
    diff = u_star - v_star
    delta = float(np.linalg.norm(diff))
    theta_hat = (diff / delta) if delta > geom_tol else None
    return {
        "solver": solver_name, "status": status,
        "rch_distance_sq": float(prob.value),
        "lam": lam_star, "kap": kap_star,
        "u_star": u_star, "v_star": v_star,
        "delta": delta,
        "theta_hat": theta_hat,
        "theta_from_dual": 0.5 * diff,
    }


def _solve_rch_distance_slsqp(S_plus, S_minus, mu_p, mu_n, geom_tol):
    S_plus = np.asarray(S_plus, dtype=np.float64)
    S_minus = np.asarray(S_minus, dtype=np.float64)
    n_p, n_n = len(S_plus), len(S_minus)

    def unpack(x):
        return x[:n_p], x[n_p:]

    def obj(x):
        lam, kap = unpack(x)
        d = lam @ S_plus - kap @ S_minus
        return float(np.dot(d, d))

    def grad(x):
        lam, kap = unpack(x)
        d = lam @ S_plus - kap @ S_minus
        return np.concatenate([2.0 * (S_plus @ d), -2.0 * (S_minus @ d)])

    Aeq = np.zeros((2, n_p + n_n))
    Aeq[0, :n_p] = 1.0
    Aeq[1, n_p:] = 1.0
    beq = np.array([1.0, 1.0])
    bounds = Bounds(
        np.concatenate([np.zeros(n_p), np.zeros(n_n)]),
        np.concatenate([np.full(n_p, mu_p), np.full(n_n, mu_n)]),
    )
    x0 = np.concatenate([np.full(n_p, 1.0 / n_p), np.full(n_n, 1.0 / n_n)])

    res = minimize(
        obj, x0, jac=grad, method="SLSQP", bounds=bounds,
        constraints=[LinearConstraint(Aeq, beq, beq)],
        options={"ftol": SOLVER_TOL, "maxiter": 5000, "disp": False},
    )
    lam_star, kap_star = unpack(res.x)
    u_star = lam_star @ S_plus
    v_star = kap_star @ S_minus
    diff = u_star - v_star
    delta = float(np.linalg.norm(diff))
    theta_hat = (diff / delta) if delta > geom_tol else None
    return {
        "solver": "SLSQP",
        "status": "optimal" if res.success else f"suboptimal({res.message})",
        "rch_distance_sq": float(res.fun),
        "lam": lam_star, "kap": kap_star,
        "u_star": u_star, "v_star": v_star,
        "delta": delta,
        "theta_hat": theta_hat,
        "theta_from_dual": 0.5 * diff,
    }


def solve_theorem5_primal(
    S_plus: np.ndarray,
    S_minus: np.ndarray,
    c_p: float,
    c_n: float,
) -> Dict[str, Any]:
    """Theorem 5 primal soft-margin QP (binary):

        min  0.5 ||theta||^2 - rho + c_p sum xi+ + c_n sum xi-
        s.t. theta^T u_i - t >= rho - xi+_i,  xi+ >= 0
             t - theta^T v_j >= rho - xi-_j,  xi- >= 0.

    Returns the primal optimum (theta, t, rho, xi+/-) along with the objective.
    """
    if HAS_CVXPY:
        return _solve_theorem5_cvxpy(S_plus, S_minus, c_p, c_n)
    return _solve_theorem5_slsqp(S_plus, S_minus, c_p, c_n)


def _solve_theorem5_cvxpy(S_plus, S_minus, c_p, c_n):
    S_plus = np.asarray(S_plus, dtype=np.float64)
    S_minus = np.asarray(S_minus, dtype=np.float64)
    d = S_plus.shape[1]
    n_p, n_n = len(S_plus), len(S_minus)

    theta = cp.Variable(d)
    t = cp.Variable()
    rho = cp.Variable()
    xi_p = cp.Variable(n_p, nonneg=True)
    xi_n = cp.Variable(n_n, nonneg=True)

    prob = cp.Problem(
        cp.Minimize(0.5 * cp.sum_squares(theta) - rho
                    + c_p * cp.sum(xi_p) + c_n * cp.sum(xi_n)),
        [S_plus @ theta - t >= rho - xi_p,
         t - S_minus @ theta >= rho - xi_n],
    )
    solver_name, status = _solve_cvxpy_problem(prob)
    return {
        "solver": solver_name, "status": status,
        "objective": float(prob.value),
        "theta": np.asarray(theta.value, dtype=np.float64).reshape(-1),
        "t": float(t.value),
        "rho": float(rho.value),
        "xi_p": np.asarray(xi_p.value, dtype=np.float64).reshape(-1),
        "xi_n": np.asarray(xi_n.value, dtype=np.float64).reshape(-1),
    }


def _solve_theorem5_slsqp(S_plus, S_minus, c_p, c_n):
    S_plus = np.asarray(S_plus, dtype=np.float64)
    S_minus = np.asarray(S_minus, dtype=np.float64)
    d = S_plus.shape[1]
    n_p, n_n = len(S_plus), len(S_minus)
    dim = d + 2 + n_p + n_n
    idx_theta = slice(0, d)
    idx_t, idx_rho = d, d + 1
    idx_xip = slice(d + 2, d + 2 + n_p)
    idx_xin = slice(d + 2 + n_p, dim)

    def unpack(x):
        return x[idx_theta], x[idx_t], x[idx_rho], x[idx_xip], x[idx_xin]

    def obj(x):
        th, t, rho, xip, xin = unpack(x)
        return float(0.5 * np.dot(th, th) - rho + c_p * np.sum(xip) + c_n * np.sum(xin))

    def grad(x):
        g = np.zeros(dim)
        th, t, rho, xip, xin = unpack(x)
        g[idx_theta] = th
        g[idx_rho] = -1.0
        g[idx_xip] = c_p
        g[idx_xin] = c_n
        return g

    def pos_constr(x):
        th, t, rho, xip, xin = unpack(x)
        return S_plus @ th - t - rho + xip

    def neg_constr(x):
        th, t, rho, xip, xin = unpack(x)
        return -S_minus @ th + t - rho + xin

    lb = np.full(dim, -np.inf)
    ub = np.full(dim, np.inf)
    lb[idx_xip] = 0.0
    lb[idx_xin] = 0.0
    x0 = np.zeros(dim)
    x0[idx_rho] = -1.0
    x0[idx_xip] = 1.0
    x0[idx_xin] = 1.0

    res = minimize(
        obj, x0, jac=grad, method="SLSQP",
        bounds=Bounds(lb, ub),
        constraints=[
            {"type": "ineq", "fun": pos_constr},
            {"type": "ineq", "fun": neg_constr},
        ],
        options={"ftol": SOLVER_TOL, "maxiter": 5000, "disp": False},
    )
    th, t, rho, xip, xin = unpack(res.x)
    return {
        "solver": "SLSQP",
        "status": "optimal" if res.success else f"suboptimal({res.message})",
        "objective": float(res.fun),
        "theta": np.asarray(th, dtype=np.float64).reshape(-1),
        "t": float(t), "rho": float(rho),
        "xi_p": np.asarray(xip, dtype=np.float64).reshape(-1),
        "xi_n": np.asarray(xin, dtype=np.float64).reshape(-1),
    }


# =============================================================================
# MULTI-CLASS PROBLEMS (Proposition 2.6)
# =============================================================================
@dataclass
class MCQPResult:
    """Unified result container for multi-class QP problems."""
    feasible: bool
    status: str
    solver: Optional[str]
    theta_bar: Optional[np.ndarray]             # (u, v, w, lambda)
    alpha: Optional[float]
    beta: Optional[float]
    eta: Optional[float]
    objective: Optional[float]
    C_penalty: Optional[float] = None           # for soft-margin
    extra: Dict[str, Any] = None                # diagnostic info (cutting-plane iterations etc.)


def _recover_abc(theta_bar):
    u, v, w, c = np.asarray(theta_bar, dtype=np.float64).reshape(-1).tolist()
    if c <= 0:
        raise ValueError(f"Recovery failed: lambda = {c} <= 0")
    return float(u / c), float(v / c), float(w / c)


# ---------- Hard-margin (MC-H) ----------
def solve_mc_hard_margin(
    Zbar: np.ndarray,
    use_cutting_plane: Any = "auto",
    cp_init: int = 10000,
    cp_batch: int = 5000,
    cp_max_rounds: int = 50,
    cp_tol: float = 1e-6,
    verbose: bool = False,
    _print: Any = print,
) -> MCQPResult:
    """Proposition 2.6(1): solve

        min 0.5 ||theta_bar||^2
        s.t. Zbar @ theta_bar >= 1
             lambda := theta_bar[3] >= 1

    When `use_cutting_plane=True` or ("auto" and nrows > 200k), iteratively
    grow an active set of constraints.
    """
    Zbar = np.asarray(Zbar, dtype=np.float64)
    m = Zbar.shape[0]
    MAX_EXACT = 200_000
    if use_cutting_plane == "auto":
        use_cutting_plane = (m > MAX_EXACT)

    if not use_cutting_plane:
        return _solve_mc_hard_exact(Zbar)

    if verbose:
        _print(f"[cutting-plane] {m} constraints > threshold, using active-set scheme "
               f"(init={cp_init}, batch={cp_batch})")
    return _solve_mc_hard_cutting_plane(Zbar, cp_init, cp_batch, cp_max_rounds, cp_tol,
                                        verbose=verbose, _print=_print)


def _solve_mc_hard_exact(Zbar: np.ndarray) -> MCQPResult:
    if HAS_CVXPY:
        theta_bar = cp.Variable(4)
        prob = cp.Problem(
            cp.Minimize(0.5 * cp.sum_squares(theta_bar)),
            [Zbar @ theta_bar >= 1.0, theta_bar[3] >= 1.0],
        )
        try:
            solver_name, status = _solve_cvxpy_problem(prob)
        except RuntimeError as e:
            return MCQPResult(False, f"solver_error:{e}", None, None, None, None, None, None)
        if status not in ("optimal", "optimal_inaccurate"):
            return MCQPResult(False, status, solver_name, None, None, None, None, None)
        theta_val = np.asarray(theta_bar.value, dtype=np.float64).reshape(-1)
        try:
            alpha, beta, eta = _recover_abc(theta_val)
        except ValueError as e:
            return MCQPResult(False, f"recovery_failed:{e}", solver_name,
                              theta_val, None, None, None, float(prob.value))
        return MCQPResult(True, status, solver_name, theta_val, alpha, beta, eta,
                          float(prob.value))
    # scipy fallback: use linprog feasibility + L-BFGS-B post-refinement
    return _solve_mc_hard_scipy(Zbar)


def _solve_mc_hard_scipy(Zbar: np.ndarray) -> MCQPResult:
    """No CVXPY — use linprog to get feasibility, then L-BFGS-B to minimise norm."""
    m = Zbar.shape[0]
    c_obj = np.zeros(4)
    A_ub = np.vstack([-Zbar, np.array([[0.0, 0.0, 0.0, -1.0]])])
    b_ub = np.concatenate([-np.ones(m), np.array([-1.0])])
    lp = linprog(c_obj, A_ub=A_ub, b_ub=b_ub, bounds=[(None, None)] * 4, method="highs")
    if not lp.success:
        return MCQPResult(False, f"linprog:{lp.status}", "linprog",
                          None, None, None, None, None)
    x0 = np.asarray(lp.x, dtype=np.float64)

    # Refine by minimising 0.5 ||theta||^2 with a smooth barrier on the
    # inequalities. Use scipy.minimize with inequality constraints (SLSQP).
    def obj(th): return 0.5 * float(np.dot(th, th))
    def grad(th): return th

    def ineq_constr(th): return Zbar @ th - 1.0
    def lambda_constr(th): return th[3] - 1.0

    res = minimize(
        obj, x0, jac=grad, method="SLSQP",
        constraints=[
            {"type": "ineq", "fun": ineq_constr},
            {"type": "ineq", "fun": lambda_constr},
        ],
        options={"ftol": SOLVER_TOL, "maxiter": 5000, "disp": False},
    )
    theta_val = np.asarray(res.x, dtype=np.float64)
    try:
        alpha, beta, eta = _recover_abc(theta_val)
    except ValueError as e:
        return MCQPResult(False, f"recovery_failed:{e}", "SLSQP",
                          theta_val, None, None, None, float(res.fun))
    return MCQPResult(
        True if res.success else False,
        "optimal" if res.success else f"suboptimal({res.message})",
        "SLSQP", theta_val, alpha, beta, eta, float(res.fun),
    )


def _solve_mc_hard_cutting_plane(Zbar, init, batch, max_rounds, tol, verbose, _print):
    """Active-set cutting-plane for large-scale hard-margin MC-H."""
    m = Zbar.shape[0]
    init = min(max(init, 4), m)
    # Seed: sample furthest-from-origin constraints + random
    norms = np.linalg.norm(Zbar, axis=1)
    nh = init // 2
    hi_idx = np.argpartition(norms, -nh)[-nh:]
    rem = np.setdiff1d(np.arange(m), hi_idx)
    rng = np.random.RandomState(42)
    ri = rng.choice(rem, size=min(init - nh, len(rem)), replace=False)
    active = np.unique(np.concatenate([hi_idx, ri]))

    iters: List[Dict[str, Any]] = []
    last_res: Optional[MCQPResult] = None
    for it in range(max_rounds):
        t0 = time.perf_counter()
        sub = _solve_mc_hard_exact(Zbar[active])
        elapsed = time.perf_counter() - t0
        last_res = sub
        if not sub.feasible or sub.theta_bar is None:
            if verbose:
                _print(f"  [cp {it}] sub-problem infeasible: {sub.status}")
            return MCQPResult(
                False, f"sub_infeasible({sub.status})", f"cutting-plane/{sub.solver}",
                None, None, None, None, None,
                extra={"iters": iters},
            )
        margins = Zbar @ sub.theta_bar
        violated = np.where(margins < 1.0 - tol)[0]
        min_m = float(np.min(margins))
        iters.append({"iter": it, "active": int(active.size),
                      "violated": int(violated.size),
                      "min_margin": min_m, "time_s": float(elapsed)})
        if verbose:
            _print(f"  [cp {it}] active={active.size:>7d}  violated={violated.size:>7d}  "
                   f"min_margin={min_m:.8f}  time={elapsed:.3f}s")
        if violated.size == 0:
            sub.extra = {"iters": iters}
            sub.solver = f"cutting-plane/{sub.solver}"
            return sub
        k = min(batch, violated.size)
        worst = violated[np.argpartition(margins[violated], k - 1)[:k]]
        new_active = np.unique(np.concatenate([active, worst]))
        if new_active.size == active.size:
            if verbose:
                _print("  [cp] no new constraints added → stop.")
            break
        active = new_active

    if last_res is None:
        return MCQPResult(False, "cutting_plane_failed", "cutting-plane",
                          None, None, None, None, None, extra={"iters": iters})
    # Return last best
    last_res.solver = f"cutting-plane/{last_res.solver}"
    last_res.extra = {"iters": iters}
    last_res.status = f"{last_res.status}(max_rounds)"
    return last_res


# ---------- Soft-margin (MC-S) ----------
def solve_mc_soft_margin(
    Zbar: np.ndarray,
    sample_idx: np.ndarray,
    n_samples: int,
    num_classes: int,
    C_penalty: float,
    method: str = "scipy",
) -> MCQPResult:
    """Proposition 2.6(2): multi-class soft-margin.

        min  0.5 ||theta_bar||^2 + C * sum xi_i
        s.t. Zbar @ theta_bar >= 1 - M xi        (M = sample-incidence matrix)
             xi >= 0
             lambda >= 1

    `method` can be one of:
      "scipy"   — eliminate slacks → 4-variable L-BFGS-B solve (fastest)
      "cvxpy"   — direct CVXPY formulation
    """
    if method == "scipy":
        return _solve_mc_soft_scipy(Zbar, n_samples, num_classes, C_penalty)
    elif method == "cvxpy":
        return _solve_mc_soft_cvxpy(Zbar, sample_idx, n_samples, C_penalty)
    else:
        raise ValueError(f"Unknown method: {method}")


def _solve_mc_soft_scipy(Zbar, n_samples, num_classes, C_penalty):
    """Slack-eliminated version: xi_i = max(0, 1 - min_r m_{i,r}(theta))."""
    Km1 = num_classes - 1

    def obj_grad(theta):
        all_margins = Zbar @ theta
        margins_2d = all_margins.reshape(n_samples, Km1)
        min_margins = margins_2d.min(axis=1)
        min_idx = margins_2d.argmin(axis=1)
        slack = 1.0 - min_margins
        active = slack > 0.0
        obj = 0.5 * float(np.dot(theta, theta))
        grad = theta.copy()
        if active.any():
            ai = np.where(active)[0]
            obj += C_penalty * float(slack[active].sum())
            binding_rows = ai * Km1 + min_idx[active]
            grad -= C_penalty * Zbar[binding_rows].sum(axis=0)
        return obj, grad

    x0 = np.array([0.0, 0.0, 0.0, 1.0])
    bounds = [(None, None), (None, None), (None, None), (1.0, None)]
    res = minimize(obj_grad, x0, method="L-BFGS-B", jac=True, bounds=bounds,
                   options={"maxiter": 50000, "ftol": 1e-15, "gtol": 1e-12})
    theta_val = res.x
    try:
        alpha, beta, eta = _recover_abc(theta_val)
    except ValueError:
        return MCQPResult(False, "c_nonpositive", "L-BFGS-B",
                          None, None, None, None, None, C_penalty)
    return MCQPResult(
        True,
        "optimal" if res.success else f"suboptimal({res.message})",
        "L-BFGS-B", theta_val, alpha, beta, eta, float(res.fun), C_penalty,
    )


def _solve_mc_soft_cvxpy(Zbar, sample_idx, n_samples, C_penalty):
    if not HAS_CVXPY:
        raise RuntimeError("cvxpy is not installed")
    theta_bar = cp.Variable(4)
    xi = cp.Variable(n_samples, nonneg=True)
    M = sp.csr_matrix(
        (np.ones(len(sample_idx)),
         (np.arange(len(sample_idx)), sample_idx.astype(np.int64))),
        shape=(len(sample_idx), n_samples),
    )
    prob = cp.Problem(
        cp.Minimize(0.5 * cp.sum_squares(theta_bar) + C_penalty * cp.sum(xi)),
        [Zbar @ theta_bar >= 1.0 - M @ xi, theta_bar[3] >= 1.0],
    )
    try:
        solver_name, status = _solve_cvxpy_problem(prob)
    except RuntimeError as e:
        return MCQPResult(False, f"solver_error:{e}", None,
                          None, None, None, None, None, C_penalty)
    if status not in ("optimal", "optimal_inaccurate"):
        return MCQPResult(False, status, solver_name,
                          None, None, None, None, None, C_penalty)
    theta_val = np.asarray(theta_bar.value, dtype=np.float64).reshape(-1)
    try:
        alpha, beta, eta = _recover_abc(theta_val)
    except ValueError:
        return MCQPResult(False, "c_nonpositive", solver_name,
                          theta_val, None, None, None, float(prob.value), C_penalty)
    return MCQPResult(True, status, solver_name, theta_val, alpha, beta, eta,
                      float(prob.value), C_penalty)


def solve_mc_soft_margin_batch_osqp(
    Zbar: np.ndarray,
    sample_idx: np.ndarray,
    n_samples: int,
    C_grid: List[float],
) -> Dict[float, MCQPResult]:
    """Warm-started batch solve of MC-S for a grid of C penalty values.

    Only available when the `osqp` package is installed. Falls back to
    per-C scipy solves if not.
    """
    if not HAS_OSQP_DIRECT:
        # Fallback: solve each C independently with scipy
        num_classes = len(Zbar) // n_samples + 1
        return {C: _solve_mc_soft_scipy(Zbar, n_samples, num_classes, C) for C in C_grid}

    n_constr = Zbar.shape[0]
    n_vars = 4 + n_samples
    M_inc = sp.csr_matrix(
        (np.ones(len(sample_idx)),
         (np.arange(len(sample_idx)), sample_idx.astype(np.int64))),
        shape=(len(sample_idx), n_samples),
    )
    P = sp.triu(
        sp.block_diag([sp.eye(4, format='csc'), sp.csc_matrix((n_samples, n_samples))],
                      format='csc'),
        format='csc',
    )
    A_main = sp.hstack([sp.csc_matrix(Zbar), M_inc], format='csc')
    e4_row = sp.csc_matrix(([1.0], ([0], [3])), shape=(1, n_vars))
    A_xi = sp.hstack([sp.csc_matrix((n_samples, 4)),
                      sp.eye(n_samples, format='csc')], format='csc')
    A = sp.vstack([A_main, e4_row, A_xi], format='csc')
    l_vec = np.concatenate([np.ones(n_constr), [1.0], np.zeros(n_samples)])
    u_vec = np.full(n_constr + 1 + n_samples, np.inf)

    C_sorted = sorted(C_grid)
    results: Dict[float, MCQPResult] = {}
    solver_obj = None
    for i, C_val in enumerate(C_sorted):
        q = np.concatenate([np.zeros(4), np.full(n_samples, C_val)])
        if i == 0:
            solver_obj = osqp_direct.OSQP()
            solver_obj.setup(P, q, A, l_vec, u_vec,
                             eps_abs=SOLVER_TOL, eps_rel=SOLVER_TOL,
                             max_iter=200000, polish=True, verbose=False,
                             warm_start=True)
        else:
            solver_obj.update(q=q)
        res = solver_obj.solve()
        if res.info.status in ("solved", "solved_inaccurate"):
            theta_val = np.array(res.x[:4], dtype=np.float64)
            try:
                alpha, beta, eta = _recover_abc(theta_val)
                results[C_val] = MCQPResult(
                    True, res.info.status, "OSQP-direct",
                    theta_val, alpha, beta, eta, float(res.info.obj_val), C_val,
                )
            except ValueError:
                results[C_val] = MCQPResult(
                    False, "c_recovery_failed", "OSQP-direct",
                    None, None, None, None, None, C_val,
                )
        else:
            results[C_val] = MCQPResult(
                False, res.info.status, "OSQP-direct",
                None, None, None, None, None, C_val,
            )
    return results
