"""Unit tests for `quad4fhe.core.lifting`."""
import numpy as np
import pytest

from quad4fhe.core.lifting import (
    build_pairwise_lifted_constraints,
    lift_binary,
    quadratic_logits_from_QH,
    quadratic_logits_from_QL,
    realize_affine_score_by_eta,
    recover_alpha_beta_eta,
)


def test_lift_binary_shapes_and_identity():
    rng = np.random.default_rng(0)
    d, H, N = 7, 11, 40
    X = rng.standard_normal((N, d))
    W1 = rng.standard_normal((H, d))
    b1 = rng.standard_normal(H)
    w2 = rng.standard_normal(H)
    b2 = float(rng.standard_normal())

    Y, Q, Hvec = lift_binary(X, W1, b1, w2, b2)
    assert Y.shape == (N, H)
    assert Q.shape == (N,)
    assert Hvec.shape == (N,)

    # Verify the algebraic identity used in the proof of Theorem 1:
    # For p(u) = alpha*u^2 + beta*u + eta,
    #     F_tilde(x) = alpha * Q(x) + beta * H(x) + (1-beta) * b2 + eta * B
    alpha, beta, eta = 0.3, 1.2, -0.5
    B_sum = float(np.sum(w2))
    expected = np.zeros(N)
    for i in range(N):
        y = W1 @ X[i] + b1
        expected[i] = np.sum(w2 * (alpha * y ** 2 + beta * y + eta)) + b2
    reconstructed = quadratic_logits_from_QH(Q, Hvec, alpha, beta, eta, B_sum, b2)
    np.testing.assert_allclose(reconstructed, expected, atol=1e-10)


def test_realize_affine_score_by_eta_zero_threshold():
    # B != 0 case: eta is chosen so the score threshold is exactly zero.
    alpha, beta = 0.5, 1.0
    B_sum, b2 = 2.3, 0.4
    t_target = 1.7
    eta, dep_thr, zero_ok = realize_affine_score_by_eta(alpha, beta, t_target, B_sum, b2)
    assert zero_ok is True
    assert dep_thr == 0.0
    # Check: (1 - beta) b2 + eta * B_sum == -t_target
    np.testing.assert_allclose((1 - beta) * b2 + eta * B_sum, -t_target, atol=1e-12)


def test_realize_affine_score_by_eta_B_zero():
    # B = 0: eta has no effect, falls back to nonzero threshold.
    eta, dep_thr, zero_ok = realize_affine_score_by_eta(
        alpha=0.1, beta=0.9, t_target=3.0, B_sum=0.0, b2=2.0,
    )
    assert zero_ok is False
    assert eta == 0.0
    # dep_thr = t_target + (1-beta)*b2
    np.testing.assert_allclose(dep_thr, 3.0 + 0.1 * 2.0, atol=1e-12)


def test_recover_alpha_beta_eta():
    theta_bar = np.array([2.0, 3.0, 0.5, 4.0])
    a, b, e = recover_alpha_beta_eta(theta_bar)
    assert a == 0.5
    assert b == 0.75
    assert e == 0.125


def test_recover_rejects_nonpositive_lambda():
    with pytest.raises(ValueError):
        recover_alpha_beta_eta(np.array([1.0, 1.0, 1.0, 0.0]))
    with pytest.raises(ValueError):
        recover_alpha_beta_eta(np.array([1.0, 1.0, 1.0, -0.1]))


def test_multiclass_lifting_shapes():
    rng = np.random.default_rng(1)
    d, H, K, N = 5, 8, 4, 30
    X = rng.standard_normal((N, d))
    W1 = rng.standard_normal((H, d))
    b1 = rng.standard_normal(H)
    W2 = rng.standard_normal((K, H))
    b2 = rng.standard_normal(K)
    y_ref = rng.integers(0, K, size=N)

    Zbar, sample_idx, Y, Q, L, B = build_pairwise_lifted_constraints(X, W1, b1, W2, b2, y_ref)
    assert Zbar.shape == (N * (K - 1), 4)
    assert sample_idx.shape == (N * (K - 1),)
    # sample_idx should be [0,0,0,1,1,1,2,2,2, ...]
    np.testing.assert_array_equal(sample_idx, np.repeat(np.arange(N), K - 1))
    assert Q.shape == (N, K)
    assert L.shape == (N, K)
    assert B.shape == (K,)


def test_multiclass_pairwise_identity():
    """Verify bar_theta . z_{i,r} == Fk_yi(x_i) - Fk_r(x_i) when
    (alpha, beta, eta, 1) is used."""
    rng = np.random.default_rng(2)
    d, H, K, N = 4, 6, 3, 20
    X = rng.standard_normal((N, d))
    W1 = rng.standard_normal((H, d))
    b1 = rng.standard_normal(H)
    W2 = rng.standard_normal((K, H))
    b2 = rng.standard_normal(K)
    y_ref = rng.integers(0, K, size=N)

    alpha, beta, eta = 0.7, -0.3, 0.5
    Zbar, sample_idx, Y, Q, L, B = build_pairwise_lifted_constraints(X, W1, b1, W2, b2, y_ref)
    theta_bar = np.array([alpha, beta, eta, 1.0])
    margins = Zbar @ theta_bar    # shape (N*(K-1),)

    # Reconstruct via quadratic_logits_from_QL
    logits = quadratic_logits_from_QL(Q, L, alpha, beta, eta, B, b2)   # (N, K)
    # For each sample i, and each competitor r != y_ref[i], margin should equal
    # logits[i, y_ref[i]] - logits[i, r].
    idx = 0
    for i in range(N):
        yi = y_ref[i]
        for r in range(K):
            if r == yi:
                continue
            expected = logits[i, yi] - logits[i, r]
            np.testing.assert_allclose(margins[idx], expected, atol=1e-10)
            idx += 1
    assert idx == Zbar.shape[0]
