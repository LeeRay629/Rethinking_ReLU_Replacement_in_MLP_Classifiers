"""Unit tests for `quad4fhe.torch_adapter.extractor`."""
import numpy as np
import pytest
import torch
import torch.nn as nn

from quad4fhe.torch_adapter.extractor import (
    UnsupportedLayerError,
    extract_layer_weights,
    resolve_module_by_path,
)


# -----------------------------------------------------------------------------
# Model builders
# -----------------------------------------------------------------------------
class SimpleMLP(nn.Module):
    def __init__(self, d, h, k):
        super().__init__()
        self.fc1 = nn.Linear(d, h)
        self.act = nn.ReLU()
        self.fc2 = nn.Linear(h, k)
    def forward(self, x):
        return self.fc2(self.act(self.fc1(x)))


class MLPWithBN(nn.Module):
    def __init__(self, d, h, k):
        super().__init__()
        self.fc1 = nn.Linear(d, h)
        self.bn  = nn.BatchNorm1d(h)
        self.act = nn.ReLU()
        self.fc2 = nn.Linear(h, k)
    def forward(self, x):
        return self.fc2(self.act(self.bn(self.fc1(x))))


class MLPWithLN(nn.Module):
    def __init__(self, d, h, k):
        super().__init__()
        self.fc1 = nn.Linear(d, h)
        self.ln  = nn.LayerNorm(h)
        self.act = nn.ReLU()
        self.fc2 = nn.Linear(h, k)
    def forward(self, x):
        return self.fc2(self.act(self.ln(self.fc1(x))))


class MLPWithDropout(nn.Module):
    def __init__(self, d, h, k):
        super().__init__()
        self.fc1 = nn.Linear(d, h)
        self.act = nn.ReLU()
        self.drop = nn.Dropout(0.3)
        self.fc2 = nn.Linear(h, k)
    def forward(self, x):
        return self.fc2(self.drop(self.act(self.fc1(x))))


class NestedHead(nn.Module):
    """Simulates a frozen-backbone + head structure using dotted-path access."""
    def __init__(self, d, h, k):
        super().__init__()
        self.head = nn.Module()
        self.head.fc1 = nn.Linear(d, h)
        self.head.act = nn.ReLU()
        self.head.fc2 = nn.Linear(h, k)
    def forward(self, x):
        return self.head.fc2(self.head.act(self.head.fc1(x)))


# -----------------------------------------------------------------------------
# resolve_module_by_path
# -----------------------------------------------------------------------------
def test_resolve_by_string():
    m = SimpleMLP(5, 8, 3)
    assert resolve_module_by_path(m, "fc1") is m.fc1
    assert resolve_module_by_path(m, "fc2") is m.fc2


def test_resolve_by_dotted_path():
    m = NestedHead(5, 8, 3)
    assert resolve_module_by_path(m, "head.fc1") is m.head.fc1
    assert resolve_module_by_path(m, "head.fc2") is m.head.fc2


def test_resolve_by_module_reference():
    m = SimpleMLP(5, 8, 3)
    assert resolve_module_by_path(m, m.fc1) is m.fc1


def test_resolve_invalid_path():
    m = SimpleMLP(5, 8, 3)
    with pytest.raises(AttributeError):
        resolve_module_by_path(m, "does_not_exist")
    with pytest.raises(AttributeError):
        resolve_module_by_path(m, "fc1.does_not_exist")


# -----------------------------------------------------------------------------
# extract_layer_weights
# -----------------------------------------------------------------------------
def test_extract_simple_multiclass():
    torch.manual_seed(0)
    m = SimpleMLP(5, 8, 3).eval()
    info = extract_layer_weights(m, "fc1", "fc2", "relu", task="multiclass")
    assert info["W1"].shape == (8, 5)
    assert info["b1"].shape == (8,)
    assert info["W2"].shape == (3, 8)
    assert info["b2"].shape == (3,)
    assert info["num_classes"] == 3
    np.testing.assert_array_almost_equal(
        info["W1"], m.fc1.weight.detach().numpy().astype(np.float64), decimal=6,
    )


def test_extract_simple_binary():
    torch.manual_seed(0)
    m = SimpleMLP(5, 8, 1).eval()
    info = extract_layer_weights(m, "fc1", "fc2", "relu", task="binary")
    assert info["W1"].shape == (8, 5)
    assert info["W2"].shape == (8,)           # flattened
    assert isinstance(info["b2"], float)
    assert info["num_classes"] == 1


def test_binary_task_rejects_multiclass_head():
    m = SimpleMLP(5, 8, 3).eval()
    with pytest.raises(ValueError):
        extract_layer_weights(m, "fc1", "fc2", "relu", task="binary")


def test_multiclass_task_rejects_binary_head():
    m = SimpleMLP(5, 8, 1).eval()
    with pytest.raises(ValueError):
        extract_layer_weights(m, "fc1", "fc2", "relu", task="multiclass")


def test_dropout_is_ignored():
    torch.manual_seed(0)
    m = MLPWithDropout(5, 8, 3).eval()
    info = extract_layer_weights(m, "fc1", "fc2", "relu", task="multiclass")
    assert info["W1"].shape == (8, 5)
    assert any("Dropout" in line for line in info["structure_log"])


def test_layernorm_raises():
    m = MLPWithLN(5, 8, 3).eval()
    with pytest.raises(UnsupportedLayerError, match="LayerNorm"):
        extract_layer_weights(m, "fc1", "fc2", "relu", task="multiclass")


def test_nested_dotted_path():
    m = NestedHead(5, 8, 3).eval()
    info = extract_layer_weights(m, "head.fc1", "head.fc2", "relu", task="multiclass")
    assert info["W1"].shape == (8, 5)


# -----------------------------------------------------------------------------
# BN fold correctness — the critical numerical test
# -----------------------------------------------------------------------------
def test_bn_fold_is_numerically_correct():
    """The folded W1_eff, b1_eff must produce the same pre-activation output
    (in eval mode) as the original BN(fc1(x))."""
    torch.manual_seed(42)
    d, h = 7, 16
    m = MLPWithBN(d, h, 3)
    # Put BN into a realistic 'trained' state by doing a few forward passes in
    # train mode.
    m.train()
    for _ in range(20):
        x = torch.randn(32, d)
        m(x)
    m.eval()

    # Extract folded weights
    info = extract_layer_weights(m, "fc1", "fc2", "relu", task="multiclass")
    W1_eff = info["W1"]
    b1_eff = info["b1"]
    assert any("BatchNorm1d" in line for line in info["structure_log"])

    # Verify: for any x, W1_eff @ x + b1_eff == bn(fc1(x))
    rng = np.random.default_rng(0)
    for _ in range(5):
        x_np = rng.standard_normal(d).astype(np.float64)
        x_t = torch.tensor(x_np, dtype=torch.float32).unsqueeze(0)
        with torch.no_grad():
            expected = m.bn(m.fc1(x_t)).squeeze(0).numpy().astype(np.float64)
        actual = W1_eff @ x_np + b1_eff
        np.testing.assert_allclose(actual, expected, atol=1e-5)
