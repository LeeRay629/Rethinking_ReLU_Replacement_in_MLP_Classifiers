"""
quad4fhe.core.lifting
=====================

Implements the lifting maps from the theory:

* **Binary**:   Phi(x) = (Q(x), H(x))        (Definition 1.4)
* **Multi**:    \bar z_{i,r} = (dQ, dL, dB, db)   (Definition 2.5)

Also provides the algebraic identity that lets us evaluate the replaced-
model score purely from (Q, H) (binary) or (Q, L) (multi-class), plus small
helpers for threshold realisation and parameter recovery.
"""
from __future__ import annotations

from typing import Tuple

import numpy as np


# =============================================================================
# Binary-task lifting
# =============================================================================
def lift_binary(
    X: np.ndarray,
    W1: np.ndarray,
    b1: np.ndarray,
    w2: np.ndarray,
    b2: float,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Compute pre-activations Y and the 2D lifted representation (Q, H).

    For a binary single-hidden-layer MLP
        F(x) = sum_j w2_j * sigma(W1_j . x + b1_j) + b2,
    the replaced score with quadratic surrogate p(u) = alpha u^2 + beta u + eta
    equals

        F_tilde(x) = alpha * Q(x) + beta * H(x) + (1 - beta) * b2 + eta * B,

    where
        Q(x) = sum_j w2_j * y_j(x)^2,
        H(x) = sum_j w2_j * y_j(x) + b2,
        B    = sum_j w2_j,
        y_j(x) = W1_j . x + b1_j.

    Parameters
    ----------
    X  : (N, d) float
    W1 : (H, d) float
    b1 : (H,)   float
    w2 : (H,)   float
    b2 : scalar

    Returns
    -------
    Y : (N, H) — pre-activations (still useful for baselines)
    Q : (N,)
    H : (N,)
    """
    X = np.asarray(X, dtype=np.float64)
    W1 = np.asarray(W1, dtype=np.float64)
    b1 = np.asarray(b1, dtype=np.float64).reshape(-1)
    w2 = np.asarray(w2, dtype=np.float64).reshape(-1)
    b2 = float(b2)

    Y = X @ W1.T + b1[None, :]
    Q = np.sum((Y ** 2) * w2[None, :], axis=1)
    H_vec = np.sum(Y * w2[None, :], axis=1) + b2
    return Y, Q, H_vec


def quadratic_logits_from_QH(
    Q: np.ndarray,
    H: np.ndarray,
    alpha: float,
    beta: float,
    eta: float,
    B_sum: float,
    b2: float,
) -> np.ndarray:
    """Binary: reconstruct replaced-model scores from (Q, H).

        F_tilde(x) = alpha Q(x) + beta H(x) + (1 - beta) b2 + eta * B
    """
    return alpha * Q + beta * H + (1.0 - beta) * b2 + eta * B_sum


def realize_affine_score_by_eta(
    alpha: float,
    beta: float,
    t_target: float,
    B_sum: float,
    b2: float,
    tol: float = 1e-12,
) -> Tuple[float, float, bool]:
    """Solve for eta that places the target threshold t_target at score == 0.

    We have
        F_tilde(x) = alpha Q + beta H + C_{beta, eta}
        C_{beta, eta} = (1 - beta) b2 + eta * B

    Given a desired target threshold t_target (pre-constant), we want:
        C_{beta, eta} = -t_target.

    Returns
    -------
    eta : float
    fallback_threshold : float      — non-zero threshold used if B == 0
    zero_realized : bool            — whether deployment threshold is 0
    """
    base_const = (1.0 - beta) * b2
    if abs(B_sum) > tol:
        eta = (-t_target - base_const) / B_sum
        return float(eta), 0.0, True
    # B = 0 ⇒ eta has no effect; threshold must absorb what's left.
    return 0.0, float(t_target + base_const), False


# =============================================================================
# Multi-class pairwise lifting (Definition 2.5)
# =============================================================================
def _extract_mc_params(X, W1, b1, W2, b2):
    """Compute hidden pre-activations Y and the Q, L, B, b2 tensors used to
    build pairwise differences for multi-class.

    For a multi-class head F_k(x) = sum_j W2[k, j] * sigma(y_j(x)) + b2[k]:
        Q[i, k] = sum_j W2[k, j] y_j(x_i)^2
        L[i, k] = sum_j W2[k, j] y_j(x_i)
        B[k]    = sum_j W2[k, j]
    """
    X = np.asarray(X, dtype=np.float64)
    W1 = np.asarray(W1, dtype=np.float64)
    b1 = np.asarray(b1, dtype=np.float64).reshape(-1)
    W2 = np.asarray(W2, dtype=np.float64)
    b2 = np.asarray(b2, dtype=np.float64).reshape(-1)

    Y = X @ W1.T + b1[None, :]                  # (N, H)
    Q = (Y ** 2) @ W2.T                         # (N, K)
    L = Y @ W2.T                                # (N, K)
    B = np.sum(W2, axis=1)                      # (K,)
    return Y, Q, L, B, b2


def build_pairwise_lifted_constraints(
    X: np.ndarray,
    W1: np.ndarray,
    b1: np.ndarray,
    W2: np.ndarray,
    b2: np.ndarray,
    y_ref: np.ndarray,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """Construct the matrix Zbar of pairwise-difference constraints for
    multi-class (Theorem 2.4 + Proposition 2.7 homogeneous form).

    For every (sample i, competitor r != y_i), build the 4D row
        [ dQ_{i,r}, dL_{i,r}, dB_{i,r}, db_{i,r} ]
    such that requiring bar_theta^T * row >= 0 for all rows is equivalent to
    strict top-1 preservation.

    This implementation is fully vectorised — no Python loop over samples.

    Parameters
    ----------
    X      : (N, d) inputs
    W1     : (H, d), b1 : (H,)
    W2     : (K, H), b2 : (K,)
    y_ref  : (N,) int   — target labels (usually original-model predictions)

    Returns
    -------
    Zbar       : (N * (K-1), 4) constraint matrix
    sample_idx : (N * (K-1),)   which sample each row came from
    Y, Q, L, B : intermediate tensors (useful for baselines and HE export)
    """
    y_ref = np.asarray(y_ref, dtype=np.int64).reshape(-1)
    N = y_ref.shape[0]

    Y, Q, L, B, b2 = _extract_mc_params(X, W1, b1, W2, b2)
    K = Q.shape[1]

    rows = np.arange(N)
    # Correct-class slices
    Qc = Q[rows, y_ref][:, None]                # (N, 1)
    Lc = L[rows, y_ref][:, None]
    Bc = B[y_ref][:, None]
    bc = b2[y_ref][:, None]
    # Differences (N, K)
    dQ = Qc - Q
    dL = Lc - L
    dB = Bc - B[None, :]
    db = bc - b2[None, :]

    # Mask out the correct-class column
    mask = np.ones((N, K), dtype=bool)
    mask[rows, y_ref] = False

    Zbar = np.stack([
        dQ[mask], dL[mask], dB[mask], db[mask]
    ], axis=1).astype(np.float64)               # (N*(K-1), 4)
    sample_idx = np.repeat(np.arange(N, dtype=np.int64), K - 1)
    return Zbar, sample_idx, Y, Q, L, B


def quadratic_logits_from_QL(
    Q: np.ndarray,
    L: np.ndarray,
    alpha: float,
    beta: float,
    eta: float,
    B: np.ndarray,
    b2: np.ndarray,
) -> np.ndarray:
    """Multi-class: reconstruct replaced-model logits from (Q, L).

        F_k_tilde(x) = alpha Q[:, k] + beta L[:, k] + eta * B[k] + b2[k]
    """
    return alpha * Q + beta * L + eta * B[None, :] + b2[None, :]


def recover_alpha_beta_eta(theta_bar: np.ndarray) -> Tuple[float, float, float]:
    """Proposition 2.5 (multi-class): recover (alpha, beta, eta) from the
    homogenised 4D vector bar_theta = (u, v, w, lambda) with lambda > 0.
    """
    u, v, w, c = np.asarray(theta_bar, dtype=np.float64).reshape(-1).tolist()
    if c <= 0:
        raise ValueError(f"Recovery failed: lambda = {c} <= 0")
    return float(u / c), float(v / c), float(w / c)
