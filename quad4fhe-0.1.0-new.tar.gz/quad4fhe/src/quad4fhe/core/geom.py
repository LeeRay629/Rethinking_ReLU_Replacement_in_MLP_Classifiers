"""
quad4fhe.core.geom
==================

Geometric verification utilities:

* **Exact separation** (Theorem 1):
        min_{x+} theta^T Phi(x+) > max_{x-} theta^T Phi(x-)

* **RCH (Reduced Convex Hull) separation** (Definition 2.2, Theorem 4):
        min_{u in RCH_mu+(S+)} theta^T u > max_{v in RCH_mu-(S-)} theta^T v

* **Capped-simplex extrema**: the optimum of a linear functional over
    RCH_mu = { sum lambda_i z_i : sum lambda_i = 1, 0 <= lambda_i <= mu }
  can be computed in O(n log n) by sorting and filling the budget.

* **Quantization tolerances** (Corollary 1.2 and 2.4).
"""
from __future__ import annotations

from typing import Tuple

import numpy as np


# -----------------------------------------------------------------------------
# Capped-simplex extrema
# -----------------------------------------------------------------------------
def capped_simplex_min(scores: np.ndarray, mu: float, tol: float = 1e-12) -> float:
    """Minimum of sum_i lambda_i * scores[i] subject to
    sum lambda_i = 1 and 0 <= lambda_i <= mu (i.e. the RCH objective).

    The greedy solution: assign weight mu to the smallest scores until the
    total mass 1 is used up.
    """
    s = np.sort(np.asarray(scores, dtype=np.float64))
    rem, val, i, n = 1.0, 0.0, 0, len(s)
    while rem > tol:
        if i >= n:
            raise RuntimeError("capped simplex infeasible (mu too small)")
        w = min(mu, rem)
        val += w * s[i]
        rem -= w
        i += 1
    return float(val)


def capped_simplex_max(scores: np.ndarray, mu: float, tol: float = 1e-12) -> float:
    """Maximum counterpart of `capped_simplex_min`."""
    return -capped_simplex_min(-np.asarray(scores, dtype=np.float64), mu=mu, tol=tol)


# -----------------------------------------------------------------------------
# Separation verification
# -----------------------------------------------------------------------------
def verify_exact_separation(
    theta: np.ndarray,
    S_plus: np.ndarray,
    S_minus: np.ndarray,
    tol: float = 1e-9,
) -> Tuple[float, float, bool]:
    """Check whether theta strictly separates S+ from S- (Theorem 1/2).

    Returns
    -------
    P        = min_{u in S+}  theta^T u
    N        = max_{v in S-}  theta^T v
    feasible = (P > N + tol)
    """
    theta = np.asarray(theta, dtype=np.float64).reshape(-1)
    P = float(np.min(np.asarray(S_plus, dtype=np.float64) @ theta))
    N = float(np.max(np.asarray(S_minus, dtype=np.float64) @ theta))
    return P, N, bool(P > N + tol)


def verify_rch_separation(
    theta: np.ndarray,
    S_plus: np.ndarray,
    S_minus: np.ndarray,
    mu_p: float,
    mu_n: float,
    tol: float = 1e-9,
) -> Tuple[float, float, bool]:
    """Check whether theta strictly separates RCH_{mu+}(S+) from RCH_{mu-}(S-)
    (Theorem 4). Returns (P_mu, N_mu, feasible)."""
    theta = np.asarray(theta, dtype=np.float64).reshape(-1)
    S_plus = np.asarray(S_plus, dtype=np.float64)
    S_minus = np.asarray(S_minus, dtype=np.float64)
    P_mu = capped_simplex_min(S_plus @ theta, mu_p)
    N_mu = capped_simplex_max(S_minus @ theta, mu_n)
    return float(P_mu), float(N_mu), bool(P_mu > N_mu + tol)


# -----------------------------------------------------------------------------
# Quantization robustness (Corollaries 1.2 and 2.4)
# -----------------------------------------------------------------------------
def compute_quantization_robustness_exact(
    theta_star: np.ndarray,
    S_plus: np.ndarray,
    S_minus: np.ndarray,
) -> Tuple[float, float, float]:
    """Compute the exact-case quantization tolerance (Corollary 1.2):

        tol = rho* / M

    where rho* = min pairwise inner-product across positive/negative pairs
    and M = max_{x+, x-} ||Phi(x+) - Phi(x-)||_2.

    Returns (rho_star, M, tolerance).
    """
    theta_star = np.asarray(theta_star, dtype=np.float64).reshape(-1)
    S_plus = np.asarray(S_plus, dtype=np.float64)
    S_minus = np.asarray(S_minus, dtype=np.float64)

    diffs = S_plus[:, None, :] - S_minus[None, :, :]
    projections = np.einsum("ijk,k->ij", diffs, theta_star)
    rho_star = float(np.min(projections))
    M = float(np.max(np.linalg.norm(diffs, axis=2)))
    tol = rho_star / M if M > 1e-15 else float("inf")
    return rho_star, M, tol


def compute_quantization_robustness_rch(
    theta_star: np.ndarray,
    S_plus: np.ndarray,
    S_minus: np.ndarray,
    mu_p: float,
    mu_n: float,
) -> Tuple[float, float, float, float]:
    """Compute RCH-case quantization tolerance (Corollary 2.4):

        tol = delta_mu / (R_+ + R_-)

    where delta_mu = P_mu - N_mu and R_pm = max ||z|| over the respective
    reduced convex hulls (upper-bounded by the full sample-set radius).

    Returns (delta_mu, R_plus, R_minus, tolerance).
    """
    theta_star = np.asarray(theta_star, dtype=np.float64).reshape(-1)
    S_plus = np.asarray(S_plus, dtype=np.float64)
    S_minus = np.asarray(S_minus, dtype=np.float64)

    P_mu, N_mu, _ = verify_rch_separation(theta_star, S_plus, S_minus, mu_p, mu_n, tol=0.0)
    delta_mu = float(P_mu - N_mu)
    R_plus = float(np.max(np.linalg.norm(S_plus, axis=1)))
    R_minus = float(np.max(np.linalg.norm(S_minus, axis=1)))
    denom = R_plus + R_minus
    tol = delta_mu / denom if denom > 1e-15 else float("inf")
    return delta_mu, R_plus, R_minus, tol
