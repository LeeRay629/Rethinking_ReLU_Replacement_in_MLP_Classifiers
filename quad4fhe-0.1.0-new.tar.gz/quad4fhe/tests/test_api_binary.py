"""End-to-end integration test for `quad4fhe.replace` on a binary task."""
import numpy as np
import pytest
import torch

import quad4fhe
from tests.fixtures import SimpleBinaryMLP, make_binary_dataset, train_model


def test_binary_pipeline_end_to_end():
    X_tr, X_te, y_tr, y_te = make_binary_dataset(seed=42)
    model = SimpleBinaryMLP(in_dim=X_tr.shape[1], hidden_dim=16)
    model = train_model(model, X_tr, y_tr, task="binary", epochs=100)

    res = quad4fhe.replace(
        task="binary", model=model,
        hidden_layer="fc1", output_layer="fc2", activation="relu",
        fit_data=(X_tr, y_tr),
        test_data=(X_te, y_te),
        baselines=["square", "remez_2"],
        verbose=False,
    )

    # All core fields populated
    assert np.isfinite(res.alpha)
    assert np.isfinite(res.beta)
    assert np.isfinite(res.eta)
    assert res.threshold is not None
    assert res.method_used in ("hard", "soft") or res.method_used.startswith(("rch", "soft"))
    assert res.replaced_model is not None
    assert res.report_vs_pseudo is not None
    assert res.report_vs_truth is not None

    # Reports contain at least Original and Quad4FHE rows
    pseudo_methods = set(res.report_vs_pseudo["Method"].unique())
    assert "Original" in pseudo_methods
    assert "Quad4FHE" in pseudo_methods

    # Baselines dict should contain the requested entries
    assert res.baseline_results is not None
    assert "square" in res.baseline_results
    assert "remez_2" in res.baseline_results

    # Drop-in replaced model matches theoretical logits
    from quad4fhe.core.lifting import lift_binary, quadratic_logits_from_QH
    rm = res.replaced_model.eval()
    with torch.no_grad():
        logits_module = rm(torch.tensor(X_te, dtype=torch.float32)).cpu().numpy()
    _, Q, H_vec = lift_binary(X_te, res.W1, res.b1, res.W2, float(res.b2))
    logits_theory = quadratic_logits_from_QH(
        Q, H_vec, res.alpha, res.beta, res.eta,
        float(np.sum(res.W2)), float(res.b2),
    )
    diff = np.max(np.abs(logits_module - logits_theory))
    assert diff < 1e-4, f"Replaced module mismatch: {diff}"


def test_binary_method_hard_raises_if_infeasible():
    """When method='hard' is forced but hulls overlap, must raise."""
    # Construct a model whose (Q, H) hulls are known to overlap: use a highly
    # underparameterized and poorly-trained model (random weights) on low-
    # information data (standardised random noise).
    rng = np.random.default_rng(0)
    X_tr = rng.standard_normal((100, 8))                  # pure noise
    y_tr = rng.integers(0, 2, size=100)                   # random labels
    torch.manual_seed(0)
    model = SimpleBinaryMLP(in_dim=8, hidden_dim=2)       # tiny
    model.eval()                                          # untrained

    with pytest.raises(RuntimeError):
        quad4fhe.replace(
            task="binary", model=model,
            hidden_layer="fc1", output_layer="fc2", activation="relu",
            fit_data=(X_tr, y_tr),
            method="hard",
            verbose=False,
        )


def test_binary_return_module_false_gives_no_module():
    X_tr, _, y_tr, _ = make_binary_dataset(seed=42)
    model = SimpleBinaryMLP(X_tr.shape[1], 8)
    model = train_model(model, X_tr, y_tr, task="binary", epochs=50)
    res = quad4fhe.replace(
        task="binary", model=model,
        hidden_layer="fc1", output_layer="fc2", activation="relu",
        fit_data=(X_tr, y_tr),
        return_module=False,
        verbose=False,
    )
    assert res.replaced_model is None
