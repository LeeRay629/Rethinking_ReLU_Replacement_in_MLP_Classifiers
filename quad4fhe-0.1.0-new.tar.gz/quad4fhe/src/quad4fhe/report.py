"""
quad4fhe.report
===============

Build the two evaluation DataFrames that `quad4fhe.replace(...)` returns
when a test set is given:

* **report_vs_pseudo** — how well does each method agree with the original
  ReLU model's top-1 decisions?
* **report_vs_truth**  — how well does each method match the true labels?

Binary columns:      Method, Split, AUC, ACC, F1, Precision, Recall, Agreement
Multi-class columns: Method, Split, ACC, MacroF1, MacroPrec, MacroRec, AUC_ovr, Agreement
"""
from __future__ import annotations

from typing import Any, Dict, List, Optional

import numpy as np
import pandas as pd
from sklearn.metrics import (
    accuracy_score,
    f1_score,
    precision_score,
    recall_score,
    roc_auc_score,
)


# -----------------------------------------------------------------------------
# Helpers
# -----------------------------------------------------------------------------
def _softmax(x: np.ndarray) -> np.ndarray:
    z = x - np.max(x, axis=1, keepdims=True)
    ez = np.exp(z)
    return ez / np.sum(ez, axis=1, keepdims=True)


def _safe_auc_binary(y_true: np.ndarray, scores: np.ndarray) -> float:
    y_true = np.asarray(y_true)
    if len(np.unique(y_true)) < 2:
        return float("nan")
    return float(roc_auc_score(y_true, scores))


def _safe_auc_multiclass(y_true: np.ndarray, logits: np.ndarray, num_classes: int) -> float:
    try:
        return float(roc_auc_score(
            y_true, _softmax(logits),
            labels=np.arange(num_classes),
            multi_class="ovr", average="macro",
        ))
    except Exception:
        return float("nan")


def _predict_binary(logits: np.ndarray, threshold: float) -> np.ndarray:
    return (np.asarray(logits, dtype=np.float64) > float(threshold)).astype(int)


def _predict_multiclass(logits: np.ndarray) -> np.ndarray:
    return np.argmax(np.asarray(logits, dtype=np.float64), axis=1).astype(int)


# -----------------------------------------------------------------------------
# Per-row builders
# -----------------------------------------------------------------------------
def _row_binary(
    method_name: str, split: str,
    logits: np.ndarray, threshold: float,
    y_eval: np.ndarray,
    orig_logits: np.ndarray, orig_threshold: float,
) -> Dict[str, Any]:
    preds = _predict_binary(logits, threshold)
    orig_preds = _predict_binary(orig_logits, orig_threshold)
    return {
        "Method": method_name,
        "Split": split,
        "AUC": _safe_auc_binary(y_eval, logits),
        "ACC": float(accuracy_score(y_eval, preds)),
        "F1": float(f1_score(y_eval, preds, zero_division=0)),
        "Precision": float(precision_score(y_eval, preds, zero_division=0)),
        "Recall": float(recall_score(y_eval, preds, zero_division=0)),
        "Agreement": float(np.mean(preds == orig_preds)),
    }


def _row_multiclass(
    method_name: str, split: str,
    logits: np.ndarray,
    y_eval: np.ndarray,
    orig_logits: np.ndarray,
    num_classes: int,
) -> Dict[str, Any]:
    preds = _predict_multiclass(logits)
    orig_preds = _predict_multiclass(orig_logits)
    return {
        "Method": method_name,
        "Split": split,
        "ACC": float(accuracy_score(y_eval, preds)),
        "MacroF1": float(f1_score(y_eval, preds, average="macro", zero_division=0)),
        "MacroPrec": float(precision_score(y_eval, preds, average="macro", zero_division=0)),
        "MacroRec": float(recall_score(y_eval, preds, average="macro", zero_division=0)),
        "AUC_ovr": _safe_auc_multiclass(y_eval, logits, num_classes),
        "Agreement": float(np.mean(preds == orig_preds)),
    }


# -----------------------------------------------------------------------------
# Public builders
# -----------------------------------------------------------------------------
def build_binary_reports(
    methods_logits: Dict[str, Dict[str, np.ndarray]],
    methods_thresholds: Dict[str, float],
    orig_logits: Dict[str, np.ndarray],
    y_truth: Dict[str, np.ndarray],
    y_pseudo: Dict[str, np.ndarray],
    orig_threshold: float = 0.0,
    splits: Optional[List[str]] = None,
):
    """Returns (df_vs_pseudo, df_vs_truth)."""
    if splits is None:
        splits = [k for k in ["fit", "test"] if k in orig_logits]

    rows_pseudo: List[Dict[str, Any]] = []
    rows_truth: List[Dict[str, Any]] = []
    for method_name, by_split in methods_logits.items():
        thr = methods_thresholds.get(method_name, 0.0)
        for split in splits:
            if split not in by_split:
                continue
            logits = by_split[split]
            rows_pseudo.append(_row_binary(
                method_name, split, logits, thr,
                y_eval=y_pseudo[split],
                orig_logits=orig_logits[split],
                orig_threshold=orig_threshold,
            ))
            rows_truth.append(_row_binary(
                method_name, split, logits, thr,
                y_eval=y_truth[split],
                orig_logits=orig_logits[split],
                orig_threshold=orig_threshold,
            ))
    cols = ["Method", "Split", "AUC", "ACC", "F1", "Precision", "Recall", "Agreement"]
    return pd.DataFrame(rows_pseudo, columns=cols), pd.DataFrame(rows_truth, columns=cols)


def build_multiclass_reports(
    methods_logits: Dict[str, Dict[str, np.ndarray]],
    orig_logits: Dict[str, np.ndarray],
    y_truth: Dict[str, np.ndarray],
    y_pseudo: Dict[str, np.ndarray],
    num_classes: int,
    splits: Optional[List[str]] = None,
):
    """Returns (df_vs_pseudo, df_vs_truth)."""
    if splits is None:
        splits = [k for k in ["fit", "test"] if k in orig_logits]

    rows_pseudo: List[Dict[str, Any]] = []
    rows_truth: List[Dict[str, Any]] = []
    for method_name, by_split in methods_logits.items():
        for split in splits:
            if split not in by_split:
                continue
            logits = by_split[split]
            rows_pseudo.append(_row_multiclass(
                method_name, split, logits,
                y_eval=y_pseudo[split],
                orig_logits=orig_logits[split],
                num_classes=num_classes,
            ))
            rows_truth.append(_row_multiclass(
                method_name, split, logits,
                y_eval=y_truth[split],
                orig_logits=orig_logits[split],
                num_classes=num_classes,
            ))
    cols = ["Method", "Split", "ACC", "MacroF1", "MacroPrec", "MacroRec", "AUC_ovr", "Agreement"]
    return pd.DataFrame(rows_pseudo, columns=cols), pd.DataFrame(rows_truth, columns=cols)
