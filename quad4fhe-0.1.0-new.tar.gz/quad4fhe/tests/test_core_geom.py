"""Unit tests for `quad4fhe.core.geom`."""
import numpy as np
import pytest

from quad4fhe.core.geom import (
    capped_simplex_max,
    capped_simplex_min,
    compute_quantization_robustness_exact,
    compute_quantization_robustness_rch,
    verify_exact_separation,
    verify_rch_separation,
)


def test_capped_simplex_min_basic():
    scores = np.array([1.0, 5.0, 3.0, 2.0, 4.0])
    # mu=1 => min is just min(scores)
    assert capped_simplex_min(scores, mu=1.0) == pytest.approx(1.0, abs=1e-12)
    # mu=0.5 => use 2 smallest at 0.5 each: 0.5*1 + 0.5*2 = 1.5
    assert capped_simplex_min(scores, mu=0.5) == pytest.approx(1.5, abs=1e-12)
    # mu=0.3 => 0.3*1 + 0.3*2 + 0.3*3 + 0.1*4 = 0.3+0.6+0.9+0.4 = 2.2
    assert capped_simplex_min(scores, mu=0.3) == pytest.approx(2.2, abs=1e-12)


def test_capped_simplex_max():
    scores = np.array([1.0, 5.0, 3.0, 2.0, 4.0])
    assert capped_simplex_max(scores, mu=1.0) == pytest.approx(5.0, abs=1e-12)
    # mu=0.5 => 0.5*5 + 0.5*4 = 4.5
    assert capped_simplex_max(scores, mu=0.5) == pytest.approx(4.5, abs=1e-12)


def test_capped_simplex_infeasible():
    # If mu * n < 1, no convex combination exists
    scores = np.array([1.0, 2.0, 3.0])
    with pytest.raises(RuntimeError):
        capped_simplex_min(scores, mu=0.1)


def test_verify_exact_separation_success():
    # Two clusters clearly separable along x-axis
    S_plus = np.array([[5.0, 0.0], [6.0, 1.0], [5.5, -0.5]])
    S_minus = np.array([[-1.0, 0.0], [-2.0, 0.5], [-1.5, -0.3]])
    theta = np.array([1.0, 0.0])
    P, N, ok = verify_exact_separation(theta, S_plus, S_minus)
    assert ok is True
    assert P > N


def test_verify_exact_separation_failure():
    S_plus = np.array([[0.0, 0.0], [1.0, 1.0]])
    S_minus = np.array([[0.5, 0.5], [2.0, 2.0]])
    theta = np.array([1.0, 1.0])
    # The hulls overlap in this direction
    _, _, ok = verify_exact_separation(theta, S_plus, S_minus)
    assert ok is False


def test_verify_rch_separation_respects_mu():
    # A single-outlier case where standard hulls would fail but RCH succeeds
    S_plus = np.array([[10.0, 0.0]] + [[i, 0.0] for i in range(5)])  # one outlier at 10
    S_minus = np.array([[8.0, 0.0]] + [[-i, 0.0] for i in range(1, 6)])
    # Full hulls overlap (10 crosses -5); RCH with small mu down-weights the outlier.
    theta = np.array([-1.0, 0.0])     # want min over S-
    # With mu=1 it's technically still bad:
    _, _, bad = verify_rch_separation(theta, S_plus, S_minus, mu_p=1.0, mu_n=1.0)
    # With mu small, the averaging smooths out the outlier.
    # This is a sanity test; we primarily check the function runs without error.
    _, _, _ = verify_rch_separation(theta, S_plus, S_minus, mu_p=0.5, mu_n=0.5)


def test_quantization_robustness_exact_returns_positive_tol():
    S_plus = np.array([[5.0, 0.0], [6.0, 1.0]])
    S_minus = np.array([[-1.0, 0.0], [-2.0, 0.5]])
    theta = np.array([1.0, 0.0])
    rho, M, tol = compute_quantization_robustness_exact(theta, S_plus, S_minus)
    assert rho > 0
    assert M > 0
    assert tol > 0
    # Sanity: tol = rho / M
    np.testing.assert_allclose(tol, rho / M, rtol=1e-12)


def test_quantization_robustness_rch():
    S_plus = np.array([[5.0, 0.0], [6.0, 1.0], [5.5, -0.5]])
    S_minus = np.array([[-1.0, 0.0], [-2.0, 0.5], [-1.5, -0.3]])
    theta = np.array([1.0, 0.0])
    delta_mu, R_plus, R_minus, tol = compute_quantization_robustness_rch(
        theta, S_plus, S_minus, mu_p=1.0, mu_n=1.0,
    )
    assert delta_mu > 0
    assert R_plus > 0
    assert R_minus > 0
    assert tol > 0
