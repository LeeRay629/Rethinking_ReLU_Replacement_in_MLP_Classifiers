"""
quad4fhe.baselines._base — shared utilities for all baseline classes.
"""
from __future__ import annotations

from typing import Callable, Dict, Optional

import numpy as np


# -----------------------------------------------------------------------------
# Activation numpy implementations (independent of PyTorch, for pure-numpy
# baseline evaluation).
# -----------------------------------------------------------------------------
def _relu_np(x: np.ndarray) -> np.ndarray:
    return np.maximum(0.0, x)


def _gelu_np(x: np.ndarray) -> np.ndarray:
    from scipy.special import erf
    x = np.asarray(x, dtype=np.float64)
    return 0.5 * x * (1.0 + erf(x / np.sqrt(2.0)))


def _silu_np(x: np.ndarray) -> np.ndarray:
    x = np.asarray(x, dtype=np.float64)
    return x / (1.0 + np.exp(-x))


_ACT_FN_BY_NAME = {"relu": _relu_np, "gelu": _gelu_np, "silu": _silu_np}


def activation_numpy(name: str) -> Callable[[np.ndarray], np.ndarray]:
    """Look up the NumPy reference implementation of the given activation."""
    name = name.lower()
    if name not in _ACT_FN_BY_NAME:
        raise ValueError(f"Unsupported activation '{name}' for baselines. "
                         f"Supported: {list(_ACT_FN_BY_NAME)}")
    return _ACT_FN_BY_NAME[name]


def activation_error(
    poly_fn: Callable[[np.ndarray], np.ndarray],
    Y_ref: np.ndarray,
    activation: str,
    grid_points: int = 30000,
) -> tuple:
    """Compute (max_err, mean_err) of `poly_fn` against the reference activation
    on a uniform grid spanning Y_ref's range."""
    act_fn = activation_numpy(activation)
    flat = np.asarray(Y_ref, dtype=np.float64).reshape(-1)
    lo, hi = float(np.min(flat)), float(np.max(flat))
    if hi - lo < 1e-12:
        hi = lo + 1e-12
    grid = np.linspace(lo, hi, grid_points)
    err = poly_fn(grid) - act_fn(grid)
    return float(np.max(np.abs(err))), float(np.mean(np.abs(err)))


# -----------------------------------------------------------------------------
# Logit reconstruction utilities (binary vs multi-class)
# -----------------------------------------------------------------------------
def apply_scalar_activation_binary(
    Y: np.ndarray, w2: np.ndarray, b2: float,
    act_fn: Callable[[np.ndarray], np.ndarray],
) -> np.ndarray:
    """score(x) = sum_j w2[j] * act(Y[:, j]) + b2. Returns (N,) float64."""
    act = act_fn(Y)
    return np.sum(act * w2[None, :], axis=1) + b2


def apply_scalar_activation_multiclass(
    Y: np.ndarray, W2: np.ndarray, b2: np.ndarray,
    act_fn: Callable[[np.ndarray], np.ndarray],
) -> np.ndarray:
    """logits(x) = act(Y) @ W2.T + b2. Returns (N, K) float64."""
    act = act_fn(Y)
    return act @ W2.T + b2[None, :]


# -----------------------------------------------------------------------------
# Base class
# -----------------------------------------------------------------------------
class _BaseBaseline:
    """Base class for all baseline activation replacements.

    Subclasses override `.fit(Y_ref, activation)` and `.apply(Y)`.
    """
    name: str = "base"

    def fit(self, Y_ref: np.ndarray, activation: str) -> None:
        raise NotImplementedError

    def apply(self, Y: np.ndarray) -> np.ndarray:
        """Apply the fitted approximation element-wise to Y."""
        raise NotImplementedError

    # Convenience — each baseline populates these in .fit()
    max_err: Optional[float] = None
    mean_err: Optional[float] = None
    coeffs_info: Optional[Dict] = None       # populated by polynomial baselines

    def evaluate(
        self,
        Y_fit: np.ndarray, Y_test: np.ndarray,
        W2, b2,
        task: str,
    ) -> Dict[str, np.ndarray]:
        """Compute replacement logits on fit + test splits. Returns
        {"logits_fit": ..., "logits_test": ...}.
        """
        if task == "binary":
            return {
                "logits_fit": apply_scalar_activation_binary(Y_fit, W2, float(b2), self.apply),
                "logits_test": apply_scalar_activation_binary(Y_test, W2, float(b2), self.apply),
            }
        elif task == "multiclass":
            return {
                "logits_fit": apply_scalar_activation_multiclass(Y_fit, W2, np.asarray(b2), self.apply),
                "logits_test": apply_scalar_activation_multiclass(Y_test, W2, np.asarray(b2), self.apply),
            }
        else:
            raise ValueError(f"task must be 'binary' or 'multiclass', got '{task}'")
