"""Shared test fixtures for the quad4fhe test suite."""
from typing import Tuple

import numpy as np
import torch
import torch.nn as nn
from sklearn.datasets import make_classification
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler


def make_binary_dataset(seed: int = 42) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """Small well-separated binary dataset for fast tests."""
    X, y = make_classification(
        n_samples=300, n_features=8, n_informative=5, n_redundant=0,
        n_clusters_per_class=1, class_sep=2.0, random_state=seed,
    )
    X_tr, X_te, y_tr, y_te = train_test_split(X, y, test_size=0.3,
                                              random_state=seed, stratify=y)
    sc = StandardScaler().fit(X_tr)
    return sc.transform(X_tr), sc.transform(X_te), y_tr, y_te


def make_multiclass_dataset(n_classes: int = 4, seed: int = 42):
    X, y = make_classification(
        n_samples=400, n_features=16, n_informative=10,
        n_classes=n_classes, n_clusters_per_class=1,
        class_sep=1.5, random_state=seed,
    )
    X_tr, X_te, y_tr, y_te = train_test_split(X, y, test_size=0.25,
                                              random_state=seed, stratify=y)
    sc = StandardScaler().fit(X_tr)
    return sc.transform(X_tr), sc.transform(X_te), y_tr, y_te


class SimpleBinaryMLP(nn.Module):
    def __init__(self, in_dim: int, hidden_dim: int):
        super().__init__()
        self.fc1 = nn.Linear(in_dim, hidden_dim)
        self.act = nn.ReLU()
        self.fc2 = nn.Linear(hidden_dim, 1)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.fc2(self.act(self.fc1(x))).squeeze(-1)


class SimpleMulticlassMLP(nn.Module):
    def __init__(self, in_dim: int, hidden_dim: int, num_classes: int):
        super().__init__()
        self.fc1 = nn.Linear(in_dim, hidden_dim)
        self.act = nn.ReLU()
        self.fc2 = nn.Linear(hidden_dim, num_classes)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.fc2(self.act(self.fc1(x)))


class MLPWithBN(nn.Module):
    """MLP with BN in the block — used to verify fold correctness."""
    def __init__(self, in_dim: int, hidden_dim: int, num_classes: int):
        super().__init__()
        self.fc1 = nn.Linear(in_dim, hidden_dim)
        self.bn  = nn.BatchNorm1d(hidden_dim)
        self.act = nn.ReLU()
        self.fc2 = nn.Linear(hidden_dim, num_classes)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.fc2(self.act(self.bn(self.fc1(x))))


def train_model(model: nn.Module, X: np.ndarray, y: np.ndarray,
                task: str, epochs: int = 100, lr: float = 1e-2,
                seed: int = 0) -> nn.Module:
    """Quick-and-dirty training loop for smoke tests."""
    torch.manual_seed(seed)
    model.train()
    opt = torch.optim.Adam(model.parameters(), lr=lr)
    if task == "binary":
        loss_fn = nn.BCEWithLogitsLoss()
        y_t = torch.tensor(y, dtype=torch.float32)
    else:
        loss_fn = nn.CrossEntropyLoss()
        y_t = torch.tensor(y, dtype=torch.long)
    X_t = torch.tensor(X, dtype=torch.float32)
    for _ in range(epochs):
        opt.zero_grad()
        out = model(X_t)
        loss = loss_fn(out, y_t)
        loss.backward()
        opt.step()
    model.eval()
    return model
