"""
quad4fhe.torch_adapter.extractor
================================

Introspect a trained PyTorch model and pull out:

* The hidden layer `nn.Linear` weights (W1, b1)
* The output layer `nn.Linear` weights (W2, b2)
* The activation to be replaced (default: auto-detect ReLU/GELU/SiLU)

`nn.BatchNorm1d` layers sitting between the hidden Linear and the activation
are **folded** into effective W1_eff, b1_eff. Dropout and Identity layers are
**ignored**. LayerNorm raises `UnsupportedLayerError`.
"""
from __future__ import annotations

from typing import Tuple, Union

import numpy as np
import torch.nn as nn


class UnsupportedLayerError(RuntimeError):
    """Raised when the model contains a module between hidden_layer and
    output_layer that we don't know how to absorb automatically."""


# Modules we know how to ignore (identity in eval mode)
_IGNORABLE = (nn.Dropout, nn.Identity)
try:
    _IGNORABLE = _IGNORABLE + (nn.Dropout1d, nn.Dropout2d, nn.Dropout3d)   # type: ignore[attr-defined]
except AttributeError:  # pragma: no cover
    pass

# Activation module classes we recognise
_ACTIVATION_CLASSES = {
    "relu": nn.ReLU,
    "gelu": nn.GELU,
    "silu": nn.SiLU,
}


def resolve_module_by_path(model: nn.Module, path_or_module: Union[str, nn.Module]) -> nn.Module:
    """Resolve a layer spec (either a dotted-path string or a direct module
    reference) to the actual `nn.Module` inside `model`."""
    if isinstance(path_or_module, nn.Module):
        return path_or_module
    if not isinstance(path_or_module, str):
        raise TypeError(f"layer spec must be str or nn.Module, got {type(path_or_module)}")
    mod = model
    for part in path_or_module.split("."):
        if not hasattr(mod, part):
            raise AttributeError(
                f"Cannot resolve '{path_or_module}' in model: no attribute '{part}' "
                f"on {type(mod).__name__}"
            )
        mod = getattr(mod, part)
    return mod


def _is_ignorable(module: nn.Module) -> bool:
    return isinstance(module, _IGNORABLE)


def _is_bn1d(module: nn.Module) -> bool:
    return isinstance(module, nn.BatchNorm1d)


def _is_layernorm(module: nn.Module) -> bool:
    return isinstance(module, nn.LayerNorm)


def _match_activation(module: nn.Module, activation_spec: Union[str, nn.Module]) -> bool:
    """Check whether `module` is the activation we're looking for."""
    if isinstance(activation_spec, nn.Module):
        return module is activation_spec
    if isinstance(activation_spec, str):
        cls = _ACTIVATION_CLASSES.get(activation_spec.lower())
        if cls is None:
            raise ValueError(
                f"Unknown activation spec '{activation_spec}'. "
                f"Supported: {list(_ACTIVATION_CLASSES)} or a nn.Module instance."
            )
        return isinstance(module, cls)
    raise TypeError(f"activation spec must be str or nn.Module, got {type(activation_spec)}")


def _fold_batchnorm1d(
    W: np.ndarray, b: np.ndarray, bn: nn.BatchNorm1d
) -> Tuple[np.ndarray, np.ndarray]:
    """Fold a BatchNorm1d into effective linear weights.

    Given y = BN(W x + b) in eval mode:
        BN(u) = gamma * (u - running_mean) / sqrt(running_var + eps) + beta
              = s * u + t
    with s = gamma / sqrt(var + eps), t = -s * running_mean + beta.
    Therefore y = (s * W) x + (s * b + t), which we fold into
        W_eff = diag(s) @ W, b_eff = s * b + t.
    """
    if bn.running_mean is None or bn.running_var is None:
        raise UnsupportedLayerError(
            "BatchNorm1d has no running statistics (track_running_stats=False). "
            "Cannot fold."
        )
    gamma = (bn.weight.detach().cpu().numpy().astype(np.float64)
             if bn.weight is not None else np.ones(bn.num_features))
    beta = (bn.bias.detach().cpu().numpy().astype(np.float64)
            if bn.bias is not None else np.zeros(bn.num_features))
    rm = bn.running_mean.detach().cpu().numpy().astype(np.float64)
    rv = bn.running_var.detach().cpu().numpy().astype(np.float64)
    s = gamma / np.sqrt(rv + bn.eps)
    t = -s * rm + beta
    W_eff = s[:, None] * W
    b_eff = s * b + t
    return W_eff, b_eff


def _linear_to_numpy(lin: nn.Linear) -> Tuple[np.ndarray, np.ndarray]:
    W = lin.weight.detach().cpu().numpy().astype(np.float64)
    b = (lin.bias.detach().cpu().numpy().astype(np.float64)
         if lin.bias is not None else np.zeros(lin.out_features, dtype=np.float64))
    return W, b


def _collect_ordered_modules(model: nn.Module):
    """Return a list of (name, module) pairs in the order they would be visited
    during a forward pass (strictly speaking: pre-order DFS). Good enough for
    the classical single-block MLP structures we support."""
    return [(n, m) for n, m in model.named_modules() if m is not model]


def extract_layer_weights(
    model: nn.Module,
    hidden_layer: Union[str, nn.Module],
    output_layer: Union[str, nn.Module],
    activation: Union[str, nn.Module] = "relu",
    task: str = "binary",
) -> dict:
    """Inspect `model` and extract the BN-folded effective weights.

    Parameters
    ----------
    model : nn.Module
        The trained model (must be in eval mode before calling, otherwise
        BN running statistics may be off — we don't force eval() here to
        avoid side effects).
    hidden_layer, output_layer : str | nn.Module
        Dotted-path string or module reference.
    activation : str | nn.Module
        Which activation to look for between hidden and output. Only used for
        sanity-checking the block structure. Default: "relu".
    task : str
        "binary" or "multiclass". Controls the shape of returned (W2, b2).

    Returns
    -------
    dict with keys
        W1 : (H, d) float64
        b1 : (H,)   float64
        W2 : (H,)   float64     (binary)
           | (K, H) float64     (multi-class)
        b2 : float              (binary)
           | (K,)  float64      (multi-class)
        hidden_dim, input_dim, num_classes (if multi)
        structure_log : list[str]    human-readable trace of what was found/folded
    """
    if task not in ("binary", "multiclass"):
        raise ValueError(f"task must be 'binary' or 'multiclass', got '{task}'")

    hidden_mod = resolve_module_by_path(model, hidden_layer)
    output_mod = resolve_module_by_path(model, output_layer)
    if not isinstance(hidden_mod, nn.Linear):
        raise TypeError(f"hidden_layer must be nn.Linear, got {type(hidden_mod).__name__}")
    if not isinstance(output_mod, nn.Linear):
        raise TypeError(f"output_layer must be nn.Linear, got {type(output_mod).__name__}")

    W1, b1 = _linear_to_numpy(hidden_mod)
    W2, b2 = _linear_to_numpy(output_mod)

    # Sanity-check output shape w.r.t. task
    if task == "binary":
        if output_mod.out_features != 1:
            raise ValueError(
                f"task='binary' expects output_layer with out_features=1, "
                f"got {output_mod.out_features}. "
                f"Use task='multiclass' for multi-class models."
            )
        # Flatten to (H,) and scalar
        W2 = W2.reshape(-1)
        b2 = float(b2.reshape(-1)[0])
        num_classes = 1
    else:
        if output_mod.out_features < 2:
            raise ValueError(
                f"task='multiclass' expects output_layer with out_features>=2, "
                f"got {output_mod.out_features}."
            )
        num_classes = output_mod.out_features

    # Walk modules ordered as in forward pass; absorb BN / ignore dropout;
    # complain on unrecognised modules sitting between hidden_layer and
    # output_layer.
    all_mods = _collect_ordered_modules(model)
    hidden_idx = next((i for i, (_, m) in enumerate(all_mods) if m is hidden_mod), None)
    output_idx = next((i for i, (_, m) in enumerate(all_mods) if m is output_mod), None)
    if hidden_idx is None or output_idx is None:
        raise RuntimeError("Could not locate hidden_layer / output_layer inside model.")
    if output_idx < hidden_idx:
        raise RuntimeError(
            "output_layer appears before hidden_layer in the module ordering. "
            "Double-check your layer specs."
        )

    structure_log = [f"hidden_layer: {type(hidden_mod).__name__} "
                     f"(in={hidden_mod.in_features}, out={hidden_mod.out_features})"]
    activation_seen = False
    for name, mod in all_mods[hidden_idx + 1:output_idx]:
        # Skip sub-children of already-consumed containers (e.g. nn.Sequential
        # has .weight=None and its children are already listed individually)
        if len(list(mod.children())) > 0:
            continue
        if _is_ignorable(mod):
            structure_log.append(f"  ignoring {type(mod).__name__} at '{name}'")
            continue
        if _is_bn1d(mod):
            if activation_seen:
                raise UnsupportedLayerError(
                    f"BatchNorm1d '{name}' appears AFTER the activation — this is "
                    "not supported by the quadratic substitution theory (the theory "
                    "assumes BN is folded into W1). Move BN before activation."
                )
            W1, b1 = _fold_batchnorm1d(W1, b1, mod)
            structure_log.append(
                f"  folded BatchNorm1d at '{name}' (num_features={mod.num_features})"
            )
            continue
        if _is_layernorm(mod):
            raise UnsupportedLayerError(
                f"LayerNorm at '{name}' between hidden and output layers is not "
                "supported by automatic folding (sample-dependent statistics). "
                "Replace LN with BN, remove it, or use `extractor=<custom>`."
            )
        if _match_activation(mod, activation):
            structure_log.append(f"  found activation {type(mod).__name__} at '{name}' "
                                 "(will be replaced)")
            activation_seen = True
            continue
        # Unknown module — complain loudly
        raise UnsupportedLayerError(
            f"Unrecognised module {type(mod).__name__} at '{name}' between "
            f"hidden_layer and output_layer. Supported: nn.Linear (at the ends), "
            f"nn.BatchNorm1d (folded), nn.Dropout/Identity (ignored), and the "
            f"specified activation. For custom structures, pass `extractor=<fn>`."
        )

    if not activation_seen:
        raise UnsupportedLayerError(
            "No activation layer found between hidden_layer and output_layer. "
            "If your model applies the activation via a functional call in "
            "forward(), please use `extractor=<custom>` or refactor to a "
            "module form."
        )

    structure_log.append(f"output_layer: {type(output_mod).__name__} "
                         f"(in={output_mod.in_features}, out={output_mod.out_features})")

    return {
        "W1": W1, "b1": b1, "W2": W2, "b2": b2,
        "input_dim": hidden_mod.in_features,
        "hidden_dim": hidden_mod.out_features,
        "num_classes": num_classes,
        "structure_log": structure_log,
    }
