"""
quad4fhe.api
============

The top-level user-facing function `quad4fhe.replace(...)`. This module
orchestrates the full pipeline:

    1. Inspect model, extract BN-folded W1/b1/W2/b2.
    2. Run forward pass on fit_data (optionally through a frozen backbone)
       to obtain original-model logits + pseudo-labels.
    3. Build the lifted representation (Q, H) for binary or the bias-free
       pairwise-difference matrix Zbar=(dQ,dL,dB,db) for multi-class.
    4. Solve:
       - Binary: try Hard (RCH @ mu=1), then RCH scan, then Theorem 5 primal.
       - Multi:  try Hard-margin QP (Prop 2.6(1)), then soft-margin sweep (2.6(2)).
    5. Scan quantization granularity and report the smallest safe decimals.
    6. If `test_data` given, produce the two evaluation DataFrames.
    7. If `baselines` given, run them under the same pipeline and add them
       to the reports + HE artifact export.
    8. If `export_he_dir` given, write artifacts to disk.
    9. If `return_module=True`, deep-copy the model with the activation swapped
       for QuadraticActivation.

Non-trivial printed log is emitted when verbose=True; the structure follows
the sectioned style used in the authors' reproducibility scripts.
"""
from __future__ import annotations

import random
from typing import Any, Dict, List, Optional, Tuple, Union

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from torch.utils.data import DataLoader

from quad4fhe.baselines.registry import build_baseline, expand_baseline_list
from quad4fhe.core.geom import (
    verify_exact_separation,
    verify_rch_separation,
)
from quad4fhe.core.lifting import (
    build_pairwise_lifted_constraints,
    lift_binary,
    quadratic_logits_from_QH,
    quadratic_logits_from_QL,
    realize_affine_score_by_eta,
)
from quad4fhe.core.solvers import (
    HAS_OSQP_DIRECT,
    solve_mc_hard_margin,
    solve_mc_soft_margin,
    solve_mc_soft_margin_batch_osqp,
    solve_rch_distance,
    solve_theorem5_primal,
)
from quad4fhe.export import export_he_artifacts
from quad4fhe.quant import (
    min_safe_decimals,
    scan_quantization_binary,
    scan_quantization_multiclass,
)
from quad4fhe.report import (
    build_binary_reports,
    build_multiclass_reports,
)
from quad4fhe.result import ReplacementResult
from quad4fhe.torch_adapter.extractor import extract_layer_weights
from quad4fhe.torch_adapter.replace import build_replaced_model


# =============================================================================
# Printing helpers (mirror author reproducibility scripts)
# =============================================================================
def _sep(title: str, verbose: bool):
    if verbose:
        print("\n" + "=" * 78)
        print(title)
        print("=" * 78)


def _sub(title: str, verbose: bool):
    if verbose:
        print("\n" + "-" * 78)
        print(title)
        print("-" * 78)


def _log(msg: str, verbose: bool):
    if verbose:
        print(msg)


# =============================================================================
# Data ingestion helpers
# =============================================================================
def _unpack_data_arg(
    data: Optional[Any],
    name: str,
) -> Tuple[Optional[np.ndarray], Optional[np.ndarray]]:
    """Accept either a (X, y) tuple / list of two ndarrays or a DataLoader."""
    if data is None:
        return None, None
    # (X, y) numpy pair
    if isinstance(data, (tuple, list)) and len(data) == 2:
        X, y = data
        X = np.asarray(X, dtype=np.float64)
        y = np.asarray(y, dtype=np.int64).reshape(-1)
        if X.shape[0] != y.shape[0]:
            raise ValueError(f"{name}: X.shape[0]={X.shape[0]} != y.shape[0]={y.shape[0]}")
        return X, y
    # DataLoader
    if isinstance(data, DataLoader):
        Xs, ys = [], []
        for batch in data:
            if isinstance(batch, (tuple, list)) and len(batch) == 2:
                xb, yb = batch
            else:
                raise ValueError(
                    f"{name}: DataLoader batches must be (X, y) pairs; "
                    f"got a batch of type {type(batch)}"
                )
            xb_np = xb.detach().cpu().numpy() if torch.is_tensor(xb) else np.asarray(xb)
            yb_np = yb.detach().cpu().numpy() if torch.is_tensor(yb) else np.asarray(yb)
            Xs.append(xb_np.reshape(xb_np.shape[0], -1).astype(np.float64))
            ys.append(yb_np.reshape(-1).astype(np.int64))
        return np.concatenate(Xs, axis=0), np.concatenate(ys, axis=0)
    raise TypeError(
        f"{name} must be (X, y) or torch.utils.data.DataLoader; got {type(data).__name__}"
    )


def _run_backbone(
    backbone: nn.Module, X_np: np.ndarray,
    device: torch.device, batch_size: int = 256,
) -> np.ndarray:
    """Run a frozen backbone forward and flatten the outputs."""
    backbone.eval()
    # Match backbone's parameter dtype (usually float32).
    try:
        bb_dtype = next(backbone.parameters()).dtype
    except StopIteration:
        bb_dtype = torch.float32
    outs: List[np.ndarray] = []
    with torch.no_grad():
        for i in range(0, X_np.shape[0], batch_size):
            xb = torch.as_tensor(X_np[i:i + batch_size], dtype=bb_dtype).to(device)
            ob = backbone(xb)
            if torch.is_tensor(ob):
                arr = ob.detach().cpu().numpy()
            else:
                # Some backbones (e.g. HuggingFace) return a struct; try .last_hidden_state[:, 0, :]
                try:
                    arr = ob.last_hidden_state[:, 0, :].detach().cpu().numpy()
                except AttributeError as e:
                    raise RuntimeError(
                        f"Backbone output of type {type(ob)} is not a tensor and "
                        "has no `.last_hidden_state` attribute; please pre-extract "
                        "features manually and pass them directly as fit_data."
                    ) from e
            outs.append(arr.reshape(arr.shape[0], -1).astype(np.float64))
    return np.concatenate(outs, axis=0)


def _predict_model_logits(
    model: nn.Module, X_np: np.ndarray,
    device: torch.device, batch_size: int = 1024,
) -> np.ndarray:
    """Forward through the full model to obtain (N,) binary scores or (N, K) logits."""
    model.eval()
    try:
        m_dtype = next(model.parameters()).dtype
    except StopIteration:
        m_dtype = torch.float32
    outs: List[np.ndarray] = []
    with torch.no_grad():
        for i in range(0, X_np.shape[0], batch_size):
            xb = torch.as_tensor(X_np[i:i + batch_size], dtype=m_dtype).to(device)
            ob = model(xb)
            arr = ob.detach().cpu().numpy().astype(np.float64)
            if arr.ndim == 1:
                outs.append(arr)
            elif arr.ndim == 2 and arr.shape[1] == 1:
                outs.append(arr.reshape(-1))
            else:
                outs.append(arr)
    return np.concatenate(outs, axis=0)


# =============================================================================
# Default grids
# =============================================================================
_DEFAULT_MU_GRID = [0.80, 0.60, 0.40, 0.30, 0.20, 0.15, 0.10, 0.08, 0.05, 0.03, 0.02, 0.01]
_DEFAULT_SOFT_C_GRID = [1e-3, 1e-2, 1e-1, 1.0, 10.0, 100.0]


# =============================================================================
# Diagnostics helpers used for calibration/test decision-preservation reporting
# =============================================================================
def _predictions_from_logits(task: str, logits: np.ndarray, threshold: float = 0.0) -> np.ndarray:
    logits = np.asarray(logits, dtype=np.float64)
    if task == "binary":
        return (logits.reshape(-1) > float(threshold)).astype(np.int64)
    return np.argmax(logits, axis=1).astype(np.int64)


def _agreement_diagnostics(
    *,
    task: str,
    orig_logits: Optional[np.ndarray],
    repl_logits: Optional[np.ndarray],
    repl_threshold: float = 0.0,
    split: str,
) -> Optional[Dict[str, Any]]:
    """Agreement of the replacement with the original ReLU decision on one split."""
    if orig_logits is None or repl_logits is None:
        return None
    y_orig = _predictions_from_logits(task, orig_logits, 0.0)
    y_repl = _predictions_from_logits(task, repl_logits, repl_threshold if task == "binary" else 0.0)
    mismatch = int(np.sum(y_orig != y_repl))
    n = int(y_orig.shape[0])
    return {
        "split": split,
        "n": n,
        "agreement": float(1.0 - mismatch / max(n, 1)),
        "mismatch_count": mismatch,
        "exact_preserved": bool(mismatch == 0),
    }


def _multiclass_margin_diagnostics(
    Zbar: np.ndarray,
    theta_bar: np.ndarray,
    n_samples: int,
    num_classes: int,
    tol: float = 1e-12,
) -> Dict[str, Any]:
    """Margin/slack diagnostics for MC-H/MC-S.

    The soft-margin variable in the paper is per-sample: xi_i covers all
    K-1 competitor constraints for sample i. We therefore report both
    per-sample slack and pairwise-row slack.
    """
    Zbar = np.asarray(Zbar, dtype=np.float64)
    theta_bar = np.asarray(theta_bar, dtype=np.float64).reshape(-1)
    margins = Zbar @ theta_bar
    km1 = max(int(num_classes) - 1, 1)
    margins_2d = margins.reshape(int(n_samples), km1)
    min_by_sample = margins_2d.min(axis=1)
    sample_slack = np.maximum(0.0, 1.0 - min_by_sample)
    pair_slack = np.maximum(0.0, 1.0 - margins)
    decision_bad = min_by_sample <= tol
    return {
        "num_pairwise_constraints": int(Zbar.shape[0]),
        "min_pairwise_margin": float(np.min(margins)),
        "normalized_min_pairwise_margin": float(np.min(margins) / max(np.linalg.norm(theta_bar), 1e-15)),
        "calib_agreement": float(np.mean(~decision_bad)),
        "calib_mismatch_count": int(np.sum(decision_bad)),
        "exact_preserved": bool(not np.any(decision_bad)),
        "slack_positive_count": int(np.sum(sample_slack > tol)),
        "sum_slack": float(np.sum(sample_slack)),
        "mean_slack": float(np.mean(sample_slack)),
        "max_slack": float(np.max(sample_slack)),
        "pairwise_slack_positive_count": int(np.sum(pair_slack > tol)),
        "pairwise_sum_slack": float(np.sum(pair_slack)),
        "pairwise_max_slack": float(np.max(pair_slack)),
    }


# =============================================================================
# Binary solver pipeline
# =============================================================================
def _solve_binary(
    Q_fit: np.ndarray, H_fit: np.ndarray, y_ref_fit: np.ndarray,
    method: str, mu_grid: List[float],
    verbose: bool,
) -> Dict[str, Any]:
    """Solve the binary substitution problem. Returns a dict with theta,
    method_used, feasible, margin, threshold (via midpoint)."""
    S = np.column_stack([Q_fit, H_fit])
    S_plus = S[y_ref_fit == 1]
    S_minus = S[y_ref_fit == 0]

    # === Attempt: Hard-margin via standard convex hulls (mu=1) ===
    if method in ("auto", "hard"):
        _log("Attempting exact lossless substitution (Theorems 1-3, mu=1) ...", verbose)
        exact = solve_rch_distance(S_plus, S_minus, mu_p=1.0, mu_n=1.0)
        if exact["theta_hat"] is not None:
            P, N, feasible = verify_exact_separation(exact["theta_hat"], S_plus, S_minus)
            if feasible and exact["delta"] > 1e-7:
                rho = (P - N) / max(np.linalg.norm(exact["theta_hat"]), 1e-15)
                t_mid = 0.5 * (P + N)
                _log(f"  exact separation OK: delta={exact['delta']:.8f}, "
                     f"P={P:.6f} > N={N:.6f}, rho={rho:.6f}", verbose)
                return {
                    "theta": np.asarray(exact["theta_hat"], dtype=np.float64),
                    "method_used": "hard",
                    "feasible": True,
                    "empirical_margin": float(P - N),
                    "normalized_margin": float(rho),
                    "t_mid": float(t_mid),
                    "mu_p": 1.0, "mu_n": 1.0,
                    "S_plus": S_plus, "S_minus": S_minus,
                }
            _log(f"  exact failed (delta={exact['delta']:.8f}, P-N={P - N:+.6f}); "
                 "falling back to RCH scan.", verbose)
        if method == "hard":
            raise RuntimeError("Hard-margin exact separation is infeasible.")

    # === Attempt: RCH scan (Theorem 4) ===
    if method in ("auto", "rch"):
        _log("Scanning RCH parameter mu ...", verbose)
        best_rch: Optional[Dict[str, Any]] = None
        n_p, n_n = len(S_plus), len(S_minus)
        mu_floor_p, mu_floor_n = 1.0 / max(n_p, 1), 1.0 / max(n_n, 1)
        for mu_base in mu_grid:
            mu_p = max(mu_base, mu_floor_p)
            mu_n = max(mu_base, mu_floor_n)
            dres = solve_rch_distance(S_plus, S_minus, mu_p=mu_p, mu_n=mu_n)
            th = dres["theta_hat"]
            if th is None:
                _log(f"  mu={mu_base:>5.3f}  delta~0 (infeasible)", verbose)
                continue
            P_mu, N_mu, ok = verify_rch_separation(th, S_plus, S_minus, mu_p, mu_n)
            _log(f"  mu={mu_base:>5.3f}  delta={dres['delta']:>10.6f}  "
                 f"gap={P_mu - N_mu:>+.6f}  feasible={ok!s:>5}", verbose)
            if ok and dres["delta"] > 1e-7:
                # Prefer the largest feasible mu (closest to standard hull).
                if best_rch is None or mu_p > best_rch["mu_p"]:
                    best_rch = {
                        "theta_hat": th, "delta": dres["delta"],
                        "P_mu": P_mu, "N_mu": N_mu,
                        "mu_p": mu_p, "mu_n": mu_n,
                    }

        if best_rch is not None:
            theta_hat = best_rch["theta_hat"]
            rho = (best_rch["P_mu"] - best_rch["N_mu"]) / max(np.linalg.norm(theta_hat), 1e-15)
            t_mid = 0.5 * (best_rch["P_mu"] + best_rch["N_mu"])
            _log(f"Selected mu=({best_rch['mu_p']:.3f}, {best_rch['mu_n']:.3f}), "
                 f"delta_mu={best_rch['delta']:.6f}, rho={rho:.6f}", verbose)
            return {
                "theta": np.asarray(theta_hat, dtype=np.float64),
                "method_used": f"rch(mu={best_rch['mu_p']:.3f})",
                "feasible": False,   # hard wasn't feasible; surrogate only
                "empirical_margin": float(best_rch["P_mu"] - best_rch["N_mu"]),
                "normalized_margin": float(rho),
                "t_mid": float(t_mid),
                "mu_p": float(best_rch["mu_p"]),
                "mu_n": float(best_rch["mu_n"]),
                "S_plus": S_plus, "S_minus": S_minus,
            }
        if method == "rch":
            raise RuntimeError("RCH separation is infeasible for all mu values.")

    # === Final: Theorem 5 primal (soft) ===
    if method in ("auto", "soft"):
        _log("Falling back to Theorem 5 primal (soft-margin) ...", verbose)
        # Use a small, moderate C; user can customise later.
        primal = solve_theorem5_primal(S_plus, S_minus, c_p=0.5, c_n=0.5)
        theta = np.asarray(primal["theta"], dtype=np.float64)
        t = float(primal["t"])
        P, N, ok = verify_exact_separation(theta, S_plus, S_minus)
        rho = (P - N) / max(np.linalg.norm(theta), 1e-15)
        _log(f"  theta={theta.tolist()}, t={t:.6f}, status={primal['status']}", verbose)
        return {
            "theta": theta,
            "method_used": "soft",
            "feasible": bool(ok),
            "empirical_margin": float(P - N),
            "normalized_margin": float(rho),
            "t_mid": t,
            "mu_p": None, "mu_n": None,
            "S_plus": S_plus, "S_minus": S_minus,
        }

    raise ValueError(f"Unknown method='{method}'.")


# =============================================================================
# Multi-class solver pipeline
# =============================================================================
def _solve_multiclass(
    Zbar: np.ndarray, sample_idx: np.ndarray, n_samples: int, num_classes: int,
    method: str,
    soft_C_grid: List[float],
    use_cutting_plane: Any,
    use_osqp_warmstart: Any,
    verbose: bool,
) -> Dict[str, Any]:
    """Solve the multi-class substitution problem. Returns a dict with alpha,
    beta, eta, method_used, feasible, margin."""
    # === Attempt: Hard-margin (Prop 2.6(1)) ===
    if method in ("auto", "hard"):
        _log("Attempting multi-class hard-margin QP (Proposition 2.6(1)) ...", verbose)
        hard = solve_mc_hard_margin(Zbar, use_cutting_plane=use_cutting_plane,
                                    verbose=verbose, _print=lambda s: _log(s, verbose))
        if hard.feasible and hard.theta_bar is not None:
            theta_bar = hard.theta_bar
            margins = Zbar @ theta_bar
            min_m = float(np.min(margins))
            norm_bar = float(np.linalg.norm(theta_bar))
            rho = min_m / max(norm_bar, 1e-15)
            _log(f"  hard-margin OK (solver={hard.solver}, min_margin={min_m:.6f})", verbose)
            diagnostics = _multiclass_margin_diagnostics(Zbar, theta_bar, n_samples, num_classes)
            return {
                "alpha": hard.alpha, "beta": hard.beta, "eta": hard.eta,
                "method_used": "hard",
                "feasible": True,
                "empirical_margin": min_m,
                "normalized_margin": rho,
                "theta_bar": theta_bar,
                "solver_diagnostics": diagnostics,
            }
        _log(f"  hard-margin infeasible (status={hard.status}); "
             "falling back to soft-margin sweep.", verbose)
        if method == "hard":
            raise RuntimeError(f"Hard-margin infeasible: {hard.status}")

    # === Attempt: Soft-margin (Prop 2.6(2)) ===
    if method in ("auto", "soft"):
        use_osqp = (use_osqp_warmstart is True) or (
            use_osqp_warmstart == "auto" and HAS_OSQP_DIRECT and n_samples > 5000
        )
        _log(f"Running multi-class soft-margin sweep over C ({'OSQP warm-start' if use_osqp else 'scipy'}) ...",
             verbose)
        if use_osqp and HAS_OSQP_DIRECT:
            results = solve_mc_soft_margin_batch_osqp(Zbar, sample_idx, n_samples, soft_C_grid)
            soft_candidates = []
            for C, res in results.items():
                if res.feasible:
                    soft_candidates.append((C, res))
        else:
            soft_candidates = []
            for C in soft_C_grid:
                res = solve_mc_soft_margin(Zbar, sample_idx, n_samples, num_classes, C,
                                           method="scipy")
                if res.feasible:
                    soft_candidates.append((C, res))

        if not soft_candidates:
            raise RuntimeError("No soft-margin C value produced a feasible solution.")

        # Pick the best by:
        #   1) calibration agreement (all K-1 pairwise margins positive for a sample),
        #   2) smaller aggregate per-sample hinge slack,
        #   3) larger worst-case margin, and
        #   4) smaller coefficient norm.
        soft_scored = []
        for C, res in soft_candidates:
            diag = _multiclass_margin_diagnostics(Zbar, res.theta_bar, n_samples, num_classes)
            soft_scored.append((C, res, diag))

        def _score(triple):
            C, res, diag = triple
            return (
                diag["calib_agreement"],
                -diag["sum_slack"],
                diag["min_pairwise_margin"],
                -float(np.linalg.norm(res.theta_bar)),
            )

        best_C, best, best_diag = max(soft_scored, key=_score)
        theta_bar = best.theta_bar
        margins = Zbar @ theta_bar
        min_m = float(np.min(margins))
        norm_bar = float(np.linalg.norm(theta_bar))
        rho = min_m / max(norm_bar, 1e-15)
        soft_trace = []
        for C, res, diag in soft_scored:
            soft_trace.append({
                "C": float(C),
                "objective": float(res.objective) if res.objective is not None else None,
                "calib_agreement": diag["calib_agreement"],
                "calib_mismatch_count": diag["calib_mismatch_count"],
                "min_pairwise_margin": diag["min_pairwise_margin"],
                "sum_slack": diag["sum_slack"],
                "max_slack": diag["max_slack"],
                "slack_positive_count": diag["slack_positive_count"],
            })
        solver_diag = dict(best_diag)
        solver_diag.update({
            "soft_C_grid": [float(c) for c in soft_C_grid],
            "selected_C": float(best_C),
            "soft_trace": soft_trace,
        })
        _log(f"  best C={best_C}, min_margin={min_m:.6f}, "
             f"calib_agreement={best_diag['calib_agreement']:.6f}, "
             f"sum_slack={best_diag['sum_slack']:.6f}, status={best.status}", verbose)
        return {
            "alpha": best.alpha, "beta": best.beta, "eta": best.eta,
            "method_used": f"soft(C={best_C})",
            "feasible": False,   # hard wasn't feasible; surrogate only
            "empirical_margin": min_m,
            "normalized_margin": rho,
            "theta_bar": theta_bar,
            "solver_diagnostics": solver_diag,
        }

    raise ValueError(f"Unknown method='{method}'.")


# =============================================================================
# Top-level replace()
# =============================================================================
def replace(
    *,
    task: str,
    model: nn.Module,
    hidden_layer: Union[str, nn.Module],
    output_layer: Union[str, nn.Module],
    activation: Union[str, nn.Module] = "relu",
    fit_data: Any,
    backbone: Optional[nn.Module] = None,
    method: str = "auto",
    mu_grid: Optional[List[float]] = None,
    soft_C_grid: Optional[List[float]] = None,
    use_cutting_plane: Any = "auto",
    use_osqp_warmstart: Any = "auto",
    test_data: Optional[Any] = None,
    baselines: Union[None, str, List[str]] = None,
    return_module: bool = True,
    export_he_dir: Optional[str] = None,
    verbose: bool = True,
    seed: int = 2026,
) -> ReplacementResult:
    """One-line end-to-end quadratic substitution pipeline.

    See README and docstrings of individual sub-modules for details.
    """
    # ---- Preamble ----
    if task not in ("binary", "multiclass"):
        raise ValueError(f"task must be 'binary' or 'multiclass', got '{task}'")
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)

    mu_grid = list(mu_grid) if mu_grid is not None else list(_DEFAULT_MU_GRID)
    soft_C_grid = list(soft_C_grid) if soft_C_grid is not None else list(_DEFAULT_SOFT_C_GRID)
    device = next(model.parameters()).device
    model.eval()

    # =============================================================
    # Step 1: extract folded weights
    # =============================================================
    _sep("Step 1: Extract folded model weights", verbose)
    weights = extract_layer_weights(
        model, hidden_layer=hidden_layer, output_layer=output_layer,
        activation=activation, task=task,
    )
    W1, b1 = weights["W1"], weights["b1"]
    W2, b2 = weights["W2"], weights["b2"]
    input_dim = weights["input_dim"]
    num_classes = weights["num_classes"]
    if verbose:
        for line in weights["structure_log"]:
            print(line)
    _log(f"W1: {W1.shape}, b1: {b1.shape}", verbose)
    if task == "binary":
        _log(f"w2: {W2.shape}, b2: {b2:.6f}", verbose)
    else:
        _log(f"W2: {W2.shape}, b2: {b2.shape}, num_classes={num_classes}", verbose)

    # =============================================================
    # Step 2: ingest data and compute pseudo-labels
    # =============================================================
    _sep("Step 2: Ingest fit_data / test_data and compute original-model predictions",
         verbose)
    X_fit_raw, y_fit_true = _unpack_data_arg(fit_data, "fit_data")
    X_test_raw, y_test_true = _unpack_data_arg(test_data, "test_data")

    # Apply backbone if given.
    if backbone is not None:
        backbone.eval()
        _log("Running frozen backbone forward on fit_data ...", verbose)
        X_fit = _run_backbone(backbone, X_fit_raw, device)
        if X_test_raw is not None:
            _log("Running frozen backbone forward on test_data ...", verbose)
            X_test = _run_backbone(backbone, X_test_raw, device)
        else:
            X_test = None
    else:
        X_fit = X_fit_raw
        X_test = X_test_raw

    if X_fit.shape[1] != input_dim:
        raise ValueError(
            f"fit_data feature dim ({X_fit.shape[1]}) != expected input_dim ({input_dim}). "
            "If your model takes raw images, pass a backbone; if you've already "
            "pre-extracted features, ensure dims match the hidden Linear's in_features."
        )

    # Original-model logits must come from the FULL model on the RAW inputs.
    # (When a backbone is given, X_fit is the backbone output; we feed the raw
    # inputs to `model` instead.)
    X_fit_for_model = X_fit_raw
    X_test_for_model = X_test_raw
    orig_logits_fit = _predict_model_logits(model, X_fit_for_model, device)
    if X_test_for_model is not None:
        orig_logits_test = _predict_model_logits(model, X_test_for_model, device)
    else:
        orig_logits_test = None

    # Pseudo-labels = argmax/threshold of original model.
    if task == "binary":
        y_ref_fit = (orig_logits_fit > 0.0).astype(np.int64)
        y_ref_test = (orig_logits_test > 0.0).astype(np.int64) if orig_logits_test is not None else None
    else:
        y_ref_fit = np.argmax(orig_logits_fit, axis=1).astype(np.int64)
        y_ref_test = (np.argmax(orig_logits_test, axis=1).astype(np.int64)
                      if orig_logits_test is not None else None)
    _log(f"Original model on fit: {len(y_ref_fit)} samples, "
         f"class counts = {np.bincount(y_ref_fit).tolist()}", verbose)

    # =============================================================
    # Step 3: lift + solve
    # =============================================================
    _sep("Step 3: Build lifted representation and solve", verbose)

    if task == "binary":
        Y_fit, Q_fit, H_fit = lift_binary(X_fit, W1, b1, W2, b2)
        Y_test = None
        Q_test = None
        H_test = None
        if X_test is not None:
            Y_test, Q_test, H_test = lift_binary(X_test, W1, b1, W2, b2)

        sol = _solve_binary(Q_fit, H_fit, y_ref_fit, method, mu_grid, verbose)
        alpha, beta = float(sol["theta"][0]), float(sol["theta"][1])
        B_sum = float(np.sum(W2))

        # Realise eta so the midpoint threshold lies at zero if possible.
        eta, deploy_threshold, zero_realized = realize_affine_score_by_eta(
            alpha, beta, sol["t_mid"], B_sum, float(b2),
        )
        method_used = sol["method_used"]
        feasible = sol["feasible"]
        emp_margin = sol["empirical_margin"]
        norm_margin = sol["normalized_margin"]
        S_plus = sol["S_plus"]
        S_minus = sol["S_minus"]
        mu_p_sel, mu_n_sel = sol["mu_p"], sol["mu_n"]
        solver_diagnostics = {
            "regime": method_used,
            "mu_grid": [float(mu) for mu in mu_grid],
            "mu_p": None if mu_p_sel is None else float(mu_p_sel),
            "mu_n": None if mu_n_sel is None else float(mu_n_sel),
        }
        Zbar = None
    else:
        Zbar, sample_idx, Y_fit, Q_fit, L_fit, B_vec = build_pairwise_lifted_constraints(
            X_fit, W1, b1, W2, b2, y_ref_fit,
        )
        Y_test = None
        Q_test = None
        L_test = None
        if X_test is not None:
            Zbar_test, _, Y_test, Q_test, L_test, _ = build_pairwise_lifted_constraints(
                X_test, W1, b1, W2, b2, y_ref_test,
            )
        n_samples = X_fit.shape[0]
        sol = _solve_multiclass(
            Zbar, sample_idx, n_samples, num_classes, method,
            soft_C_grid, use_cutting_plane, use_osqp_warmstart, verbose,
        )
        alpha = float(sol["alpha"])
        beta = float(sol["beta"])
        eta = float(sol["eta"])
        method_used = sol["method_used"]
        feasible = sol["feasible"]
        emp_margin = sol["empirical_margin"]
        norm_margin = sol["normalized_margin"]
        solver_diagnostics = sol.get("solver_diagnostics", {})
        solver_diagnostics.setdefault("regime", method_used)
        solver_diagnostics.setdefault("constraint_version", "multiclass_bias_free_dL_v1")
        deploy_threshold = None
        zero_realized = None
        mu_p_sel, mu_n_sel = None, None
        S_plus = None
        S_minus = None

    _log(f"\nResult: alpha={alpha:+.10f}  beta={beta:+.10f}  eta={eta:+.10f}", verbose)
    if task == "binary":
        _log(f"Threshold tau = {deploy_threshold:+.10f} "
             f"(zero_threshold_realized={zero_realized})", verbose)

    # =============================================================
    # Step 4: quantization scan
    # =============================================================
    _sep("Step 4: Quantization robustness scan (1..7 decimals)", verbose)
    if task == "binary":
        scan = scan_quantization_binary(
            alpha, beta, eta, S_plus, S_minus,
            mu_p=mu_p_sel, mu_n=mu_n_sel,
        )
    else:
        scan = scan_quantization_multiclass(alpha, beta, eta, Zbar)
    qd = min_safe_decimals(scan)
    if verbose:
        for row in scan:
            flag = "<-- SELECTED" if row.decimals == qd else ""
            print(f"  {row.decimals}dp  delta={row.delta_theta_l2:.10f}  "
                  f"within_tol={row.within_tolerance!s:>5}  "
                  f"sep_ok={row.separation_preserved!s:>5}  gap={row.gap:+.6f}  {flag}")
        if qd == 0:
            print("  No decimal level preserved separation; quant_decimals = 0 (do not quantize).")
        else:
            print(f"  Minimum safe decimal places: {qd}")

    # =============================================================
    # Step 5: build replaced module
    # =============================================================
    replaced_model = None
    if return_module:
        _sep("Step 5: Build drop-in replaced model", verbose)
        replaced_model = build_replaced_model(
            original_model=model,
            alpha=alpha, beta=beta, eta=eta,
            hidden_layer=hidden_layer, output_layer=output_layer,
            activation=activation,
        )
        replaced_model = replaced_model.to(device)
        _log("  built (QuadraticActivation in place of original activation).", verbose)

    # =============================================================
    # Step 6: compute replacement + baseline logits (for reports + export)
    # =============================================================
    _sep("Step 6: Compute replacement and baseline logits", verbose)

    if task == "binary":
        quad_logits_fit = quadratic_logits_from_QH(Q_fit, H_fit, alpha, beta, eta, B_sum, float(b2))
        quad_logits_test = (quadratic_logits_from_QH(Q_test, H_test, alpha, beta, eta, B_sum, float(b2))
                            if Q_test is not None else None)
    else:
        quad_logits_fit = quadratic_logits_from_QL(Q_fit, L_fit, alpha, beta, eta, B_vec, b2)
        quad_logits_test = (quadratic_logits_from_QL(Q_test, L_test, alpha, beta, eta, B_vec, b2)
                            if Q_test is not None else None)

    fit_diagnostics = _agreement_diagnostics(
        task=task, orig_logits=orig_logits_fit, repl_logits=quad_logits_fit,
        repl_threshold=float(deploy_threshold) if task == "binary" else 0.0, split="fit",
    )
    test_diagnostics = _agreement_diagnostics(
        task=task, orig_logits=orig_logits_test, repl_logits=quad_logits_test,
        repl_threshold=float(deploy_threshold) if task == "binary" else 0.0, split="test",
    )
    if solver_diagnostics is None:
        solver_diagnostics = {}
    solver_diagnostics.setdefault("fit_exact_preserved", None if fit_diagnostics is None else fit_diagnostics["exact_preserved"])
    solver_diagnostics.setdefault("fit_mismatch_count", None if fit_diagnostics is None else fit_diagnostics["mismatch_count"])
    solver_diagnostics.setdefault("fit_agreement", None if fit_diagnostics is None else fit_diagnostics["agreement"])

    # --- Baselines ---
    baseline_names = expand_baseline_list(baselines)
    baseline_results: Dict[str, Dict[str, Any]] = {}
    act_str = activation if isinstance(activation, str) else "relu"

    for bname in baseline_names:
        baseline = build_baseline(bname, act_str)
        if baseline is None:
            continue
        _log(f"Fitting baseline '{bname}' ...", verbose)
        baseline.fit(Y_fit, act_str)
        eva = baseline.evaluate(
            Y_fit=Y_fit,
            Y_test=Y_test if Y_test is not None else Y_fit,
            W2=W2, b2=b2, task=task,
        )
        # If no test_data given, discard the dummy fit-as-test logits
        if Y_test is None:
            eva["logits_test"] = None
        baseline_results[bname] = {
            "max_err": baseline.max_err,
            "mean_err": baseline.mean_err,
            "coeffs_info": baseline.coeffs_info,
            "logits_fit": eva["logits_fit"],
            "logits_test": eva["logits_test"],
        }
        _log(f"  {bname}: max_err={baseline.max_err:.6e}, mean_err={baseline.mean_err:.6e}",
             verbose)

    # =============================================================
    # Step 7: evaluation reports
    # =============================================================
    report_vs_pseudo = None
    report_vs_truth = None
    if X_test is not None and y_test_true is not None:
        _sep("Step 7: Build evaluation reports (vs pseudo-labels and vs truth)", verbose)

        # Assemble {method: {split: logits}}
        methods_logits: Dict[str, Dict[str, np.ndarray]] = {
            "Original": {"fit": orig_logits_fit, "test": orig_logits_test},
            "Quad4FHE": {"fit": quad_logits_fit, "test": quad_logits_test},
        }
        methods_thresholds: Dict[str, float] = {
            "Original": 0.0,
            "Quad4FHE": float(deploy_threshold) if task == "binary" else 0.0,
        }
        for bname, bres in baseline_results.items():
            if bres["logits_test"] is None:
                continue
            methods_logits[bname] = {"fit": bres["logits_fit"], "test": bres["logits_test"]}
            if task == "binary":
                # Baselines don't have a principled threshold — use 0.
                methods_thresholds[bname] = 0.0

        y_truth_dict = {"fit": y_fit_true, "test": y_test_true}
        y_pseudo_dict = {"fit": y_ref_fit, "test": y_ref_test}
        orig_logits_dict = {"fit": orig_logits_fit, "test": orig_logits_test}

        if task == "binary":
            report_vs_pseudo, report_vs_truth = build_binary_reports(
                methods_logits, methods_thresholds, orig_logits_dict,
                y_truth=y_truth_dict, y_pseudo=y_pseudo_dict,
                orig_threshold=0.0, splits=["fit", "test"],
            )
        else:
            report_vs_pseudo, report_vs_truth = build_multiclass_reports(
                methods_logits, orig_logits_dict,
                y_truth=y_truth_dict, y_pseudo=y_pseudo_dict,
                num_classes=num_classes, splits=["fit", "test"],
            )

        if verbose:
            with pd.option_context('display.float_format', '{:.4f}'.format):
                print("\n--- Report vs pseudo-labels (agreement with original model) ---")
                print(report_vs_pseudo.to_string(index=False))
                print("\n--- Report vs ground truth ---")
                print(report_vs_truth.to_string(index=False))

    # =============================================================
    # Step 8: HE artifact export
    # =============================================================
    he_dir_abs = None
    if export_he_dir is not None:
        if X_test is None or y_test_true is None:
            _log("WARNING: export_he_dir was given but test_data is missing — "
                 "HE artifacts need a test set. Skipping export.", verbose)
        else:
            _sep(f"Step 8: Export HE artifacts to {export_he_dir}", verbose)
            schemes_to_export: List[Dict[str, Any]] = []

            # Primary scheme: Quad4FHE
            quad_scheme = {
                "name": "quad4fhe",
                "display_name": "Quad4FHE",
                "degree": 2,
                "coeffs": [eta, beta, alpha],            # ascending: c0 + c1*x + c2*x^2
                "coeffs_order": "ascending",
                "logits_test": quad_logits_test,
                "notes": f"method={method_used}; feasible={feasible}",
            }
            if task == "binary":
                quad_scheme["threshold"] = float(deploy_threshold)
            else:
                quad_scheme["threshold"] = 0.0
            schemes_to_export.append(quad_scheme)

            # Polynomial baselines
            for bname, bres in baseline_results.items():
                if bres["logits_test"] is None or bres["coeffs_info"] is None:
                    continue
                ci = bres["coeffs_info"]
                if "coeffs_ascending" not in ci:
                    # Non-polynomial baselines (e.g. precise_a11, OLA-in-z) can't be
                    # exported as a single-variable polynomial over x — skip.
                    _log(f"  skipping baseline '{bname}' from HE export "
                         f"(no plain-x polynomial representation).", verbose)
                    continue
                schemes_to_export.append({
                    "name": bname,
                    "display_name": bname,
                    "degree": int(ci["degree"]),
                    "coeffs": ci["coeffs_ascending"],
                    "coeffs_order": "ascending",
                    "logits_test": bres["logits_test"],
                    "threshold": 0.0,
                    "notes": f"max_err={bres['max_err']:.6e}",
                })

            he_dir_abs = export_he_artifacts(
                out_dir=export_he_dir,
                task=task,
                W1=W1, b1=b1, W2=W2, b2=b2,
                X_test=X_test, y_test_true=y_test_true,
                relu_pred_test=y_ref_test,
                relu_logits_test=orig_logits_test,
                schemes=schemes_to_export,
                relu_threshold=0.0,
                verbose=verbose,
            )

    # =============================================================
    # Assemble the final result
    # =============================================================
    result = ReplacementResult(
        alpha=alpha, beta=beta, eta=eta,
        threshold=deploy_threshold, zero_threshold_realized=zero_realized,
        method_used=method_used, feasible=bool(feasible),
        empirical_margin=float(emp_margin),
        normalized_margin=float(norm_margin),
        quant_decimals=int(qd),
        quant_scan=scan,
        W1=W1, b1=b1, W2=W2, b2=b2,
        replaced_model=replaced_model,
        report_vs_pseudo=report_vs_pseudo,
        report_vs_truth=report_vs_truth,
        baseline_results=baseline_results if baseline_results else None,
        he_export_dir=he_dir_abs,
        fit_diagnostics=fit_diagnostics,
        test_diagnostics=test_diagnostics,
        solver_diagnostics=solver_diagnostics,
        constraint_version=("binary_QH_v1" if task == "binary" else "multiclass_bias_free_dL_v1"),
    )
    if verbose:
        print("\n" + result.summary())
    return result
