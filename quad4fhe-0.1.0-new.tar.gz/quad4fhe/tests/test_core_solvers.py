"""Unit tests for `quad4fhe.core.solvers`."""
import numpy as np

from quad4fhe.core.geom import verify_exact_separation
from quad4fhe.core.solvers import (
    solve_mc_hard_margin,
    solve_mc_soft_margin,
    solve_rch_distance,
    solve_theorem5_primal,
)


# -----------------------------------------------------------------------------
# Binary RCH-distance solver
# -----------------------------------------------------------------------------
def test_rch_distance_separated_clusters():
    """Two well-separated clusters → positive distance, correct separator direction."""
    rng = np.random.default_rng(0)
    S_plus = rng.standard_normal((20, 2)) + np.array([5.0, 0.0])
    S_minus = rng.standard_normal((20, 2)) + np.array([-5.0, 0.0])
    res = solve_rch_distance(S_plus, S_minus, mu_p=1.0, mu_n=1.0)
    assert res["delta"] > 0.5          # clearly separated
    assert res["theta_hat"] is not None
    # theta_hat should point roughly along +x axis
    assert res["theta_hat"][0] > 0.8
    # And it separates the data
    _, _, ok = verify_exact_separation(res["theta_hat"], S_plus, S_minus)
    assert ok


def test_rch_distance_overlapping_hulls_produces_zero():
    """When S+ and S- overlap, the RCH distance with mu=1 should be ~0."""
    rng = np.random.default_rng(1)
    S_plus = rng.standard_normal((15, 2))
    S_minus = rng.standard_normal((15, 2))         # same distribution → overlap
    res = solve_rch_distance(S_plus, S_minus, mu_p=1.0, mu_n=1.0)
    assert res["delta"] < 1e-2          # close to zero


def test_rch_distance_with_mu_restores_feasibility():
    """Overlapping clusters may become RCH-separable at small enough mu."""
    rng = np.random.default_rng(2)
    S_plus = rng.standard_normal((40, 2)) + np.array([0.5, 0.0])
    S_minus = rng.standard_normal((40, 2)) - np.array([0.5, 0.0])
    # mu=1: probably not strictly separable
    # mu=0.2: shrinks each hull toward its centroid and should separate
    res = solve_rch_distance(S_plus, S_minus, mu_p=0.2, mu_n=0.2)
    assert res["delta"] > 0


# -----------------------------------------------------------------------------
# Binary Theorem 5 primal
# -----------------------------------------------------------------------------
def test_theorem5_primal_runs_and_returns_finite():
    rng = np.random.default_rng(3)
    S_plus = rng.standard_normal((10, 2)) + np.array([3.0, 0.0])
    S_minus = rng.standard_normal((10, 2)) - np.array([3.0, 0.0])
    res = solve_theorem5_primal(S_plus, S_minus, c_p=0.5, c_n=0.5)
    assert np.all(np.isfinite(res["theta"]))
    assert np.isfinite(res["t"])
    assert np.isfinite(res["rho"])
    # With separated clusters, rho should be positive.
    assert res["rho"] > 0


# -----------------------------------------------------------------------------
# Multi-class hard-margin
# -----------------------------------------------------------------------------
def _build_mc_trivially_feasible_Zbar(n_constraints: int = 20, seed: int = 0):
    """A set of 4D rows that all point into the positive orthant, with the
    4th coord positive — so the problem min 0.5||x||^2 s.t. Zbar x >= 1,
    x[3] >= 1 is certainly feasible."""
    rng = np.random.default_rng(seed)
    Z = np.abs(rng.standard_normal((n_constraints, 4))) + 0.5
    return Z


def test_mc_hard_margin_feasible():
    Zbar = _build_mc_trivially_feasible_Zbar()
    res = solve_mc_hard_margin(Zbar, use_cutting_plane=False)
    assert res.feasible
    assert res.theta_bar is not None
    # Check: all margins >= 1 (up to solver tolerance)
    margins = Zbar @ res.theta_bar
    assert np.min(margins) >= 1.0 - 1e-4
    # lambda >= 1
    assert res.theta_bar[3] >= 1.0 - 1e-4


def test_mc_hard_margin_cutting_plane_converges():
    """Cutting-plane mode must reach the same optimum as the exact mode (up to tol)."""
    Zbar = _build_mc_trivially_feasible_Zbar(n_constraints=200, seed=7)
    exact = solve_mc_hard_margin(Zbar, use_cutting_plane=False)
    cp = solve_mc_hard_margin(
        Zbar, use_cutting_plane=True, cp_init=20, cp_batch=20, cp_max_rounds=20,
    )
    assert exact.feasible and cp.feasible
    # Objective values should match to a few digits
    np.testing.assert_allclose(exact.objective, cp.objective, rtol=1e-3)


# -----------------------------------------------------------------------------
# Multi-class soft-margin
# -----------------------------------------------------------------------------
def test_mc_soft_margin_scipy_runs():
    Zbar = _build_mc_trivially_feasible_Zbar(n_constraints=30, seed=10)
    n_samples = 10
    num_classes = 4                # Zbar rows / n_samples + 1 = 30/10 + 1 = 4
    # Reshape Zbar to have 3 rows per sample so sample_idx makes sense
    Zbar = Zbar[:n_samples * (num_classes - 1)]
    sample_idx = np.repeat(np.arange(n_samples), num_classes - 1)
    res = solve_mc_soft_margin(Zbar, sample_idx, n_samples, num_classes,
                               C_penalty=1.0, method="scipy")
    assert res.feasible
    assert res.theta_bar is not None
    assert res.theta_bar[3] >= 1.0 - 1e-4
