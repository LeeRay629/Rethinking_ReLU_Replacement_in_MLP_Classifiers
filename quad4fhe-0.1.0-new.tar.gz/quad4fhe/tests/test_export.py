"""Unit tests for `quad4fhe.export`."""
import json
import os

import numpy as np
import pytest

from quad4fhe.export import export_he_artifacts


# -----------------------------------------------------------------------------
# Binary export
# -----------------------------------------------------------------------------
def test_binary_export_creates_all_files(tmp_path):
    rng = np.random.default_rng(0)
    H, d, N = 16, 8, 50
    W1 = rng.standard_normal((H, d))
    b1 = rng.standard_normal(H)
    w2 = rng.standard_normal(H)
    b2 = float(rng.standard_normal())
    X_test = rng.standard_normal((N, d))
    y_test_true = rng.integers(0, 2, size=N)
    relu_pred = rng.integers(0, 2, size=N)
    relu_logits = rng.standard_normal(N)

    schemes = [
        {
            "name": "quad4fhe", "display_name": "Quad4FHE",
            "degree": 2, "coeffs": [0.0, 1.0, 0.3],   # ascending
            "coeffs_order": "ascending",
            "threshold": 0.1,
            "logits_test": rng.standard_normal(N),
            "notes": "unit test",
        },
    ]

    out_dir = export_he_artifacts(
        out_dir=str(tmp_path / "he_out"), task="binary",
        W1=W1, b1=b1, W2=w2, b2=b2,
        X_test=X_test, y_test_true=y_test_true,
        relu_pred_test=relu_pred, relu_logits_test=relu_logits,
        schemes=schemes,
    )

    # All expected files exist
    expected = [
        "W1.bin", "b1.bin", "w2.bin", "b2.bin",
        "X_test.bin", "y_test_true.bin", "y_test_relu.bin", "relu_logits_test.bin",
        "coeffs_quad4fhe.bin", "logits_quad4fhe.bin",
        "schemes.txt", "meta.txt", "meta.json",
    ]
    for fn in expected:
        assert os.path.exists(os.path.join(out_dir, fn)), f"missing {fn}"


def test_binary_export_roundtrip(tmp_path):
    rng = np.random.default_rng(0)
    H, d, N = 8, 5, 30
    W1 = rng.standard_normal((H, d)).astype(np.float64)
    b1 = rng.standard_normal(H).astype(np.float64)
    w2 = rng.standard_normal(H).astype(np.float64)
    b2 = 0.5
    X_test = rng.standard_normal((N, d)).astype(np.float64)
    y_test_true = np.zeros(N, dtype=np.int32)
    relu_pred = np.ones(N, dtype=np.int32)
    relu_logits = rng.standard_normal(N).astype(np.float64)

    schemes = [{
        "name": "test_scheme", "degree": 2,
        "coeffs": [0.1, 0.2, 0.3], "coeffs_order": "ascending",
        "threshold": 0.0, "logits_test": rng.standard_normal(N).astype(np.float64),
    }]

    out_dir = export_he_artifacts(
        out_dir=str(tmp_path / "bin_out"), task="binary",
        W1=W1, b1=b1, W2=w2, b2=b2,
        X_test=X_test, y_test_true=y_test_true,
        relu_pred_test=relu_pred, relu_logits_test=relu_logits,
        schemes=schemes,
    )

    # Read back and compare
    W1_rt = np.fromfile(os.path.join(out_dir, "W1.bin"), dtype=np.float64).reshape(H, d)
    b1_rt = np.fromfile(os.path.join(out_dir, "b1.bin"), dtype=np.float64)
    w2_rt = np.fromfile(os.path.join(out_dir, "w2.bin"), dtype=np.float64)
    X_rt = np.fromfile(os.path.join(out_dir, "X_test.bin"), dtype=np.float64).reshape(N, d)
    y_rt = np.fromfile(os.path.join(out_dir, "y_test_true.bin"), dtype=np.int32)

    np.testing.assert_array_equal(W1, W1_rt)
    np.testing.assert_array_equal(b1, b1_rt)
    np.testing.assert_array_equal(w2, w2_rt)
    np.testing.assert_array_equal(X_test, X_rt)
    np.testing.assert_array_equal(y_test_true.astype(np.int32), y_rt)

    with open(os.path.join(out_dir, "meta.json")) as f:
        meta = json.load(f)
    assert meta["task"] == "binary"
    assert meta["input_dim"] == d
    assert meta["hidden_dim"] == H


# -----------------------------------------------------------------------------
# Multi-class export
# -----------------------------------------------------------------------------
def test_multiclass_export_roundtrip(tmp_path):
    rng = np.random.default_rng(1)
    H, d, N, K = 12, 6, 40, 4
    W1 = rng.standard_normal((H, d))
    b1 = rng.standard_normal(H)
    W2 = rng.standard_normal((K, H))
    b2 = rng.standard_normal(K)
    X_test = rng.standard_normal((N, d))
    y_test_true = rng.integers(0, K, size=N).astype(np.int32)
    relu_pred = rng.integers(0, K, size=N).astype(np.int32)
    relu_logits = rng.standard_normal((N, K))

    schemes = [{
        "name": "quad4fhe", "degree": 2,
        "coeffs": [0.0, 0.5, 0.2], "coeffs_order": "ascending",
        "logits_test": rng.standard_normal((N, K)),
    }]

    out_dir = export_he_artifacts(
        out_dir=str(tmp_path / "mc_out"), task="multiclass",
        W1=W1, b1=b1, W2=W2, b2=b2,
        X_test=X_test, y_test_true=y_test_true,
        relu_pred_test=relu_pred, relu_logits_test=relu_logits,
        schemes=schemes,
    )

    # Multi-class: W2 is (K, H) on disk
    W2_rt = np.fromfile(os.path.join(out_dir, "W2.bin"), dtype=np.float64).reshape(K, H)
    b2_rt = np.fromfile(os.path.join(out_dir, "b2.bin"), dtype=np.float64)
    np.testing.assert_array_equal(W2, W2_rt)
    np.testing.assert_array_equal(b2, b2_rt)

    with open(os.path.join(out_dir, "meta.json")) as f:
        meta = json.load(f)
    assert meta["task"] == "multiclass"
    assert meta["num_classes"] == K


def test_export_with_scaler_stats(tmp_path):
    rng = np.random.default_rng(2)
    H, d, N = 4, 5, 20
    scaler_mean = rng.standard_normal(d)
    scaler_scale = np.abs(rng.standard_normal(d)) + 0.1

    out_dir = export_he_artifacts(
        out_dir=str(tmp_path / "sc_out"), task="binary",
        W1=rng.standard_normal((H, d)),
        b1=rng.standard_normal(H),
        W2=rng.standard_normal(H),
        b2=0.0,
        X_test=rng.standard_normal((N, d)),
        y_test_true=np.zeros(N, dtype=np.int32),
        relu_pred_test=np.zeros(N, dtype=np.int32),
        relu_logits_test=rng.standard_normal(N),
        schemes=[{"name": "s", "degree": 2, "coeffs": [0, 0, 1],
                  "threshold": 0.0, "logits_test": rng.standard_normal(N)}],
        scaler_mean=scaler_mean, scaler_scale=scaler_scale,
    )
    assert os.path.exists(os.path.join(out_dir, "scaler_mean.bin"))
    sm_rt = np.fromfile(os.path.join(out_dir, "scaler_mean.bin"), dtype=np.float64)
    ss_rt = np.fromfile(os.path.join(out_dir, "scaler_scale.bin"), dtype=np.float64)
    np.testing.assert_array_equal(scaler_mean, sm_rt)
    np.testing.assert_array_equal(scaler_scale, ss_rt)

    with open(os.path.join(out_dir, "meta.json")) as f:
        meta = json.load(f)
    assert meta["has_scaler"] is True


def test_export_rejects_whitespace_in_scheme_name(tmp_path):
    rng = np.random.default_rng(0)
    with pytest.raises(ValueError, match="whitespace"):
        export_he_artifacts(
            out_dir=str(tmp_path / "bad"), task="binary",
            W1=rng.standard_normal((4, 3)),
            b1=rng.standard_normal(4),
            W2=rng.standard_normal(4),
            b2=0.0,
            X_test=rng.standard_normal((5, 3)),
            y_test_true=np.zeros(5, dtype=np.int32),
            relu_pred_test=np.zeros(5, dtype=np.int32),
            relu_logits_test=rng.standard_normal(5),
            schemes=[{"name": "bad name",  # space not allowed
                      "degree": 2, "coeffs": [0, 0, 1],
                      "threshold": 0.0, "logits_test": rng.standard_normal(5)}],
        )
