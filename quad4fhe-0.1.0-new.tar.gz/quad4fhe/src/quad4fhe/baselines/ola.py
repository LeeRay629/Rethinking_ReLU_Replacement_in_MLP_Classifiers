"""
quad4fhe.baselines.ola — Gaussian-weighted least-squares baseline following
the OLA activation-substitution paper.

OLA fits polynomials by weighting grid points with a Gaussian centred on the
hidden pre-activation distribution's mean, with adjustable bandwidth
(`lambda_scale * r * sigma`). It sweeps a fixed set of degrees and returns
the best-fitting configuration by a simple scoring rule.
"""
from __future__ import annotations

from typing import List, Tuple

import numpy as np

from quad4fhe.baselines._base import _BaseBaseline, activation_numpy

OLA_SEARCH_SPACE = [7, 15, 31, 63, 127, 255]
OLA_SCALE_R = 2.2
OLA_LAMBDA_THRESHOLD = 1e6
OLA_LAMBDA_CANDIDATES = [1.0, 2.0]


def _fit_ola_polynomial(
    Y_ref: np.ndarray,
    degree: int,
    activation: str,
    r: float = OLA_SCALE_R,
    lambda_scale: float = 1.0,
    grid_points: int = 30000,
) -> Tuple[np.ndarray, callable, float, float, float]:
    """Fit a single OLA polynomial. Returns (coeffs_desc, poly_fn_x,
    max_err, mean_err, max_abs_coeff)."""
    act_fn = activation_numpy(activation)
    flat = np.asarray(Y_ref, dtype=np.float64).reshape(-1)
    B1, B2 = float(np.min(flat)), float(np.max(flat))
    if abs(B2 - B1) < 1e-12:
        B2 = B1 + 1e-12
    center = 0.5 * (B1 + B2)
    halfspan = 0.5 * (B2 - B1)
    sigma_x = max(float(np.std(flat)), 1e-12)
    mu_x = float(np.mean(flat))
    mu_z = (mu_x - center) / halfspan
    sigma_z = sigma_x / halfspan
    sigma_eff_z = max(float(r) * float(lambda_scale) * sigma_z, 1e-12)

    z_grid = np.linspace(-1.0, 1.0, grid_points)
    x_grid = center + halfspan * z_grid
    act_grid = act_fn(x_grid)
    weights = np.exp(-0.5 * ((z_grid - mu_z) / sigma_eff_z) ** 2)

    V = np.vander(z_grid, N=degree + 1, increasing=True)
    sqrt_w = np.sqrt(weights)
    Aw = V * sqrt_w[:, None]
    bw = act_grid * sqrt_w
    coeffs_inc_z, *_ = np.linalg.lstsq(Aw, bw, rcond=None)
    coeffs_desc_z = coeffs_inc_z[::-1]
    poly_z = np.poly1d(coeffs_desc_z)

    def poly_fn_x(x):
        x = np.asarray(x, dtype=np.float64)
        z = (x - center) / halfspan
        return poly_z(z)

    approx_grid = poly_fn_x(x_grid)
    max_err = float(np.max(np.abs(approx_grid - act_grid)))
    mean_err = float(np.mean(np.abs(approx_grid - act_grid)))
    max_abs_coeff = float(np.max(np.abs(coeffs_desc_z))) if coeffs_desc_z.size > 0 else 0.0
    return coeffs_desc_z, poly_fn_x, max_err, mean_err, max_abs_coeff


class OLABaseline(_BaseBaseline):
    """Sweep OLA degrees and pick the best configuration by (max_err,
    smallest degree) while respecting coefficient-magnitude constraints."""
    name = "ola"

    def __init__(self,
                 degrees: List[int] = OLA_SEARCH_SPACE,
                 r: float = OLA_SCALE_R,
                 lambda_candidates: List[float] = OLA_LAMBDA_CANDIDATES,
                 lambda_threshold: float = OLA_LAMBDA_THRESHOLD):
        self.degrees = list(degrees)
        self.r = float(r)
        self.lambda_candidates = list(lambda_candidates)
        self.lambda_threshold = float(lambda_threshold)
        self._fn = None
        self.selected_degree = None
        self.selected_lambda_scale = None

    def fit(self, Y_ref: np.ndarray, activation: str) -> None:
        best = None
        best_score = None
        for deg in self.degrees:
            chosen = None
            for lam in self.lambda_candidates:
                row = _fit_ola_polynomial(Y_ref, degree=deg, activation=activation,
                                          r=self.r, lambda_scale=lam)
                coeffs, poly_fn, max_err, mean_err, max_abs_coeff = row
                if lam == 1.0 and max_abs_coeff <= self.lambda_threshold:
                    chosen = (coeffs, poly_fn, max_err, mean_err, max_abs_coeff, lam)
                    break
                if lam != 1.0:
                    chosen = (coeffs, poly_fn, max_err, mean_err, max_abs_coeff, lam)
            if chosen is None:
                continue
            coeffs, poly_fn, max_err, mean_err, max_abs_coeff, lam_used = chosen
            # Score: lower max_err first, then smaller degree.
            score = (-max_err, -deg)
            if best_score is None or score > best_score:
                best_score = score
                best = {
                    "degree": deg, "lambda_scale": lam_used,
                    "coeffs_desc": coeffs, "poly_fn": poly_fn,
                    "max_err": max_err, "mean_err": mean_err,
                    "max_abs_coeff": max_abs_coeff,
                }
        if best is None:
            raise RuntimeError("OLA failed to fit at any configured degree.")

        self._fn = lambda x: best["poly_fn"](np.asarray(x, dtype=np.float64))
        self.max_err = best["max_err"]
        self.mean_err = best["mean_err"]
        self.selected_degree = best["degree"]
        self.selected_lambda_scale = best["lambda_scale"]
        self.coeffs_info = {
            "kind": "ola",
            "degree": best["degree"],
            "lambda_scale": best["lambda_scale"],
            # OLA polynomial is expressed in z = (x - c)/h variables; note this
            # differently so downstream HE export can remember the change-of-variable.
            "coeffs_ascending_in_z": [float(v) for v in best["coeffs_desc"][::-1].tolist()],
            "max_abs_coeff": best["max_abs_coeff"],
        }

    def apply(self, Y: np.ndarray) -> np.ndarray:
        return self._fn(Y)
