# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/).

## [0.1.0] - 2026-04

### Added
- Initial public release.
- Top-level `quad4fhe.replace(...)` pipeline for one-line substitution.
- `QuadraticActivation` drop-in `nn.Module`.
- Binary task:
  - Hard-margin exact substitution (Theorems 1–3).
  - RCH fallback (Theorem 4).
  - Theorem-5 primal soft-margin QP.
- Multi-class task:
  - Hard-margin homogeneous QP (Proposition 2.6(1)).
  - Soft-margin homogeneous QP (Proposition 2.6(2)).
  - Cutting-plane acceleration for large `N*(K-1)`.
  - OSQP batch warm-start for soft-margin `C` sweeps.
- Automatic BatchNorm1d folding; LayerNorm raises `UnsupportedLayerError`.
- Frozen-backbone support via `backbone=...`.
- Quantization robustness scan (1–7 decimals) with exact and RCH tolerance bounds.
- Baseline zoo: Square, LS-Poly (2/3/5/7), Remez (2/3/5/7), OLA, Precise-Approximation (alpha=11, ReLU only).
- Two evaluation DataFrames (vs pseudo-labels / vs ground truth).
- HE artifact export for C++ SEAL/CKKS consumption:
  - Binary and multi-class schemas.
  - Multi-scheme manifest (Quad4FHE + polynomial baselines).
  - Optional StandardScaler statistics.
  - `input_kind` metadata for raw / scaled / backbone-output inputs.
- 70 unit and integration tests (77% overall coverage).
- Three end-to-end examples (binary, multiclass+BN, frozen backbone).
